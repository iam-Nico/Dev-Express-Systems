﻿Imports System.ComponentModel
Imports System.Text


Imports DevExpress.XtraSplashScreen


Partial Public Class Form1
    Shared Sub New()
        DevExpress.UserSkins.BonusSkins.Register()
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub
    Public Sub New()
        InitializeComponent()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        UC_hides()
        lbl_currentuser.Text = frm_login._User

        Dim ctl As Control
        Dim ctlMDI As MdiClient

        ' Loop through all of the form's controls looking
        ' for the control of type MdiClient.
        For Each ctl In Me.Controls
            Try
                ' Attempt to cast the control to type MdiClient.
                ctlMDI = CType(ctl, MdiClient)

                ' Set the BackColor of the MdiClient control.
                ctlMDI.BackColor = Color.FromArgb(240, 240, 240)

            Catch exc As InvalidCastException
                ' Catch and ignore the error if casting failed.
            End Try
        Next
    End Sub

    Private Sub btn_enrollment_Click(sender As Object, e As EventArgs) Handles btn_enrollment.Click
        UC_hides()
        SplashScreenManager.ShowForm(GetType(WaitForm1))
        Uc_enrollment1.Show()
        SplashScreenManager.CloseForm()
    End Sub

    Private Sub btn_stud_grades_Click(sender As Object, e As EventArgs) Handles btn_stud_grades.Click
        UC_hides()
        Uc_grades1.Show()
    End Sub

    Private Sub tmr_date_Tick(sender As Object, e As EventArgs) Handles tmr_date.Tick

        lbl_date.Text = Date.Now.ToLongDateString
        lbl_time.Text = Date.Now.ToLongTimeString
    End Sub

    Private Sub btn_faculties_Click(sender As Object, e As EventArgs) Handles btn_faculties.Click
        UC_hides()
        Uc_faculties1.Show()
    End Sub

    Public Sub UC_hides()
        Uc_enrollment1.Hide()
        Uc_faculties1.Hide()
        Uc_students1.Hide()
        Uc_subjects1.Hide()
        Uc_grades1.Hide()
        Uc_classlist1.Hide()
    End Sub

    Private Sub btn_stud_reg_Click(sender As Object, e As EventArgs) Handles btn_stud_reg.Click
        UC_hides()
        Uc_students1.Show()
    End Sub

    Private Sub btn_subjects_Click(sender As Object, e As EventArgs) Handles btn_subjects.Click
        UC_hides()
        Uc_subjects1.Show()
    End Sub

    Private Sub btn_class_list_Click(sender As Object, e As EventArgs) Handles btn_class_list.Click
        UC_hides()
        Uc_classlist1.Show()
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click

        Me.WindowState = FormWindowState.Minimized

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        frm_login.txt_username.Text = ""
        frm_login.txt_password.Text = ""

        frm_login.Show()
        Me.Hide()
    End Sub

End Class
