﻿Module Public_Variables

    Public Command As Integer
    Public _GradeLevel As String
    Public _Section As String

End Module
