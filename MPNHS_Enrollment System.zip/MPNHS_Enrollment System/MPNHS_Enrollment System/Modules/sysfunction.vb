﻿
Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Microsoft.VisualBasic
Imports System.IO

Module sysfunction


    Public Collection As New AutoCompleteStringCollection()

    Public Function Login(ByVal username As String, password As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.UserLogin("Select * from tbl_faculties where faculties_username = '" & username & "' and faculties_password = '" & password & "'")
        Return dt
    End Function

    ''DROPDOWNS
    Public Function dropdowns_F() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetFacultylist("Select (faculties_fname + '" & " " & "' + Substring(faculties_mname,1,1) + '" & "." & "' + '" & " " & "' +  faculties_lname) as faculty_names from tbl_faculties")

        Return dt
    End Function

    Public Function dropdowns_S() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetStudentID("Select (stud_fname + '" & " " & "' + Substring(stud_mname,1,1) + '" & "." & "' + '" & " " & "' +  stud_lname) as stud_names,stud_id from tbl_students where stud_id = '" & frm_enrollstudents.txt_studid.Text & "' and stud_status = '" & "Not Enrolled" & "'")

        Return dt
    End Function

    Public Function getstudids() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetStudentID(" ;WITH Base AS (SELECT stud_id,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name FROM tbl_students)" &
                              "SELECT * FROM Base WHERE stud_name = '" & frm_enrollstudents.txt_studname.Text & "'")

        Return dt
    End Function

    ''FACULTIES
    Public Sub AddFaculties(ByVal fac_fname As String, fac_mname As String, fac_lname As String, fac_address As String, fac_contact As String, fac_username As String, fac_password As String, fac_gadv As String, fac_sadv As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_faculties (faculties_fname,faculties_mname,faculties_lname,faculties_address,faculties_contactnumber,faculties_username,faculties_password,faculties_gadvisory,faculties_sadvisory)" &
                            "values ('" & fac_fname & "','" & fac_mname & "','" & fac_lname & "','" & fac_address & "','" & fac_contact & "','" & fac_username & "','" & fac_password & "','" & fac_gadv & "','" & fac_sadv & "')")
    End Sub


    Public Function GetFaculties() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetFacultylist("Select * from tbl_faculties")

        Return dt
    End Function

    Public Sub EditFaculties(ByVal fac_id As String, fac_fname As String, fac_mname As String, fac_lname As String, fac_address As String, fac_contact As String, fac_username As String, fac_password As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_faculties set faculties_fname = '" & fac_fname & "',faculties_mname = '" & fac_mname & "',faculties_lname = '" & fac_lname & "',faculties_address = '" & fac_address & "',faculties_contactnumber = '" & fac_contact & ",faculties_username = '" & fac_username & "',faculties_password = '" & fac_password & "' where faculties_id = '" & fac_id & "' ")
    End Sub

    Public Sub DeleteFaculties(ByVal faculty_id As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_faculties where subject_id = '" & faculty_id & "'")
    End Sub

    ''SUBJECTS
    Public Sub AddSubjects(ByVal subj_code As String, subj_description As String, subj_stime As String, subj_etime As String, subj_teacher As String, subj_grade As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_subjects (subject_id,subject_description,subject_starttime,subject_endtime,subject_teacher,subject_grade)" &
                            "values ('" & subj_code & "','" & subj_description & "','" & subj_stime & "','" & subj_etime & "','" & subj_teacher & "','" & subj_grade & "')")
    End Sub

    Public Function GetSubjects() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select *,(subject_starttime + '" & "-" & "' + subject_endtime) as subject_time from tbl_subjects ")

        Return dt
    End Function

    Public Sub EditSubjects(ByVal subject_id As String, subject_desc As String, subject_from As String, subject_to As String, subject_teacher As String, subject_glvl As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_subjects set subject_id = '" & subject_id & "',subject_description = '" & subject_desc & "',subject_starttime = '" & subject_from & "',subject_endtime = '" & subject_to & "',subject_teacher = '" & subject_teacher & "',subject_grade = '" & subject_glvl & "' where subject_id = '" & subject_id & "' ")
    End Sub

    Public Sub DeleteSubjects(ByVal subject_id As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_subjects where subject_id = '" & subject_id & "'")
    End Sub

    ''STUDENTS
    Public Sub AddStudents(ByVal stud_fname As String, stud_mname As String, stud_lname As String, stud_gender As String, stud_bday As String, stud_age As Integer, stud_address As String, stud_contact As String, stud_mother As String, stud_father As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_students (stud_fname,stud_mname,stud_lname,stud_gender,stud_bday,stud_age,stud_address,stud_contactnumber,stud_mother,stud_father,stud_status,date_added)" &
                            "values ('" & stud_fname & "','" & stud_mname & "','" & stud_lname & "','" & stud_gender & "','" & stud_bday & "','" & stud_age & "','" & stud_address & "','" & stud_contact & "','" & stud_mother & "','" & stud_father & "','" & "Not Enrolled" & "','" & Form1.lbl_date.Text + " " + Form1.lbl_time.Text & "')")
    End Sub

    Public Function GetStudents() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select * from tbl_students ")

        Return dt
    End Function

    Public Sub EditStudents(ByVal stud_id As String, stud_fname As String, stud_mname As String, stud_lname As String, stud_bday As String, stud_age As String, stud_gender As String, stud_address As String, stud_contact As String, stud_mother As String, stud_father As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_students set stud_fname = '" & stud_fname & "',stud_mname = '" & stud_mname & "',stud_lname = '" & stud_lname & "',stud_bday = '" & stud_bday & "',stud_age = '" & stud_age & "',stud_gender = '" & stud_gender & "',stud_address = '" & stud_address & "',stud_contactnumber = '" & stud_contact & "',stud_mother = '" & stud_mother & "',stud_father = '" & stud_father & "' where stud_id = '" & stud_id & "' ")
    End Sub

    Public Sub DeleteStudents(ByVal stud_id As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_students where stud_id = '" & stud_id & "'")
    End Sub


    ''ENROLLMENT
    Public Sub Enroll(ByVal stud_id As String, fac_id As String, stud_grade As String, stud_section As String, enroll_date As String, school_year As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_enrollment (stud_id,faculties_id,stud_gradelevel,stud_section,enroll_date,school_year)" &
                            "values ('" & stud_id & "','" & fac_id & "','" & stud_grade & "','" & stud_section & "','" & enroll_date & "','" & school_year & "')")

        id = obj.ActionData("Update tbl_students set stud_status = '" & "Enrolled" & "' where stud_id = '" & frm_enrollstudents.txt_studid.Text & "'")

        'id = obj.ActionData("Insert into tbl_grades (stud_id,subject_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,grade_period)" &
        '                    "values ('" & frm_enrollstudents.txt_studid.Text & "','" & frm_enrollstudents.dg_subjects.Rows(1).Cells(0).Value.ToString & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & "First Grading" & "')")

    End Sub

    Public Sub AddtoGrades()
        Dim obj As New SqlHelper
        Dim id As Integer
        Dim zero As Decimal = 0


        ' MessageBox.Show(CStr(frm_enrollstudents.dg_subjects.Rows.Count - 2))

        For i As Integer = 0 To frm_enrollstudents.dg_subjects.Rows.Count - 2
            id = obj.ActionData("Insert into tbl_grades (stud_id,subject_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,grade_period)" &
                                "values ('" & frm_enrollstudents.txt_studid.Text & "','" & CStr(frm_enrollstudents.dg_subjects.Rows(i).Cells(0).Value) & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & "First Grading" & "')")
            id = obj.ActionData("Insert into tbl_grades (stud_id,subject_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,grade_period)" &
                                "values ('" & frm_enrollstudents.txt_studid.Text & "','" & CStr(frm_enrollstudents.dg_subjects.Rows(i).Cells(0).Value) & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & "Second Grading" & "')")
            id = obj.ActionData("Insert into tbl_grades (stud_id,subject_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,grade_period)" &
                                "values ('" & frm_enrollstudents.txt_studid.Text & "','" & CStr(frm_enrollstudents.dg_subjects.Rows(i).Cells(0).Value) & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & "Third Grading" & "')")
            id = obj.ActionData("Insert into tbl_grades (stud_id,subject_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,grade_period)" &
                                "values ('" & frm_enrollstudents.txt_studid.Text & "','" & CStr(frm_enrollstudents.dg_subjects.Rows(i).Cells(0).Value) & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & zero & "','" & "Fourth Grading" & "')")
        Next

    End Sub

    Public Function GetEnrolledSubjects() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select subject_id,subject_description,(subject_starttime + '" & "-" & "' + subject_endtime) as subject_time,subject_teacher from tbl_subjects where subject_grade = '" & frm_enrollstudents.cbo_gradelvl.Text & "'")

        Return dt
    End Function

    Public Sub EditEnrolled(ByVal stud_id As String, stud_glvl As String, stud_section As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_enrollment set stud_gradelevel = '" & stud_glvl & "',stud_section= '" & stud_section & "' where stud_id = '" & stud_id & "'")
    End Sub

    Public Sub DeleteEnrolled(ByVal enroll_id As String, stud_id As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_enrollment where enroll_id = '" & enroll_id & "'")

        id = obj.ActionData("Update tbl_students set stud_status = '" & "Not Enrolled" & "' where stud_id = '" & stud_id & "'")

    End Sub


    Public Function GetEnrolledStudents() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select *,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name from Enrolled_List")

        Return dt
    End Function

    Public Function GetClasslist() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select stud_id,(stud_lname +', '+ stud_fname +' '+ substring(stud_mname,1,1)+'.') as stud_name,stud_gender,stud_gradelevel,stud_section from Enrolled_List order by stud_name asc")

        Return dt
    End Function

    Public Function FilterClasslist() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select stud_id,(stud_lname +', '+ stud_fname +' '+ substring(stud_mname,1,1)+'.') as stud_name,stud_gender,stud_gradelevel,stud_section from Enrolled_List where stud_gradelevel = '" & Form1.Uc_classlist1.cbo_gradelevel.Text & "' and stud_section = '" & Form1.Uc_classlist1.cbo_section.Text & "' order by stud_name asc")

        Return dt
    End Function

    ''GRADES
    Public Function GetGrades() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable

        If _Section = "Generosity" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                            " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl2.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Patience" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                              " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl2.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Responsibility" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                                " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl3.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Hardwork" Then
            'MessageBox.Show("Hello")
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                      " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl3.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Initiative" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                                     " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl4.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Sincerity" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                                  " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl4.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Discipline" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                               " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.Xtratab2.SelectedTabPage.Text & "' ")

        ElseIf _Section = "Punctuality" Then
            dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id,grade_final from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                              " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.Xtratab2.SelectedTabPage.Text & "' ")

        End If


        Return dt
    End Function

    Public Function GetGradesHardwork() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        'MessageBox.Show("Hello")
        dt = obj.GetFacultylist("Select stud_id,grade_recitation1,grade_recitation2,grade_quiz1,grade_quiz2,grade_quiz3,grade_project,grade_exam,(stud_fname +' '+ substring(stud_mname,1,1)+'.'+' '+ stud_lname) as stud_name,grade_id from Students_Grade where subject_description = '" & Form1.Uc_grades1.cbo_subjects.Text & "' " &
                            " and grade_period = '" & Form1.Uc_grades1.cbo_period.Text & "' and stud_gradelevel = '" & Form1.Uc_grades1.XtraTabControl1.SelectedTabPage.Text & "' and stud_section = '" & Form1.Uc_grades1.XtraTabControl3.SelectedTabPage.Text & "' ")
        Return dt
    End Function


    Public Sub EditGrades()
        Dim obj As New SqlHelper
        Dim id As Integer

        If _Section = "Generosity" Then
            For i As Integer = 0 To Form1.Uc_grades1.dg_generosity.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dg_generosity.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dg_generosity.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Patience" Then
            For i As Integer = 0 To Form1.Uc_grades1.dgpatience.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dgpatience.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dgpatience.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Responsibility" Then
            For i As Integer = 0 To Form1.Uc_grades1.dgresponsibility.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dgresponsibility.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Hardwork" Then
            For i As Integer = 0 To Form1.Uc_grades1.dghardwork.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dghardwork.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dghardwork.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Initiative" Then
            For i As Integer = 0 To Form1.Uc_grades1.dginitiative.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dginitiative.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dginitiative.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Sincerity" Then
            For i As Integer = 0 To Form1.Uc_grades1.dgsincerity.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dgsincerity.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dgsincerity.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Discipline" Then
            For i As Integer = 0 To Form1.Uc_grades1.dgdiscipline.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dgdiscipline.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        ElseIf _Section = "Punctuality" Then
            For i As Integer = 0 To Form1.Uc_grades1.dgpunctuality.Rows.Count - 1

                id = obj.ActionData("Update tbl_grades set grade_recitation1 = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(1).Value.ToString) & "',grade_recitation2 = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(2).Value.ToString) & "',grade_quiz1 = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(3).Value.ToString) & "',grade_quiz2 = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(4).Value.ToString) & "',grade_quiz3 = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(5).Value.ToString) & "',grade_project = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(6).Value.ToString) & "',grade_exam = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(7).Value.ToString) & "',grade_final = '" & CDec(Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(10).Value.ToString) & "' where grade_id = '" & Form1.Uc_grades1.dgpunctuality.Rows(i).Cells(9).Value.ToString & "' ")

            Next
        End If

    End Sub



End Module
