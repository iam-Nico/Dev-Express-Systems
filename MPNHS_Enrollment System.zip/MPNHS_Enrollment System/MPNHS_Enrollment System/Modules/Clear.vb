﻿Imports DevExpress.XtraEditors


Imports System.Data.Sql
Imports System.Data.SqlClient

Module Clear

    Public Sub ClearFields()

        Dim c As Control
        Dim cbo As System.Windows.Forms.ComboBox

        For Each c In frm_enrollstudents.GroupControl1.Controls

            If TypeOf c Is TextEdit Or TypeOf c Is TextBox Then

                c.Text = Nothing
                'Dim te As TextEdit = CType(c, TextEdit)
                'te.Properties.ReadOnly = True
            ElseIf TypeOf c Is ComboBoxEdit Then
                c.Text = ""
            End If

        Next

        For Each c In frm_addfaculties.GroupControl1.Controls

            If TypeOf c Is TextEdit Then
                c.Text = Nothing
            End If

        Next

        For Each c In frm_addsubjects.GroupControl1.Controls

            If TypeOf c Is TextEdit Then
                c.Text = Nothing
            ElseIf TypeOf c Is ComboBoxEdit Then
                c.Text = ""
            ElseIf TypeOf c Is LookUpEdit Then
                c.Text = ""
            End If

        Next

        For Each c In frm_regstudents.GroupControl1.Controls

            If TypeOf c Is TextEdit Then
                c.Text = Nothing
            ElseIf TypeOf c Is ComboBoxEdit Then
                c.Text = ""
            ElseIf TypeOf c Is DateEdit Then
                c.Text = ""
            End If

        Next

        'frm_enrollstudents.dg_faculties.DataSource = Nothing

    End Sub


End Module
