﻿
Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.TypeInitializationException


Imports DevExpress.XtraSplashScreen

Public Class SqlHelper

    Public _cmd As SqlCommand
    Public _dr As SqlDataReader
    Public _dap As SqlDataAdapter
    Public _con As SqlConnection




    Public Function ActionData(ByVal str As String) As Integer
        Dim returnval As String
        _con = New SqlConnection(My.Settings.dbcon)
        _con.Open()
        _cmd = New SqlCommand
        _cmd.CommandType = CommandType.Text
        _cmd.CommandText = str
        _cmd.Connection = _con
        returnval = _cmd.ExecuteNonQuery

        _con.Dispose()
        _cmd.Dispose()
        Return returnval
    End Function


    Public Function UserLogin(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd
            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

            End Using

            Dim _dr As SqlDataReader = _cmd.ExecuteReader
            _dr.Read()

            If _dr.HasRows Then
                frm_login._UserID = _dr("faculties_id").ToString
                frm_login._User = _dr("faculties_fname").ToString
                frm_login.Hide()

                SplashScreenManager.ShowForm(GetType(WaitForm1))
                Form1.Show()
                SplashScreenManager.CloseForm()

            Else
                MessageBox.Show("Invalid Login!")
            End If

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function


    Public Function GetFacultylist(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd

            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

                frm_addsubjects.cbo_teacher.Properties.DataSource = dt
                frm_addsubjects.cbo_teacher.Properties.DisplayMember = "faculty_names"
                'frm_addsubjects.cbo_teacher.Properties.ValueMember = "dbID"

            End Using

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function


    Public Function GetStudentlist(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd

            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

                'frm_enrollstudents.txt_studname.DataBindings.Add("Hey", dt, "stud_names")
                'frm_enrollstudents.ListBoxControl1.DataSource = dt
                'frm_enrollstudents.ListBoxControl1.DisplayMember = "stud_names"
                Collection.Clear()
                For i As Integer = 0 To dt.Rows.Count
                    Collection.Add(dt.Rows(i)(0).ToString)
                    'MessageBox.Show(dt.Rows(i)(0).ToString)
                Next
            End Using

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function

    Public Function GetStudentID(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd

            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

            End Using

            Dim _dr As SqlDataReader = _cmd.ExecuteReader
            _dr.Read()

            If _dr.HasRows Then
                frm_enrollstudents._StudentID = _dr("stud_names").ToString
            Else
                frm_enrollstudents.lbl_notfound.Visible = True
            End If


            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function

    Public Function GetData(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd

            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)
            End Using

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function



End Class
