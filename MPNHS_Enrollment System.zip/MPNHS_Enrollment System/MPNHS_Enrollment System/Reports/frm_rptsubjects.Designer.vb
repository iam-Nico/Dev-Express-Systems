﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_rptsubjects
    Inherits DevExpress.XtraBars.Ribbon.RibbonForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim SuperToolTip1 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem1 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem1 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip2 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem2 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem2 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip3 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem3 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem3 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip4 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem4 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem4 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip5 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem5 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem5 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip6 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem6 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem6 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip7 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem7 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem7 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip8 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem8 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem8 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip9 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem9 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem9 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip10 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem10 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem10 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip11 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem11 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem11 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip12 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem12 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem12 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip13 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem13 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem13 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip14 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem14 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem14 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip15 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem15 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem15 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip16 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem16 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem16 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip17 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem17 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem17 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip18 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem18 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem18 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip19 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem19 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem19 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip20 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem20 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem20 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip21 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem21 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem21 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip22 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem22 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem22 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip23 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem23 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem23 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip24 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem24 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem24 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip25 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem25 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem25 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip26 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem26 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem26 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip27 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem27 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem27 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip28 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem28 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem28 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip29 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem29 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem29 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip30 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem30 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem30 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip31 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem31 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem31 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip32 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem32 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem32 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip33 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem33 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem33 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip34 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem34 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem34 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip35 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem35 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem35 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip36 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem36 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem36 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip37 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem37 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem37 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip38 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem38 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem38 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip39 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem39 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem39 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip40 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem40 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem40 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip41 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem41 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem41 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip42 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem42 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem42 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip43 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem43 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem43 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip44 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem44 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem44 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip45 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem45 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem45 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip46 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem46 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem46 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip47 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem47 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem47 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip48 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem48 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem48 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip49 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem49 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem49 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip50 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem50 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem50 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip51 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem51 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem51 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Dim SuperToolTip52 As DevExpress.Utils.SuperToolTip = New DevExpress.Utils.SuperToolTip()
        Dim ToolTipTitleItem52 As DevExpress.Utils.ToolTipTitleItem = New DevExpress.Utils.ToolTipTitleItem()
        Dim ToolTipItem52 As DevExpress.Utils.ToolTipItem = New DevExpress.Utils.ToolTipItem()
        Me.DocumentViewer1 = New DevExpress.XtraPrinting.Preview.DocumentViewer()
        Me.DocumentViewerRibbonController1 = New DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController(Me.components)
        Me.RibbonControl1 = New DevExpress.XtraBars.Ribbon.RibbonControl()
        Me.PrintPreviewBarItem1 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem2 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem3 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem4 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem5 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem6 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem7 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem8 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem9 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem10 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem11 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem12 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem13 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem14 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem15 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem16 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem17 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem18 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem19 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem20 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem21 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem22 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem23 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem24 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem25 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem26 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem27 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem28 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem29 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem30 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem31 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem32 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem33 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem34 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem35 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem36 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem37 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem38 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem39 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem40 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem41 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem42 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem43 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem44 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem45 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem46 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem47 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem48 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem49 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem50 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewBarItem51 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewStaticItem1 = New DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem()
        Me.BarStaticItem1 = New DevExpress.XtraBars.BarStaticItem()
        Me.ProgressBarEditItem1 = New DevExpress.XtraPrinting.Preview.ProgressBarEditItem()
        Me.RepositoryItemProgressBar1 = New DevExpress.XtraEditors.Repository.RepositoryItemProgressBar()
        Me.PrintPreviewBarItem52 = New DevExpress.XtraPrinting.Preview.PrintPreviewBarItem()
        Me.PrintPreviewStaticItem2 = New DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem()
        Me.ZoomTrackBarEditItem1 = New DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem()
        Me.RepositoryItemZoomTrackBar1 = New DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar()
        Me.RibbonPage1 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage()
        Me.PrintPreviewRibbonPageGroup1 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup2 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup3 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup4 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup5 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup6 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup7 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.PrintPreviewRibbonPageGroup8 = New DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup()
        Me.RibbonStatusBar1 = New DevExpress.XtraBars.Ribbon.RibbonStatusBar()
        CType(Me.DocumentViewerRibbonController1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RibbonControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemProgressBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DocumentViewer1
        '
        Me.DocumentViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.DocumentViewer1.DocumentSource = GetType(MPNHS_Enrollment_System.rpt_subjects)
        Me.DocumentViewer1.IsMetric = False
        Me.DocumentViewer1.Location = New System.Drawing.Point(0, 146)
        Me.DocumentViewer1.Name = "DocumentViewer1"
        Me.DocumentViewer1.Size = New System.Drawing.Size(581, 195)
        Me.DocumentViewer1.TabIndex = 0
        '
        'DocumentViewerRibbonController1
        '
        Me.DocumentViewerRibbonController1.DocumentViewer = Me.DocumentViewer1
        Me.DocumentViewerRibbonController1.RibbonControl = Me.RibbonControl1
        Me.DocumentViewerRibbonController1.RibbonStatusBar = Me.RibbonStatusBar1
        '
        'RibbonControl1
        '
        Me.RibbonControl1.AutoHideEmptyItems = True
        Me.RibbonControl1.ExpandCollapseItem.Id = 0
        Me.RibbonControl1.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.RibbonControl1.ExpandCollapseItem, Me.PrintPreviewBarItem1, Me.PrintPreviewBarItem2, Me.PrintPreviewBarItem3, Me.PrintPreviewBarItem4, Me.PrintPreviewBarItem5, Me.PrintPreviewBarItem6, Me.PrintPreviewBarItem7, Me.PrintPreviewBarItem8, Me.PrintPreviewBarItem9, Me.PrintPreviewBarItem10, Me.PrintPreviewBarItem11, Me.PrintPreviewBarItem12, Me.PrintPreviewBarItem13, Me.PrintPreviewBarItem14, Me.PrintPreviewBarItem15, Me.PrintPreviewBarItem16, Me.PrintPreviewBarItem17, Me.PrintPreviewBarItem18, Me.PrintPreviewBarItem19, Me.PrintPreviewBarItem20, Me.PrintPreviewBarItem21, Me.PrintPreviewBarItem22, Me.PrintPreviewBarItem23, Me.PrintPreviewBarItem24, Me.PrintPreviewBarItem25, Me.PrintPreviewBarItem26, Me.PrintPreviewBarItem27, Me.PrintPreviewBarItem28, Me.PrintPreviewBarItem29, Me.PrintPreviewBarItem30, Me.PrintPreviewBarItem31, Me.PrintPreviewBarItem32, Me.PrintPreviewBarItem33, Me.PrintPreviewBarItem34, Me.PrintPreviewBarItem35, Me.PrintPreviewBarItem36, Me.PrintPreviewBarItem37, Me.PrintPreviewBarItem38, Me.PrintPreviewBarItem39, Me.PrintPreviewBarItem40, Me.PrintPreviewBarItem41, Me.PrintPreviewBarItem42, Me.PrintPreviewBarItem43, Me.PrintPreviewBarItem44, Me.PrintPreviewBarItem45, Me.PrintPreviewBarItem46, Me.PrintPreviewBarItem47, Me.PrintPreviewBarItem48, Me.PrintPreviewBarItem49, Me.PrintPreviewBarItem50, Me.PrintPreviewBarItem51, Me.PrintPreviewStaticItem1, Me.BarStaticItem1, Me.ProgressBarEditItem1, Me.PrintPreviewBarItem52, Me.PrintPreviewStaticItem2, Me.ZoomTrackBarEditItem1})
        Me.RibbonControl1.Location = New System.Drawing.Point(0, 0)
        Me.RibbonControl1.MaxItemId = 58
        Me.RibbonControl1.Name = "RibbonControl1"
        Me.RibbonControl1.Pages.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPage() {Me.RibbonPage1})
        Me.RibbonControl1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemProgressBar1, Me.RepositoryItemZoomTrackBar1})
        Me.RibbonControl1.Size = New System.Drawing.Size(581, 146)
        Me.RibbonControl1.StatusBar = Me.RibbonStatusBar1
        Me.RibbonControl1.TransparentEditorsMode = DevExpress.Utils.DefaultBoolean.[True]
        '
        'PrintPreviewBarItem1
        '
        Me.PrintPreviewBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem1.Caption = "Editing Fields"
        Me.PrintPreviewBarItem1.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HighlightEditingFields
        Me.PrintPreviewBarItem1.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem1.Enabled = False
        Me.PrintPreviewBarItem1.Id = 1
        Me.PrintPreviewBarItem1.Name = "PrintPreviewBarItem1"
        SuperToolTip1.FixedTooltipWidth = True
        ToolTipTitleItem1.Text = "Highlight Editing Fields"
        ToolTipItem1.LeftIndent = 6
        ToolTipItem1.Text = "Highlight all editing fields to quickly discover which of the document elements a" & _
    "re editable."
        SuperToolTip1.Items.Add(ToolTipTitleItem1)
        SuperToolTip1.Items.Add(ToolTipItem1)
        SuperToolTip1.MaxWidth = 210
        Me.PrintPreviewBarItem1.SuperTip = SuperToolTip1
        '
        'PrintPreviewBarItem2
        '
        Me.PrintPreviewBarItem2.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem2.Caption = "Bookmarks"
        Me.PrintPreviewBarItem2.Command = DevExpress.XtraPrinting.PrintingSystemCommand.DocumentMap
        Me.PrintPreviewBarItem2.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem2.Enabled = False
        Me.PrintPreviewBarItem2.Id = 2
        Me.PrintPreviewBarItem2.Name = "PrintPreviewBarItem2"
        SuperToolTip2.FixedTooltipWidth = True
        ToolTipTitleItem2.Text = "Document Map"
        ToolTipItem2.LeftIndent = 6
        ToolTipItem2.Text = "Open the Document Map, which allows you to navigate through a structural view of " & _
    "the document."
        SuperToolTip2.Items.Add(ToolTipTitleItem2)
        SuperToolTip2.Items.Add(ToolTipItem2)
        SuperToolTip2.MaxWidth = 210
        Me.PrintPreviewBarItem2.SuperTip = SuperToolTip2
        '
        'PrintPreviewBarItem3
        '
        Me.PrintPreviewBarItem3.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem3.Caption = "Parameters"
        Me.PrintPreviewBarItem3.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Parameters
        Me.PrintPreviewBarItem3.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem3.Enabled = False
        Me.PrintPreviewBarItem3.Id = 3
        Me.PrintPreviewBarItem3.Name = "PrintPreviewBarItem3"
        SuperToolTip3.FixedTooltipWidth = True
        ToolTipTitleItem3.Text = "Parameters"
        ToolTipItem3.LeftIndent = 6
        ToolTipItem3.Text = "Open the Parameters pane, which allows you to enter values for report parameters." & _
    ""
        SuperToolTip3.Items.Add(ToolTipTitleItem3)
        SuperToolTip3.Items.Add(ToolTipItem3)
        SuperToolTip3.MaxWidth = 210
        Me.PrintPreviewBarItem3.SuperTip = SuperToolTip3
        '
        'PrintPreviewBarItem4
        '
        Me.PrintPreviewBarItem4.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem4.Caption = "Find"
        Me.PrintPreviewBarItem4.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Find
        Me.PrintPreviewBarItem4.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem4.Enabled = False
        Me.PrintPreviewBarItem4.Id = 4
        Me.PrintPreviewBarItem4.Name = "PrintPreviewBarItem4"
        SuperToolTip4.FixedTooltipWidth = True
        ToolTipTitleItem4.Text = "Find"
        ToolTipItem4.LeftIndent = 6
        ToolTipItem4.Text = "Show the Find dialog to find text in the document."
        SuperToolTip4.Items.Add(ToolTipTitleItem4)
        SuperToolTip4.Items.Add(ToolTipItem4)
        SuperToolTip4.MaxWidth = 210
        Me.PrintPreviewBarItem4.SuperTip = SuperToolTip4
        '
        'PrintPreviewBarItem5
        '
        Me.PrintPreviewBarItem5.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem5.Caption = "Thumbnails"
        Me.PrintPreviewBarItem5.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Thumbnails
        Me.PrintPreviewBarItem5.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem5.Enabled = False
        Me.PrintPreviewBarItem5.Id = 5
        Me.PrintPreviewBarItem5.Name = "PrintPreviewBarItem5"
        SuperToolTip5.FixedTooltipWidth = True
        ToolTipTitleItem5.Text = "Thumbnails"
        ToolTipItem5.LeftIndent = 6
        ToolTipItem5.Text = "Open the Thumbnails, which allows you to navigate through the document."
        SuperToolTip5.Items.Add(ToolTipTitleItem5)
        SuperToolTip5.Items.Add(ToolTipItem5)
        SuperToolTip5.MaxWidth = 210
        Me.PrintPreviewBarItem5.SuperTip = SuperToolTip5
        '
        'PrintPreviewBarItem6
        '
        Me.PrintPreviewBarItem6.Caption = "Options"
        Me.PrintPreviewBarItem6.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Customize
        Me.PrintPreviewBarItem6.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem6.Enabled = False
        Me.PrintPreviewBarItem6.Id = 6
        Me.PrintPreviewBarItem6.Name = "PrintPreviewBarItem6"
        SuperToolTip6.FixedTooltipWidth = True
        ToolTipTitleItem6.Text = "Options"
        ToolTipItem6.LeftIndent = 6
        ToolTipItem6.Text = "Open the Print Options dialog, in which you can change printing options."
        SuperToolTip6.Items.Add(ToolTipTitleItem6)
        SuperToolTip6.Items.Add(ToolTipItem6)
        SuperToolTip6.MaxWidth = 210
        Me.PrintPreviewBarItem6.SuperTip = SuperToolTip6
        '
        'PrintPreviewBarItem7
        '
        Me.PrintPreviewBarItem7.Caption = "Print"
        Me.PrintPreviewBarItem7.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Print
        Me.PrintPreviewBarItem7.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem7.Enabled = False
        Me.PrintPreviewBarItem7.Id = 7
        Me.PrintPreviewBarItem7.Name = "PrintPreviewBarItem7"
        SuperToolTip7.FixedTooltipWidth = True
        ToolTipTitleItem7.Text = "Print (Ctrl+P)"
        ToolTipItem7.LeftIndent = 6
        ToolTipItem7.Text = "Select a printer, number of copies and other printing options before printing."
        SuperToolTip7.Items.Add(ToolTipTitleItem7)
        SuperToolTip7.Items.Add(ToolTipItem7)
        SuperToolTip7.MaxWidth = 210
        Me.PrintPreviewBarItem7.SuperTip = SuperToolTip7
        '
        'PrintPreviewBarItem8
        '
        Me.PrintPreviewBarItem8.Caption = "Quick Print"
        Me.PrintPreviewBarItem8.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PrintDirect
        Me.PrintPreviewBarItem8.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem8.Enabled = False
        Me.PrintPreviewBarItem8.Id = 8
        Me.PrintPreviewBarItem8.Name = "PrintPreviewBarItem8"
        SuperToolTip8.FixedTooltipWidth = True
        ToolTipTitleItem8.Text = "Quick Print"
        ToolTipItem8.LeftIndent = 6
        ToolTipItem8.Text = "Send the document directly to the default printer without making changes."
        SuperToolTip8.Items.Add(ToolTipTitleItem8)
        SuperToolTip8.Items.Add(ToolTipItem8)
        SuperToolTip8.MaxWidth = 210
        Me.PrintPreviewBarItem8.SuperTip = SuperToolTip8
        '
        'PrintPreviewBarItem9
        '
        Me.PrintPreviewBarItem9.Caption = "Custom Margins..."
        Me.PrintPreviewBarItem9.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageSetup
        Me.PrintPreviewBarItem9.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem9.Enabled = False
        Me.PrintPreviewBarItem9.Id = 9
        Me.PrintPreviewBarItem9.Name = "PrintPreviewBarItem9"
        SuperToolTip9.FixedTooltipWidth = True
        ToolTipTitleItem9.Text = "Page Setup"
        ToolTipItem9.LeftIndent = 6
        ToolTipItem9.Text = "Show the Page Setup dialog."
        SuperToolTip9.Items.Add(ToolTipTitleItem9)
        SuperToolTip9.Items.Add(ToolTipItem9)
        SuperToolTip9.MaxWidth = 210
        Me.PrintPreviewBarItem9.SuperTip = SuperToolTip9
        '
        'PrintPreviewBarItem10
        '
        Me.PrintPreviewBarItem10.Caption = "Header/Footer"
        Me.PrintPreviewBarItem10.Command = DevExpress.XtraPrinting.PrintingSystemCommand.EditPageHF
        Me.PrintPreviewBarItem10.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem10.Enabled = False
        Me.PrintPreviewBarItem10.Id = 10
        Me.PrintPreviewBarItem10.Name = "PrintPreviewBarItem10"
        SuperToolTip10.FixedTooltipWidth = True
        ToolTipTitleItem10.Text = "Header and Footer"
        ToolTipItem10.LeftIndent = 6
        ToolTipItem10.Text = "Edit the header and footer of the document."
        SuperToolTip10.Items.Add(ToolTipTitleItem10)
        SuperToolTip10.Items.Add(ToolTipItem10)
        SuperToolTip10.MaxWidth = 210
        Me.PrintPreviewBarItem10.SuperTip = SuperToolTip10
        '
        'PrintPreviewBarItem11
        '
        Me.PrintPreviewBarItem11.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem11.Caption = "Scale"
        Me.PrintPreviewBarItem11.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Scale
        Me.PrintPreviewBarItem11.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem11.Enabled = False
        Me.PrintPreviewBarItem11.Id = 11
        Me.PrintPreviewBarItem11.Name = "PrintPreviewBarItem11"
        SuperToolTip11.FixedTooltipWidth = True
        ToolTipTitleItem11.Text = "Scale"
        ToolTipItem11.LeftIndent = 6
        ToolTipItem11.Text = "Stretch or shrink the printed output to a percentage of its actual size."
        SuperToolTip11.Items.Add(ToolTipTitleItem11)
        SuperToolTip11.Items.Add(ToolTipItem11)
        SuperToolTip11.MaxWidth = 210
        Me.PrintPreviewBarItem11.SuperTip = SuperToolTip11
        '
        'PrintPreviewBarItem12
        '
        Me.PrintPreviewBarItem12.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem12.Caption = "Pointer"
        Me.PrintPreviewBarItem12.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Pointer
        Me.PrintPreviewBarItem12.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem12.Down = True
        Me.PrintPreviewBarItem12.Enabled = False
        Me.PrintPreviewBarItem12.GroupIndex = 1
        Me.PrintPreviewBarItem12.Id = 12
        Me.PrintPreviewBarItem12.Name = "PrintPreviewBarItem12"
        Me.PrintPreviewBarItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip12.FixedTooltipWidth = True
        ToolTipTitleItem12.Text = "Mouse Pointer"
        ToolTipItem12.LeftIndent = 6
        ToolTipItem12.Text = "Show the mouse pointer."
        SuperToolTip12.Items.Add(ToolTipTitleItem12)
        SuperToolTip12.Items.Add(ToolTipItem12)
        SuperToolTip12.MaxWidth = 210
        Me.PrintPreviewBarItem12.SuperTip = SuperToolTip12
        '
        'PrintPreviewBarItem13
        '
        Me.PrintPreviewBarItem13.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem13.Caption = "Hand Tool"
        Me.PrintPreviewBarItem13.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HandTool
        Me.PrintPreviewBarItem13.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem13.Enabled = False
        Me.PrintPreviewBarItem13.GroupIndex = 1
        Me.PrintPreviewBarItem13.Id = 13
        Me.PrintPreviewBarItem13.Name = "PrintPreviewBarItem13"
        Me.PrintPreviewBarItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip13.FixedTooltipWidth = True
        ToolTipTitleItem13.Text = "Hand Tool"
        ToolTipItem13.LeftIndent = 6
        ToolTipItem13.Text = "Invoke the Hand tool to manually scroll through pages."
        SuperToolTip13.Items.Add(ToolTipTitleItem13)
        SuperToolTip13.Items.Add(ToolTipItem13)
        SuperToolTip13.MaxWidth = 210
        Me.PrintPreviewBarItem13.SuperTip = SuperToolTip13
        '
        'PrintPreviewBarItem14
        '
        Me.PrintPreviewBarItem14.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check
        Me.PrintPreviewBarItem14.Caption = "Magnifier"
        Me.PrintPreviewBarItem14.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Magnifier
        Me.PrintPreviewBarItem14.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem14.Enabled = False
        Me.PrintPreviewBarItem14.GroupIndex = 1
        Me.PrintPreviewBarItem14.Id = 14
        Me.PrintPreviewBarItem14.Name = "PrintPreviewBarItem14"
        Me.PrintPreviewBarItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText
        SuperToolTip14.FixedTooltipWidth = True
        ToolTipTitleItem14.Text = "Magnifier"
        ToolTipItem14.LeftIndent = 6
        ToolTipItem14.Text = "Invoke the Magnifier tool." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Clicking once on a document zooms it so that a sing" & _
    "le page becomes entirely visible, while clicking another time zooms it to 100% o" & _
    "f the normal size."
        SuperToolTip14.Items.Add(ToolTipTitleItem14)
        SuperToolTip14.Items.Add(ToolTipItem14)
        SuperToolTip14.MaxWidth = 210
        Me.PrintPreviewBarItem14.SuperTip = SuperToolTip14
        '
        'PrintPreviewBarItem15
        '
        Me.PrintPreviewBarItem15.Caption = "Zoom Out"
        Me.PrintPreviewBarItem15.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomOut
        Me.PrintPreviewBarItem15.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem15.Enabled = False
        Me.PrintPreviewBarItem15.Id = 15
        Me.PrintPreviewBarItem15.Name = "PrintPreviewBarItem15"
        SuperToolTip15.FixedTooltipWidth = True
        ToolTipTitleItem15.Text = "Zoom Out"
        ToolTipItem15.LeftIndent = 6
        ToolTipItem15.Text = "Zoom out to see more of the page at a reduced size."
        SuperToolTip15.Items.Add(ToolTipTitleItem15)
        SuperToolTip15.Items.Add(ToolTipItem15)
        SuperToolTip15.MaxWidth = 210
        Me.PrintPreviewBarItem15.SuperTip = SuperToolTip15
        '
        'PrintPreviewBarItem16
        '
        Me.PrintPreviewBarItem16.Caption = "Zoom In"
        Me.PrintPreviewBarItem16.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomIn
        Me.PrintPreviewBarItem16.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem16.Enabled = False
        Me.PrintPreviewBarItem16.Id = 16
        Me.PrintPreviewBarItem16.Name = "PrintPreviewBarItem16"
        SuperToolTip16.FixedTooltipWidth = True
        ToolTipTitleItem16.Text = "Zoom In"
        ToolTipItem16.LeftIndent = 6
        ToolTipItem16.Text = "Zoom in to get a close-up view of the document."
        SuperToolTip16.Items.Add(ToolTipTitleItem16)
        SuperToolTip16.Items.Add(ToolTipItem16)
        SuperToolTip16.MaxWidth = 210
        Me.PrintPreviewBarItem16.SuperTip = SuperToolTip16
        '
        'PrintPreviewBarItem17
        '
        Me.PrintPreviewBarItem17.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem17.Caption = "Zoom"
        Me.PrintPreviewBarItem17.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Zoom
        Me.PrintPreviewBarItem17.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem17.Enabled = False
        Me.PrintPreviewBarItem17.Id = 17
        Me.PrintPreviewBarItem17.Name = "PrintPreviewBarItem17"
        SuperToolTip17.FixedTooltipWidth = True
        ToolTipTitleItem17.Text = "Zoom"
        ToolTipItem17.LeftIndent = 6
        ToolTipItem17.Text = "Change the zoom level of the document preview."
        SuperToolTip17.Items.Add(ToolTipTitleItem17)
        SuperToolTip17.Items.Add(ToolTipItem17)
        SuperToolTip17.MaxWidth = 210
        Me.PrintPreviewBarItem17.SuperTip = SuperToolTip17
        '
        'PrintPreviewBarItem18
        '
        Me.PrintPreviewBarItem18.Caption = "First Page"
        Me.PrintPreviewBarItem18.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowFirstPage
        Me.PrintPreviewBarItem18.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem18.Enabled = False
        Me.PrintPreviewBarItem18.Id = 18
        Me.PrintPreviewBarItem18.Name = "PrintPreviewBarItem18"
        SuperToolTip18.FixedTooltipWidth = True
        ToolTipTitleItem18.Text = "First Page (Ctrl+Home)"
        ToolTipItem18.LeftIndent = 6
        ToolTipItem18.Text = "Navigate to the first page of the document."
        SuperToolTip18.Items.Add(ToolTipTitleItem18)
        SuperToolTip18.Items.Add(ToolTipItem18)
        SuperToolTip18.MaxWidth = 210
        Me.PrintPreviewBarItem18.SuperTip = SuperToolTip18
        '
        'PrintPreviewBarItem19
        '
        Me.PrintPreviewBarItem19.Caption = "Previous Page"
        Me.PrintPreviewBarItem19.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowPrevPage
        Me.PrintPreviewBarItem19.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem19.Enabled = False
        Me.PrintPreviewBarItem19.Id = 19
        Me.PrintPreviewBarItem19.Name = "PrintPreviewBarItem19"
        SuperToolTip19.FixedTooltipWidth = True
        ToolTipTitleItem19.Text = "Previous Page (PageUp)"
        ToolTipItem19.LeftIndent = 6
        ToolTipItem19.Text = "Navigate to the previous page of the document."
        SuperToolTip19.Items.Add(ToolTipTitleItem19)
        SuperToolTip19.Items.Add(ToolTipItem19)
        SuperToolTip19.MaxWidth = 210
        Me.PrintPreviewBarItem19.SuperTip = SuperToolTip19
        '
        'PrintPreviewBarItem20
        '
        Me.PrintPreviewBarItem20.Caption = "Next  Page "
        Me.PrintPreviewBarItem20.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowNextPage
        Me.PrintPreviewBarItem20.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem20.Enabled = False
        Me.PrintPreviewBarItem20.Id = 20
        Me.PrintPreviewBarItem20.Name = "PrintPreviewBarItem20"
        SuperToolTip20.FixedTooltipWidth = True
        ToolTipTitleItem20.Text = "Next Page (PageDown)"
        ToolTipItem20.LeftIndent = 6
        ToolTipItem20.Text = "Navigate to the next page of the document."
        SuperToolTip20.Items.Add(ToolTipTitleItem20)
        SuperToolTip20.Items.Add(ToolTipItem20)
        SuperToolTip20.MaxWidth = 210
        Me.PrintPreviewBarItem20.SuperTip = SuperToolTip20
        '
        'PrintPreviewBarItem21
        '
        Me.PrintPreviewBarItem21.Caption = "Last  Page "
        Me.PrintPreviewBarItem21.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowLastPage
        Me.PrintPreviewBarItem21.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem21.Enabled = False
        Me.PrintPreviewBarItem21.Id = 21
        Me.PrintPreviewBarItem21.Name = "PrintPreviewBarItem21"
        SuperToolTip21.FixedTooltipWidth = True
        ToolTipTitleItem21.Text = "Last Page (Ctrl+End)"
        ToolTipItem21.LeftIndent = 6
        ToolTipItem21.Text = "Navigate to the last page of the document."
        SuperToolTip21.Items.Add(ToolTipTitleItem21)
        SuperToolTip21.Items.Add(ToolTipItem21)
        SuperToolTip21.MaxWidth = 210
        Me.PrintPreviewBarItem21.SuperTip = SuperToolTip21
        '
        'PrintPreviewBarItem22
        '
        Me.PrintPreviewBarItem22.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem22.Caption = "Many Pages"
        Me.PrintPreviewBarItem22.Command = DevExpress.XtraPrinting.PrintingSystemCommand.MultiplePages
        Me.PrintPreviewBarItem22.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem22.Enabled = False
        Me.PrintPreviewBarItem22.Id = 22
        Me.PrintPreviewBarItem22.Name = "PrintPreviewBarItem22"
        SuperToolTip22.FixedTooltipWidth = True
        ToolTipTitleItem22.Text = "View Many Pages"
        ToolTipItem22.LeftIndent = 6
        ToolTipItem22.Text = "Choose the page layout to arrange the document pages in preview."
        SuperToolTip22.Items.Add(ToolTipTitleItem22)
        SuperToolTip22.Items.Add(ToolTipItem22)
        SuperToolTip22.MaxWidth = 210
        Me.PrintPreviewBarItem22.SuperTip = SuperToolTip22
        '
        'PrintPreviewBarItem23
        '
        Me.PrintPreviewBarItem23.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem23.Caption = "Page Color"
        Me.PrintPreviewBarItem23.Command = DevExpress.XtraPrinting.PrintingSystemCommand.FillBackground
        Me.PrintPreviewBarItem23.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem23.Enabled = False
        Me.PrintPreviewBarItem23.Id = 23
        Me.PrintPreviewBarItem23.Name = "PrintPreviewBarItem23"
        SuperToolTip23.FixedTooltipWidth = True
        ToolTipTitleItem23.Text = "Background Color"
        ToolTipItem23.LeftIndent = 6
        ToolTipItem23.Text = "Choose a color for the background of the document pages."
        SuperToolTip23.Items.Add(ToolTipTitleItem23)
        SuperToolTip23.Items.Add(ToolTipItem23)
        SuperToolTip23.MaxWidth = 210
        Me.PrintPreviewBarItem23.SuperTip = SuperToolTip23
        '
        'PrintPreviewBarItem24
        '
        Me.PrintPreviewBarItem24.Caption = "Watermark"
        Me.PrintPreviewBarItem24.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Watermark
        Me.PrintPreviewBarItem24.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem24.Enabled = False
        Me.PrintPreviewBarItem24.Id = 24
        Me.PrintPreviewBarItem24.Name = "PrintPreviewBarItem24"
        SuperToolTip24.FixedTooltipWidth = True
        ToolTipTitleItem24.Text = "Watermark"
        ToolTipItem24.LeftIndent = 6
        ToolTipItem24.Text = "Insert ghosted text or image behind the content of a page." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "This is often used " & _
    "to indicate that a document is to be treated specially."
        SuperToolTip24.Items.Add(ToolTipTitleItem24)
        SuperToolTip24.Items.Add(ToolTipItem24)
        SuperToolTip24.MaxWidth = 210
        Me.PrintPreviewBarItem24.SuperTip = SuperToolTip24
        '
        'PrintPreviewBarItem25
        '
        Me.PrintPreviewBarItem25.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem25.Caption = "Export To"
        Me.PrintPreviewBarItem25.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportFile
        Me.PrintPreviewBarItem25.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem25.Enabled = False
        Me.PrintPreviewBarItem25.Id = 25
        Me.PrintPreviewBarItem25.Name = "PrintPreviewBarItem25"
        SuperToolTip25.FixedTooltipWidth = True
        ToolTipTitleItem25.Text = "Export To..."
        ToolTipItem25.LeftIndent = 6
        ToolTipItem25.Text = "Export the current document in one of the available formats, and save it to the f" & _
    "ile on a disk."
        SuperToolTip25.Items.Add(ToolTipTitleItem25)
        SuperToolTip25.Items.Add(ToolTipItem25)
        SuperToolTip25.MaxWidth = 210
        Me.PrintPreviewBarItem25.SuperTip = SuperToolTip25
        '
        'PrintPreviewBarItem26
        '
        Me.PrintPreviewBarItem26.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem26.Caption = "E-Mail As"
        Me.PrintPreviewBarItem26.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendFile
        Me.PrintPreviewBarItem26.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem26.Enabled = False
        Me.PrintPreviewBarItem26.Id = 26
        Me.PrintPreviewBarItem26.Name = "PrintPreviewBarItem26"
        SuperToolTip26.FixedTooltipWidth = True
        ToolTipTitleItem26.Text = "E-Mail As..."
        ToolTipItem26.LeftIndent = 6
        ToolTipItem26.Text = "Export the current document in one of the available formats, and attach it to the" & _
    " e-mail."
        SuperToolTip26.Items.Add(ToolTipTitleItem26)
        SuperToolTip26.Items.Add(ToolTipItem26)
        SuperToolTip26.MaxWidth = 210
        Me.PrintPreviewBarItem26.SuperTip = SuperToolTip26
        '
        'PrintPreviewBarItem27
        '
        Me.PrintPreviewBarItem27.Caption = "Close"
        Me.PrintPreviewBarItem27.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ClosePreview
        Me.PrintPreviewBarItem27.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem27.Enabled = False
        Me.PrintPreviewBarItem27.Id = 27
        Me.PrintPreviewBarItem27.Name = "PrintPreviewBarItem27"
        SuperToolTip27.FixedTooltipWidth = True
        ToolTipTitleItem27.Text = "Close Print Preview"
        ToolTipItem27.LeftIndent = 6
        ToolTipItem27.Text = "Close Print Preview of the document."
        SuperToolTip27.Items.Add(ToolTipTitleItem27)
        SuperToolTip27.Items.Add(ToolTipItem27)
        SuperToolTip27.MaxWidth = 210
        Me.PrintPreviewBarItem27.SuperTip = SuperToolTip27
        '
        'PrintPreviewBarItem28
        '
        Me.PrintPreviewBarItem28.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem28.Caption = "Orientation"
        Me.PrintPreviewBarItem28.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageOrientation
        Me.PrintPreviewBarItem28.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem28.Enabled = False
        Me.PrintPreviewBarItem28.Id = 28
        Me.PrintPreviewBarItem28.Name = "PrintPreviewBarItem28"
        SuperToolTip28.FixedTooltipWidth = True
        ToolTipTitleItem28.Text = "Page Orientation"
        ToolTipItem28.LeftIndent = 6
        ToolTipItem28.Text = "Switch the pages between portrait and landscape layouts."
        SuperToolTip28.Items.Add(ToolTipTitleItem28)
        SuperToolTip28.Items.Add(ToolTipItem28)
        SuperToolTip28.MaxWidth = 210
        Me.PrintPreviewBarItem28.SuperTip = SuperToolTip28
        '
        'PrintPreviewBarItem29
        '
        Me.PrintPreviewBarItem29.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem29.Caption = "Size"
        Me.PrintPreviewBarItem29.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PaperSize
        Me.PrintPreviewBarItem29.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem29.Enabled = False
        Me.PrintPreviewBarItem29.Id = 29
        Me.PrintPreviewBarItem29.Name = "PrintPreviewBarItem29"
        SuperToolTip29.FixedTooltipWidth = True
        ToolTipTitleItem29.Text = "Page Size"
        ToolTipItem29.LeftIndent = 6
        ToolTipItem29.Text = "Choose the paper size of the document."
        SuperToolTip29.Items.Add(ToolTipTitleItem29)
        SuperToolTip29.Items.Add(ToolTipItem29)
        SuperToolTip29.MaxWidth = 210
        Me.PrintPreviewBarItem29.SuperTip = SuperToolTip29
        '
        'PrintPreviewBarItem30
        '
        Me.PrintPreviewBarItem30.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown
        Me.PrintPreviewBarItem30.Caption = "Margins"
        Me.PrintPreviewBarItem30.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageMargins
        Me.PrintPreviewBarItem30.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem30.Enabled = False
        Me.PrintPreviewBarItem30.Id = 30
        Me.PrintPreviewBarItem30.Name = "PrintPreviewBarItem30"
        SuperToolTip30.FixedTooltipWidth = True
        ToolTipTitleItem30.Text = "Page Margins"
        ToolTipItem30.LeftIndent = 6
        ToolTipItem30.Text = "Select the margin sizes for the entire document." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "To apply specific margin size" & _
    "s to the document, click Custom Margins."
        SuperToolTip30.Items.Add(ToolTipTitleItem30)
        SuperToolTip30.Items.Add(ToolTipItem30)
        SuperToolTip30.MaxWidth = 210
        Me.PrintPreviewBarItem30.SuperTip = SuperToolTip30
        '
        'PrintPreviewBarItem31
        '
        Me.PrintPreviewBarItem31.Caption = "PDF File"
        Me.PrintPreviewBarItem31.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendPdf
        Me.PrintPreviewBarItem31.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem31.Description = "Adobe Portable Document Format"
        Me.PrintPreviewBarItem31.Enabled = False
        Me.PrintPreviewBarItem31.Id = 31
        Me.PrintPreviewBarItem31.Name = "PrintPreviewBarItem31"
        SuperToolTip31.FixedTooltipWidth = True
        ToolTipTitleItem31.Text = "E-Mail As PDF"
        ToolTipItem31.LeftIndent = 6
        ToolTipItem31.Text = "Export the document to PDF and attach it to the e-mail."
        SuperToolTip31.Items.Add(ToolTipTitleItem31)
        SuperToolTip31.Items.Add(ToolTipItem31)
        SuperToolTip31.MaxWidth = 210
        Me.PrintPreviewBarItem31.SuperTip = SuperToolTip31
        '
        'PrintPreviewBarItem32
        '
        Me.PrintPreviewBarItem32.Caption = "Text File"
        Me.PrintPreviewBarItem32.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendTxt
        Me.PrintPreviewBarItem32.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem32.Description = "Plain Text"
        Me.PrintPreviewBarItem32.Enabled = False
        Me.PrintPreviewBarItem32.Id = 32
        Me.PrintPreviewBarItem32.Name = "PrintPreviewBarItem32"
        SuperToolTip32.FixedTooltipWidth = True
        ToolTipTitleItem32.Text = "E-Mail As Text"
        ToolTipItem32.LeftIndent = 6
        ToolTipItem32.Text = "Export the document to Text and attach it to the e-mail."
        SuperToolTip32.Items.Add(ToolTipTitleItem32)
        SuperToolTip32.Items.Add(ToolTipItem32)
        SuperToolTip32.MaxWidth = 210
        Me.PrintPreviewBarItem32.SuperTip = SuperToolTip32
        '
        'PrintPreviewBarItem33
        '
        Me.PrintPreviewBarItem33.Caption = "CSV File"
        Me.PrintPreviewBarItem33.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendCsv
        Me.PrintPreviewBarItem33.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem33.Description = "Comma-Separated Values Text"
        Me.PrintPreviewBarItem33.Enabled = False
        Me.PrintPreviewBarItem33.Id = 33
        Me.PrintPreviewBarItem33.Name = "PrintPreviewBarItem33"
        SuperToolTip33.FixedTooltipWidth = True
        ToolTipTitleItem33.Text = "E-Mail As CSV"
        ToolTipItem33.LeftIndent = 6
        ToolTipItem33.Text = "Export the document to CSV and attach it to the e-mail."
        SuperToolTip33.Items.Add(ToolTipTitleItem33)
        SuperToolTip33.Items.Add(ToolTipItem33)
        SuperToolTip33.MaxWidth = 210
        Me.PrintPreviewBarItem33.SuperTip = SuperToolTip33
        '
        'PrintPreviewBarItem34
        '
        Me.PrintPreviewBarItem34.Caption = "MHT File"
        Me.PrintPreviewBarItem34.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendMht
        Me.PrintPreviewBarItem34.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem34.Description = "Single File Web Page"
        Me.PrintPreviewBarItem34.Enabled = False
        Me.PrintPreviewBarItem34.Id = 34
        Me.PrintPreviewBarItem34.Name = "PrintPreviewBarItem34"
        SuperToolTip34.FixedTooltipWidth = True
        ToolTipTitleItem34.Text = "E-Mail As MHT"
        ToolTipItem34.LeftIndent = 6
        ToolTipItem34.Text = "Export the document to MHT and attach it to the e-mail."
        SuperToolTip34.Items.Add(ToolTipTitleItem34)
        SuperToolTip34.Items.Add(ToolTipItem34)
        SuperToolTip34.MaxWidth = 210
        Me.PrintPreviewBarItem34.SuperTip = SuperToolTip34
        '
        'PrintPreviewBarItem35
        '
        Me.PrintPreviewBarItem35.Caption = "XLS File"
        Me.PrintPreviewBarItem35.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXls
        Me.PrintPreviewBarItem35.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem35.Description = "Microsoft Excel 2000-2003 Workbook"
        Me.PrintPreviewBarItem35.Enabled = False
        Me.PrintPreviewBarItem35.Id = 35
        Me.PrintPreviewBarItem35.Name = "PrintPreviewBarItem35"
        SuperToolTip35.FixedTooltipWidth = True
        ToolTipTitleItem35.Text = "E-Mail As XLS"
        ToolTipItem35.LeftIndent = 6
        ToolTipItem35.Text = "Export the document to XLS and attach it to the e-mail."
        SuperToolTip35.Items.Add(ToolTipTitleItem35)
        SuperToolTip35.Items.Add(ToolTipItem35)
        SuperToolTip35.MaxWidth = 210
        Me.PrintPreviewBarItem35.SuperTip = SuperToolTip35
        '
        'PrintPreviewBarItem36
        '
        Me.PrintPreviewBarItem36.Caption = "XLSX File"
        Me.PrintPreviewBarItem36.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXlsx
        Me.PrintPreviewBarItem36.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem36.Description = "Microsoft Excel 2007 Workbook"
        Me.PrintPreviewBarItem36.Enabled = False
        Me.PrintPreviewBarItem36.Id = 36
        Me.PrintPreviewBarItem36.Name = "PrintPreviewBarItem36"
        SuperToolTip36.FixedTooltipWidth = True
        ToolTipTitleItem36.Text = "E-Mail As XLSX"
        ToolTipItem36.LeftIndent = 6
        ToolTipItem36.Text = "Export the document to XLSX and attach it to the e-mail."
        SuperToolTip36.Items.Add(ToolTipTitleItem36)
        SuperToolTip36.Items.Add(ToolTipItem36)
        SuperToolTip36.MaxWidth = 210
        Me.PrintPreviewBarItem36.SuperTip = SuperToolTip36
        '
        'PrintPreviewBarItem37
        '
        Me.PrintPreviewBarItem37.Caption = "RTF File"
        Me.PrintPreviewBarItem37.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendRtf
        Me.PrintPreviewBarItem37.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem37.Description = "Rich Text Format"
        Me.PrintPreviewBarItem37.Enabled = False
        Me.PrintPreviewBarItem37.Id = 37
        Me.PrintPreviewBarItem37.Name = "PrintPreviewBarItem37"
        SuperToolTip37.FixedTooltipWidth = True
        ToolTipTitleItem37.Text = "E-Mail As RTF"
        ToolTipItem37.LeftIndent = 6
        ToolTipItem37.Text = "Export the document to RTF and attach it to the e-mail."
        SuperToolTip37.Items.Add(ToolTipTitleItem37)
        SuperToolTip37.Items.Add(ToolTipItem37)
        SuperToolTip37.MaxWidth = 210
        Me.PrintPreviewBarItem37.SuperTip = SuperToolTip37
        '
        'PrintPreviewBarItem38
        '
        Me.PrintPreviewBarItem38.Caption = "DOCX File"
        Me.PrintPreviewBarItem38.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendDocx
        Me.PrintPreviewBarItem38.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem38.Description = "Microsoft Word 2007 Document"
        Me.PrintPreviewBarItem38.Enabled = False
        Me.PrintPreviewBarItem38.Id = 38
        Me.PrintPreviewBarItem38.Name = "PrintPreviewBarItem38"
        SuperToolTip38.FixedTooltipWidth = True
        ToolTipTitleItem38.Text = "E-Mail As DOCX"
        ToolTipItem38.LeftIndent = 6
        ToolTipItem38.Text = "Export the document to DOCX and attach it to the e-mail."
        SuperToolTip38.Items.Add(ToolTipTitleItem38)
        SuperToolTip38.Items.Add(ToolTipItem38)
        SuperToolTip38.MaxWidth = 210
        Me.PrintPreviewBarItem38.SuperTip = SuperToolTip38
        '
        'PrintPreviewBarItem39
        '
        Me.PrintPreviewBarItem39.Caption = "Image File"
        Me.PrintPreviewBarItem39.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendGraphic
        Me.PrintPreviewBarItem39.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem39.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF"
        Me.PrintPreviewBarItem39.Enabled = False
        Me.PrintPreviewBarItem39.Id = 39
        Me.PrintPreviewBarItem39.Name = "PrintPreviewBarItem39"
        SuperToolTip39.FixedTooltipWidth = True
        ToolTipTitleItem39.Text = "E-Mail As Image"
        ToolTipItem39.LeftIndent = 6
        ToolTipItem39.Text = "Export the document to Image and attach it to the e-mail."
        SuperToolTip39.Items.Add(ToolTipTitleItem39)
        SuperToolTip39.Items.Add(ToolTipItem39)
        SuperToolTip39.MaxWidth = 210
        Me.PrintPreviewBarItem39.SuperTip = SuperToolTip39
        '
        'PrintPreviewBarItem40
        '
        Me.PrintPreviewBarItem40.Caption = "PDF File"
        Me.PrintPreviewBarItem40.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportPdf
        Me.PrintPreviewBarItem40.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem40.Description = "Adobe Portable Document Format"
        Me.PrintPreviewBarItem40.Enabled = False
        Me.PrintPreviewBarItem40.Id = 40
        Me.PrintPreviewBarItem40.Name = "PrintPreviewBarItem40"
        SuperToolTip40.FixedTooltipWidth = True
        ToolTipTitleItem40.Text = "Export to PDF"
        ToolTipItem40.LeftIndent = 6
        ToolTipItem40.Text = "Export the document to PDF and save it to the file on a disk."
        SuperToolTip40.Items.Add(ToolTipTitleItem40)
        SuperToolTip40.Items.Add(ToolTipItem40)
        SuperToolTip40.MaxWidth = 210
        Me.PrintPreviewBarItem40.SuperTip = SuperToolTip40
        '
        'PrintPreviewBarItem41
        '
        Me.PrintPreviewBarItem41.Caption = "HTML File"
        Me.PrintPreviewBarItem41.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportHtm
        Me.PrintPreviewBarItem41.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem41.Description = "Web Page"
        Me.PrintPreviewBarItem41.Enabled = False
        Me.PrintPreviewBarItem41.Id = 41
        Me.PrintPreviewBarItem41.Name = "PrintPreviewBarItem41"
        SuperToolTip41.FixedTooltipWidth = True
        ToolTipTitleItem41.Text = "Export to HTML"
        ToolTipItem41.LeftIndent = 6
        ToolTipItem41.Text = "Export the document to HTML and save it to the file on a disk."
        SuperToolTip41.Items.Add(ToolTipTitleItem41)
        SuperToolTip41.Items.Add(ToolTipItem41)
        SuperToolTip41.MaxWidth = 210
        Me.PrintPreviewBarItem41.SuperTip = SuperToolTip41
        '
        'PrintPreviewBarItem42
        '
        Me.PrintPreviewBarItem42.Caption = "Text File"
        Me.PrintPreviewBarItem42.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportTxt
        Me.PrintPreviewBarItem42.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem42.Description = "Plain Text"
        Me.PrintPreviewBarItem42.Enabled = False
        Me.PrintPreviewBarItem42.Id = 42
        Me.PrintPreviewBarItem42.Name = "PrintPreviewBarItem42"
        SuperToolTip42.FixedTooltipWidth = True
        ToolTipTitleItem42.Text = "Export to Text"
        ToolTipItem42.LeftIndent = 6
        ToolTipItem42.Text = "Export the document to Text and save it to the file on a disk."
        SuperToolTip42.Items.Add(ToolTipTitleItem42)
        SuperToolTip42.Items.Add(ToolTipItem42)
        SuperToolTip42.MaxWidth = 210
        Me.PrintPreviewBarItem42.SuperTip = SuperToolTip42
        '
        'PrintPreviewBarItem43
        '
        Me.PrintPreviewBarItem43.Caption = "CSV File"
        Me.PrintPreviewBarItem43.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportCsv
        Me.PrintPreviewBarItem43.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem43.Description = "Comma-Separated Values Text"
        Me.PrintPreviewBarItem43.Enabled = False
        Me.PrintPreviewBarItem43.Id = 43
        Me.PrintPreviewBarItem43.Name = "PrintPreviewBarItem43"
        SuperToolTip43.FixedTooltipWidth = True
        ToolTipTitleItem43.Text = "Export to CSV"
        ToolTipItem43.LeftIndent = 6
        ToolTipItem43.Text = "Export the document to CSV and save it to the file on a disk."
        SuperToolTip43.Items.Add(ToolTipTitleItem43)
        SuperToolTip43.Items.Add(ToolTipItem43)
        SuperToolTip43.MaxWidth = 210
        Me.PrintPreviewBarItem43.SuperTip = SuperToolTip43
        '
        'PrintPreviewBarItem44
        '
        Me.PrintPreviewBarItem44.Caption = "MHT File"
        Me.PrintPreviewBarItem44.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportMht
        Me.PrintPreviewBarItem44.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem44.Description = "Single File Web Page"
        Me.PrintPreviewBarItem44.Enabled = False
        Me.PrintPreviewBarItem44.Id = 44
        Me.PrintPreviewBarItem44.Name = "PrintPreviewBarItem44"
        SuperToolTip44.FixedTooltipWidth = True
        ToolTipTitleItem44.Text = "Export to MHT"
        ToolTipItem44.LeftIndent = 6
        ToolTipItem44.Text = "Export the document to MHT and save it to the file on a disk."
        SuperToolTip44.Items.Add(ToolTipTitleItem44)
        SuperToolTip44.Items.Add(ToolTipItem44)
        SuperToolTip44.MaxWidth = 210
        Me.PrintPreviewBarItem44.SuperTip = SuperToolTip44
        '
        'PrintPreviewBarItem45
        '
        Me.PrintPreviewBarItem45.Caption = "XLS File"
        Me.PrintPreviewBarItem45.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXls
        Me.PrintPreviewBarItem45.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem45.Description = "Microsoft Excel 2000-2003 Workbook"
        Me.PrintPreviewBarItem45.Enabled = False
        Me.PrintPreviewBarItem45.Id = 45
        Me.PrintPreviewBarItem45.Name = "PrintPreviewBarItem45"
        SuperToolTip45.FixedTooltipWidth = True
        ToolTipTitleItem45.Text = "Export to XLS"
        ToolTipItem45.LeftIndent = 6
        ToolTipItem45.Text = "Export the document to XLS and save it to the file on a disk."
        SuperToolTip45.Items.Add(ToolTipTitleItem45)
        SuperToolTip45.Items.Add(ToolTipItem45)
        SuperToolTip45.MaxWidth = 210
        Me.PrintPreviewBarItem45.SuperTip = SuperToolTip45
        '
        'PrintPreviewBarItem46
        '
        Me.PrintPreviewBarItem46.Caption = "XLSX File"
        Me.PrintPreviewBarItem46.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXlsx
        Me.PrintPreviewBarItem46.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem46.Description = "Microsoft Excel 2007 Workbook"
        Me.PrintPreviewBarItem46.Enabled = False
        Me.PrintPreviewBarItem46.Id = 46
        Me.PrintPreviewBarItem46.Name = "PrintPreviewBarItem46"
        SuperToolTip46.FixedTooltipWidth = True
        ToolTipTitleItem46.Text = "Export to XLSX"
        ToolTipItem46.LeftIndent = 6
        ToolTipItem46.Text = "Export the document to XLSX and save it to the file on a disk."
        SuperToolTip46.Items.Add(ToolTipTitleItem46)
        SuperToolTip46.Items.Add(ToolTipItem46)
        SuperToolTip46.MaxWidth = 210
        Me.PrintPreviewBarItem46.SuperTip = SuperToolTip46
        '
        'PrintPreviewBarItem47
        '
        Me.PrintPreviewBarItem47.Caption = "RTF File"
        Me.PrintPreviewBarItem47.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportRtf
        Me.PrintPreviewBarItem47.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem47.Description = "Rich Text Format"
        Me.PrintPreviewBarItem47.Enabled = False
        Me.PrintPreviewBarItem47.Id = 47
        Me.PrintPreviewBarItem47.Name = "PrintPreviewBarItem47"
        SuperToolTip47.FixedTooltipWidth = True
        ToolTipTitleItem47.Text = "Export to RTF"
        ToolTipItem47.LeftIndent = 6
        ToolTipItem47.Text = "Export the document to RTF and save it to the file on a disk."
        SuperToolTip47.Items.Add(ToolTipTitleItem47)
        SuperToolTip47.Items.Add(ToolTipItem47)
        SuperToolTip47.MaxWidth = 210
        Me.PrintPreviewBarItem47.SuperTip = SuperToolTip47
        '
        'PrintPreviewBarItem48
        '
        Me.PrintPreviewBarItem48.Caption = "DOCX File"
        Me.PrintPreviewBarItem48.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportDocx
        Me.PrintPreviewBarItem48.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem48.Description = "Microsoft Word 2007 Document"
        Me.PrintPreviewBarItem48.Enabled = False
        Me.PrintPreviewBarItem48.Id = 48
        Me.PrintPreviewBarItem48.Name = "PrintPreviewBarItem48"
        SuperToolTip48.FixedTooltipWidth = True
        ToolTipTitleItem48.Text = "Export to DOCX"
        ToolTipItem48.LeftIndent = 6
        ToolTipItem48.Text = "Export the document to DOCX and save it to the file on a disk."
        SuperToolTip48.Items.Add(ToolTipTitleItem48)
        SuperToolTip48.Items.Add(ToolTipItem48)
        SuperToolTip48.MaxWidth = 210
        Me.PrintPreviewBarItem48.SuperTip = SuperToolTip48
        '
        'PrintPreviewBarItem49
        '
        Me.PrintPreviewBarItem49.Caption = "Image File"
        Me.PrintPreviewBarItem49.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportGraphic
        Me.PrintPreviewBarItem49.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem49.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF"
        Me.PrintPreviewBarItem49.Enabled = False
        Me.PrintPreviewBarItem49.Id = 49
        Me.PrintPreviewBarItem49.Name = "PrintPreviewBarItem49"
        SuperToolTip49.FixedTooltipWidth = True
        ToolTipTitleItem49.Text = "Export to Image"
        ToolTipItem49.LeftIndent = 6
        ToolTipItem49.Text = "Export the document to Image and save it to the file on a disk."
        SuperToolTip49.Items.Add(ToolTipTitleItem49)
        SuperToolTip49.Items.Add(ToolTipItem49)
        SuperToolTip49.MaxWidth = 210
        Me.PrintPreviewBarItem49.SuperTip = SuperToolTip49
        '
        'PrintPreviewBarItem50
        '
        Me.PrintPreviewBarItem50.Caption = "Open"
        Me.PrintPreviewBarItem50.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Open
        Me.PrintPreviewBarItem50.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem50.Enabled = False
        Me.PrintPreviewBarItem50.Id = 50
        Me.PrintPreviewBarItem50.Name = "PrintPreviewBarItem50"
        SuperToolTip50.FixedTooltipWidth = True
        ToolTipTitleItem50.Text = "Open (Ctrl + O)"
        ToolTipItem50.LeftIndent = 6
        ToolTipItem50.Text = "Open a document."
        SuperToolTip50.Items.Add(ToolTipTitleItem50)
        SuperToolTip50.Items.Add(ToolTipItem50)
        SuperToolTip50.MaxWidth = 210
        Me.PrintPreviewBarItem50.SuperTip = SuperToolTip50
        '
        'PrintPreviewBarItem51
        '
        Me.PrintPreviewBarItem51.Caption = "Save"
        Me.PrintPreviewBarItem51.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Save
        Me.PrintPreviewBarItem51.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem51.Enabled = False
        Me.PrintPreviewBarItem51.Id = 51
        Me.PrintPreviewBarItem51.Name = "PrintPreviewBarItem51"
        SuperToolTip51.FixedTooltipWidth = True
        ToolTipTitleItem51.Text = "Save (Ctrl + S)"
        ToolTipItem51.LeftIndent = 6
        ToolTipItem51.Text = "Save the document."
        SuperToolTip51.Items.Add(ToolTipTitleItem51)
        SuperToolTip51.Items.Add(ToolTipItem51)
        SuperToolTip51.MaxWidth = 210
        Me.PrintPreviewBarItem51.SuperTip = SuperToolTip51
        '
        'PrintPreviewStaticItem1
        '
        Me.PrintPreviewStaticItem1.Caption = "Nothing"
        Me.PrintPreviewStaticItem1.Id = 52
        Me.PrintPreviewStaticItem1.LeftIndent = 1
        Me.PrintPreviewStaticItem1.Name = "PrintPreviewStaticItem1"
        Me.PrintPreviewStaticItem1.RightIndent = 1
        Me.PrintPreviewStaticItem1.Type = "PageOfPages"
        '
        'BarStaticItem1
        '
        Me.BarStaticItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
        Me.BarStaticItem1.Enabled = False
        Me.BarStaticItem1.Id = 53
        Me.BarStaticItem1.Name = "BarStaticItem1"
        Me.BarStaticItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.OnlyInRuntime
        '
        'ProgressBarEditItem1
        '
        Me.ProgressBarEditItem1.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.ProgressBarEditItem1.Edit = Me.RepositoryItemProgressBar1
        Me.ProgressBarEditItem1.EditHeight = 12
        Me.ProgressBarEditItem1.EditWidth = 150
        Me.ProgressBarEditItem1.Id = 54
        Me.ProgressBarEditItem1.Name = "ProgressBarEditItem1"
        Me.ProgressBarEditItem1.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
        '
        'RepositoryItemProgressBar1
        '
        Me.RepositoryItemProgressBar1.Name = "RepositoryItemProgressBar1"
        '
        'PrintPreviewBarItem52
        '
        Me.PrintPreviewBarItem52.Caption = "Stop"
        Me.PrintPreviewBarItem52.Command = DevExpress.XtraPrinting.PrintingSystemCommand.StopPageBuilding
        Me.PrintPreviewBarItem52.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewBarItem52.Enabled = False
        Me.PrintPreviewBarItem52.Hint = "Stop"
        Me.PrintPreviewBarItem52.Id = 55
        Me.PrintPreviewBarItem52.Name = "PrintPreviewBarItem52"
        Me.PrintPreviewBarItem52.Visibility = DevExpress.XtraBars.BarItemVisibility.Never
        '
        'PrintPreviewStaticItem2
        '
        Me.PrintPreviewStaticItem2.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.PrintPreviewStaticItem2.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None
        Me.PrintPreviewStaticItem2.Caption = "100%"
        Me.PrintPreviewStaticItem2.Id = 56
        Me.PrintPreviewStaticItem2.Name = "PrintPreviewStaticItem2"
        Me.PrintPreviewStaticItem2.Type = "ZoomFactorText"
        '
        'ZoomTrackBarEditItem1
        '
        Me.ZoomTrackBarEditItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.ZoomTrackBarEditItem1.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.ZoomTrackBarEditItem1.Edit = Me.RepositoryItemZoomTrackBar1
        Me.ZoomTrackBarEditItem1.EditValue = 90
        Me.ZoomTrackBarEditItem1.EditWidth = 140
        Me.ZoomTrackBarEditItem1.Enabled = False
        Me.ZoomTrackBarEditItem1.Id = 57
        Me.ZoomTrackBarEditItem1.Name = "ZoomTrackBarEditItem1"
        Me.ZoomTrackBarEditItem1.Range = New Integer() {10, 500}
        '
        'RepositoryItemZoomTrackBar1
        '
        Me.RepositoryItemZoomTrackBar1.Alignment = DevExpress.Utils.VertAlignment.Center
        Me.RepositoryItemZoomTrackBar1.AllowFocused = False
        Me.RepositoryItemZoomTrackBar1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.RepositoryItemZoomTrackBar1.Maximum = 180
        Me.RepositoryItemZoomTrackBar1.Name = "RepositoryItemZoomTrackBar1"
        '
        'RibbonPage1
        '
        Me.RibbonPage1.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.RibbonPage1.Groups.AddRange(New DevExpress.XtraBars.Ribbon.RibbonPageGroup() {Me.PrintPreviewRibbonPageGroup1, Me.PrintPreviewRibbonPageGroup2, Me.PrintPreviewRibbonPageGroup3, Me.PrintPreviewRibbonPageGroup4, Me.PrintPreviewRibbonPageGroup5, Me.PrintPreviewRibbonPageGroup6, Me.PrintPreviewRibbonPageGroup7, Me.PrintPreviewRibbonPageGroup8})
        Me.RibbonPage1.Name = "RibbonPage1"
        Me.RibbonPage1.Text = "Print Preview"
        '
        'PrintPreviewRibbonPageGroup1
        '
        Me.PrintPreviewRibbonPageGroup1.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup1.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup1.ItemLinks.Add(Me.PrintPreviewBarItem50)
        Me.PrintPreviewRibbonPageGroup1.ItemLinks.Add(Me.PrintPreviewBarItem51)
        Me.PrintPreviewRibbonPageGroup1.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Document
        Me.PrintPreviewRibbonPageGroup1.Name = "PrintPreviewRibbonPageGroup1"
        Me.PrintPreviewRibbonPageGroup1.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup1.Text = "Document"
        '
        'PrintPreviewRibbonPageGroup2
        '
        Me.PrintPreviewRibbonPageGroup2.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup2.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup2.ItemLinks.Add(Me.PrintPreviewBarItem7)
        Me.PrintPreviewRibbonPageGroup2.ItemLinks.Add(Me.PrintPreviewBarItem8)
        Me.PrintPreviewRibbonPageGroup2.ItemLinks.Add(Me.PrintPreviewBarItem6)
        Me.PrintPreviewRibbonPageGroup2.ItemLinks.Add(Me.PrintPreviewBarItem3)
        Me.PrintPreviewRibbonPageGroup2.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Print
        Me.PrintPreviewRibbonPageGroup2.Name = "PrintPreviewRibbonPageGroup2"
        Me.PrintPreviewRibbonPageGroup2.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup2.Text = "Print"
        '
        'PrintPreviewRibbonPageGroup3
        '
        Me.PrintPreviewRibbonPageGroup3.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup3.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup3.ItemLinks.Add(Me.PrintPreviewBarItem10)
        Me.PrintPreviewRibbonPageGroup3.ItemLinks.Add(Me.PrintPreviewBarItem11)
        Me.PrintPreviewRibbonPageGroup3.ItemLinks.Add(Me.PrintPreviewBarItem30)
        Me.PrintPreviewRibbonPageGroup3.ItemLinks.Add(Me.PrintPreviewBarItem28)
        Me.PrintPreviewRibbonPageGroup3.ItemLinks.Add(Me.PrintPreviewBarItem29)
        Me.PrintPreviewRibbonPageGroup3.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.PageSetup
        Me.PrintPreviewRibbonPageGroup3.Name = "PrintPreviewRibbonPageGroup3"
        SuperToolTip52.FixedTooltipWidth = True
        ToolTipTitleItem52.Text = "Page Setup"
        ToolTipItem52.LeftIndent = 6
        ToolTipItem52.Text = "Show the Page Setup dialog."
        SuperToolTip52.Items.Add(ToolTipTitleItem52)
        SuperToolTip52.Items.Add(ToolTipItem52)
        SuperToolTip52.MaxWidth = 210
        Me.PrintPreviewRibbonPageGroup3.SuperTip = SuperToolTip52
        Me.PrintPreviewRibbonPageGroup3.Text = "Page Setup"
        '
        'PrintPreviewRibbonPageGroup4
        '
        Me.PrintPreviewRibbonPageGroup4.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup4.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem4)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem5)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem2)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem1)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem18, True)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem19)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem20)
        Me.PrintPreviewRibbonPageGroup4.ItemLinks.Add(Me.PrintPreviewBarItem21)
        Me.PrintPreviewRibbonPageGroup4.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Navigation
        Me.PrintPreviewRibbonPageGroup4.Name = "PrintPreviewRibbonPageGroup4"
        Me.PrintPreviewRibbonPageGroup4.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup4.Text = "Navigation"
        '
        'PrintPreviewRibbonPageGroup5
        '
        Me.PrintPreviewRibbonPageGroup5.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup5.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem12)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem13)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem14)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem22)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem15)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem17)
        Me.PrintPreviewRibbonPageGroup5.ItemLinks.Add(Me.PrintPreviewBarItem16)
        Me.PrintPreviewRibbonPageGroup5.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Zoom
        Me.PrintPreviewRibbonPageGroup5.Name = "PrintPreviewRibbonPageGroup5"
        Me.PrintPreviewRibbonPageGroup5.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup5.Text = "Zoom"
        '
        'PrintPreviewRibbonPageGroup6
        '
        Me.PrintPreviewRibbonPageGroup6.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup6.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup6.ItemLinks.Add(Me.PrintPreviewBarItem23)
        Me.PrintPreviewRibbonPageGroup6.ItemLinks.Add(Me.PrintPreviewBarItem24)
        Me.PrintPreviewRibbonPageGroup6.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Background
        Me.PrintPreviewRibbonPageGroup6.Name = "PrintPreviewRibbonPageGroup6"
        Me.PrintPreviewRibbonPageGroup6.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup6.Text = "Page Background"
        '
        'PrintPreviewRibbonPageGroup7
        '
        Me.PrintPreviewRibbonPageGroup7.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup7.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup7.ItemLinks.Add(Me.PrintPreviewBarItem25)
        Me.PrintPreviewRibbonPageGroup7.ItemLinks.Add(Me.PrintPreviewBarItem26)
        Me.PrintPreviewRibbonPageGroup7.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Export
        Me.PrintPreviewRibbonPageGroup7.Name = "PrintPreviewRibbonPageGroup7"
        Me.PrintPreviewRibbonPageGroup7.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup7.Text = "Export"
        '
        'PrintPreviewRibbonPageGroup8
        '
        Me.PrintPreviewRibbonPageGroup8.AllowTextClipping = False
        Me.PrintPreviewRibbonPageGroup8.ContextSpecifier = Me.DocumentViewerRibbonController1
        Me.PrintPreviewRibbonPageGroup8.ItemLinks.Add(Me.PrintPreviewBarItem27)
        Me.PrintPreviewRibbonPageGroup8.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Close
        Me.PrintPreviewRibbonPageGroup8.Name = "PrintPreviewRibbonPageGroup8"
        Me.PrintPreviewRibbonPageGroup8.ShowCaptionButton = False
        Me.PrintPreviewRibbonPageGroup8.Text = "Close"
        '
        'RibbonStatusBar1
        '
        Me.RibbonStatusBar1.ItemLinks.Add(Me.PrintPreviewStaticItem1)
        Me.RibbonStatusBar1.ItemLinks.Add(Me.BarStaticItem1)
        Me.RibbonStatusBar1.ItemLinks.Add(Me.ProgressBarEditItem1)
        Me.RibbonStatusBar1.ItemLinks.Add(Me.PrintPreviewBarItem52)
        Me.RibbonStatusBar1.ItemLinks.Add(Me.PrintPreviewStaticItem2)
        Me.RibbonStatusBar1.ItemLinks.Add(Me.ZoomTrackBarEditItem1)
        Me.RibbonStatusBar1.Location = New System.Drawing.Point(0, 341)
        Me.RibbonStatusBar1.Name = "RibbonStatusBar1"
        Me.RibbonStatusBar1.Ribbon = Me.RibbonControl1
        Me.RibbonStatusBar1.Size = New System.Drawing.Size(581, 21)
        '
        'frm_rptsubjects
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 362)
        Me.Controls.Add(Me.DocumentViewer1)
        Me.Controls.Add(Me.RibbonStatusBar1)
        Me.Controls.Add(Me.RibbonControl1)
        Me.Name = "frm_rptsubjects"
        Me.Ribbon = Me.RibbonControl1
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.StatusBar = Me.RibbonStatusBar1
        Me.Text = "frm_rptsubjects"
        CType(Me.DocumentViewerRibbonController1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RibbonControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemProgressBar1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemZoomTrackBar1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DocumentViewer1 As DevExpress.XtraPrinting.Preview.DocumentViewer
    Friend WithEvents DocumentViewerRibbonController1 As DevExpress.XtraPrinting.Preview.DocumentViewerRibbonController
    Friend WithEvents RibbonControl1 As DevExpress.XtraBars.Ribbon.RibbonControl
    Friend WithEvents PrintPreviewBarItem1 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem2 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem3 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem4 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem5 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem6 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem7 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem8 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem9 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem10 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem11 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem12 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem13 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem14 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem15 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem16 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem17 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem18 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem19 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem20 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem21 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem22 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem23 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem24 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem25 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem26 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem27 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem28 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem29 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem30 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem31 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem32 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem33 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem34 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem35 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem36 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem37 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem38 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem39 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem40 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem41 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem42 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem43 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem44 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem45 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem46 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem47 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem48 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem49 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem50 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewBarItem51 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewStaticItem1 As DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem
    Friend WithEvents BarStaticItem1 As DevExpress.XtraBars.BarStaticItem
    Friend WithEvents ProgressBarEditItem1 As DevExpress.XtraPrinting.Preview.ProgressBarEditItem
    Friend WithEvents RepositoryItemProgressBar1 As DevExpress.XtraEditors.Repository.RepositoryItemProgressBar
    Friend WithEvents PrintPreviewBarItem52 As DevExpress.XtraPrinting.Preview.PrintPreviewBarItem
    Friend WithEvents PrintPreviewStaticItem2 As DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem
    Friend WithEvents ZoomTrackBarEditItem1 As DevExpress.XtraPrinting.Preview.ZoomTrackBarEditItem
    Friend WithEvents RepositoryItemZoomTrackBar1 As DevExpress.XtraEditors.Repository.RepositoryItemZoomTrackBar
    Friend WithEvents RibbonPage1 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage
    Friend WithEvents PrintPreviewRibbonPageGroup1 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup2 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup3 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup4 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup5 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup6 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup7 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents PrintPreviewRibbonPageGroup8 As DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup
    Friend WithEvents RibbonStatusBar1 As DevExpress.XtraBars.Ribbon.RibbonStatusBar
End Class
