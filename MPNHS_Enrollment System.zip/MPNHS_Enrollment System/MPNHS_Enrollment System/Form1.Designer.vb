﻿Partial Public Class Form1
    Inherits DevExpress.XtraEditors.XtraForm

    ''' <summary>
    ''' Required designer variable.
    ''' </summary>
    Private components As System.ComponentModel.IContainer = Nothing

    ''' <summary>
    ''' Clean up any resources being used.
    ''' </summary>
    ''' <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso (components IsNot Nothing) Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

#Region "Windows Form Designer generated code"

    ''' <summary>
    ''' Required method for Designer support - do not modify
    ''' the contents of this method with the code editor.
    ''' </summary>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.DefaultLookAndFeel1 = New DevExpress.LookAndFeel.DefaultLookAndFeel(Me.components)
        Me.RibbonPage2 = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_subjects = New System.Windows.Forms.Button()
        Me.btn_class_list = New System.Windows.Forms.Button()
        Me.btn_faculties = New System.Windows.Forms.Button()
        Me.btn_stud_reg = New System.Windows.Forms.Button()
        Me.btn_stud_grades = New System.Windows.Forms.Button()
        Me.btn_enrollment = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureEdit1 = New DevExpress.XtraEditors.PictureEdit()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.pnl_header = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.BunifuDragControl1 = New ns1.BunifuDragControl(Me.components)
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.Uc_classlist1 = New MPNHS_Enrollment_System.uc_classlist()
        Me.Uc_grades1 = New MPNHS_Enrollment_System.uc_grades()
        Me.Uc_subjects1 = New MPNHS_Enrollment_System.uc_subjects()
        Me.Uc_students1 = New MPNHS_Enrollment_System.uc_students()
        Me.Uc_faculties1 = New MPNHS_Enrollment_System.uc_faculties()
        Me.Uc_enrollment1 = New MPNHS_Enrollment_System.uc_enrollment()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.SeparatorControl1 = New DevExpress.XtraEditors.SeparatorControl()
        Me.SeparatorControl4 = New DevExpress.XtraEditors.SeparatorControl()
        Me.lbl_currentuser = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lbl_time = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.tmr_date = New System.Windows.Forms.Timer(Me.components)
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        Me.pnl_header.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        CType(Me.SeparatorControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SeparatorControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DefaultLookAndFeel1
        '
        Me.DefaultLookAndFeel1.LookAndFeel.SkinName = "Office 2016 Colorful"
        '
        'RibbonPage2
        '
        Me.RibbonPage2.Name = "RibbonPage2"
        Me.RibbonPage2.Text = "RibbonPage2"
        '
        'PanelControl1
        '
        Me.PanelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl1.Controls.Add(Me.PanelControl2)
        Me.PanelControl1.Controls.Add(Me.Panel2)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl1.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(239, 656)
        Me.PanelControl1.TabIndex = 1
        '
        'PanelControl2
        '
        Me.PanelControl2.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl2.Controls.Add(Me.btn_subjects)
        Me.PanelControl2.Controls.Add(Me.btn_class_list)
        Me.PanelControl2.Controls.Add(Me.btn_faculties)
        Me.PanelControl2.Controls.Add(Me.btn_stud_reg)
        Me.PanelControl2.Controls.Add(Me.btn_stud_grades)
        Me.PanelControl2.Controls.Add(Me.btn_enrollment)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl2.Location = New System.Drawing.Point(0, 143)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(239, 513)
        Me.PanelControl2.TabIndex = 9
        '
        'btn_subjects
        '
        Me.btn_subjects.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_subjects.FlatAppearance.BorderSize = 0
        Me.btn_subjects.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_subjects.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_subjects.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_subjects.Location = New System.Drawing.Point(0, 150)
        Me.btn_subjects.Name = "btn_subjects"
        Me.btn_subjects.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_subjects.Size = New System.Drawing.Size(239, 30)
        Me.btn_subjects.TabIndex = 11
        Me.btn_subjects.Text = "Subjects"
        Me.btn_subjects.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_subjects.UseVisualStyleBackColor = True
        '
        'btn_class_list
        '
        Me.btn_class_list.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_class_list.FlatAppearance.BorderSize = 0
        Me.btn_class_list.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_class_list.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_class_list.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_class_list.Location = New System.Drawing.Point(0, 120)
        Me.btn_class_list.Name = "btn_class_list"
        Me.btn_class_list.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_class_list.Size = New System.Drawing.Size(239, 30)
        Me.btn_class_list.TabIndex = 10
        Me.btn_class_list.Text = "Class Lists"
        Me.btn_class_list.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_class_list.UseVisualStyleBackColor = True
        '
        'btn_faculties
        '
        Me.btn_faculties.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_faculties.FlatAppearance.BorderSize = 0
        Me.btn_faculties.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_faculties.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_faculties.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_faculties.Location = New System.Drawing.Point(0, 90)
        Me.btn_faculties.Name = "btn_faculties"
        Me.btn_faculties.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_faculties.Size = New System.Drawing.Size(239, 30)
        Me.btn_faculties.TabIndex = 9
        Me.btn_faculties.Text = "Faculties"
        Me.btn_faculties.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_faculties.UseVisualStyleBackColor = True
        '
        'btn_stud_reg
        '
        Me.btn_stud_reg.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_stud_reg.FlatAppearance.BorderSize = 0
        Me.btn_stud_reg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_stud_reg.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_stud_reg.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_stud_reg.Location = New System.Drawing.Point(0, 60)
        Me.btn_stud_reg.Name = "btn_stud_reg"
        Me.btn_stud_reg.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_stud_reg.Size = New System.Drawing.Size(239, 30)
        Me.btn_stud_reg.TabIndex = 12
        Me.btn_stud_reg.Text = "Student Registration"
        Me.btn_stud_reg.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_stud_reg.UseVisualStyleBackColor = True
        '
        'btn_stud_grades
        '
        Me.btn_stud_grades.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_stud_grades.FlatAppearance.BorderSize = 0
        Me.btn_stud_grades.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_stud_grades.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_stud_grades.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_stud_grades.Location = New System.Drawing.Point(0, 30)
        Me.btn_stud_grades.Name = "btn_stud_grades"
        Me.btn_stud_grades.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_stud_grades.Size = New System.Drawing.Size(239, 30)
        Me.btn_stud_grades.TabIndex = 8
        Me.btn_stud_grades.Text = "Student Grades"
        Me.btn_stud_grades.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_stud_grades.UseVisualStyleBackColor = True
        '
        'btn_enrollment
        '
        Me.btn_enrollment.Dock = System.Windows.Forms.DockStyle.Top
        Me.btn_enrollment.FlatAppearance.BorderSize = 0
        Me.btn_enrollment.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_enrollment.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_enrollment.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.btn_enrollment.Location = New System.Drawing.Point(0, 0)
        Me.btn_enrollment.Name = "btn_enrollment"
        Me.btn_enrollment.Padding = New System.Windows.Forms.Padding(1)
        Me.btn_enrollment.Size = New System.Drawing.Size(239, 30)
        Me.btn_enrollment.TabIndex = 7
        Me.btn_enrollment.Text = "Enrollment"
        Me.btn_enrollment.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.btn_enrollment.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Transparent
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.PictureEdit1)
        Me.Panel2.Controls.Add(Me.Panel3)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(0, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(239, 143)
        Me.Panel2.TabIndex = 8
        '
        'Label4
        '
        Me.Label4.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(100, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 54)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Malaking Pulo" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "National" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "High School"
        '
        'PictureEdit1
        '
        Me.PictureEdit1.EditValue = Global.MPNHS_Enrollment_System.My.Resources.Resources.b22cf0f36433bfa5a803294089a75bce_0
        Me.PictureEdit1.Location = New System.Drawing.Point(0, 3)
        Me.PictureEdit1.Name = "PictureEdit1"
        Me.PictureEdit1.Properties.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.PictureEdit1.Properties.Appearance.Options.UseBackColor = True
        Me.PictureEdit1.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.[Auto]
        Me.PictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom
        Me.PictureEdit1.Size = New System.Drawing.Size(108, 94)
        Me.PictureEdit1.TabIndex = 6
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.Transparent
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel3.Location = New System.Drawing.Point(0, 122)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(239, 21)
        Me.Panel3.TabIndex = 4
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gray
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(142, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = " ENROLLMENT CONTROLS"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'pnl_header
        '
        Me.pnl_header.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.pnl_header.Controls.Add(Me.Label2)
        Me.pnl_header.Controls.Add(Me.Button8)
        Me.pnl_header.Controls.Add(Me.Button6)
        Me.pnl_header.Dock = System.Windows.Forms.DockStyle.Top
        Me.pnl_header.Location = New System.Drawing.Point(239, 0)
        Me.pnl_header.Name = "pnl_header"
        Me.pnl_header.Size = New System.Drawing.Size(997, 35)
        Me.pnl_header.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(430, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 14)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Enrollment System"
        '
        'Button8
        '
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Button8.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(929, 0)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(34, 35)
        Me.Button8.TabIndex = 3
        Me.Button8.Text = "-"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Dock = System.Windows.Forms.DockStyle.Right
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(963, 0)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(34, 35)
        Me.Button6.TabIndex = 1
        Me.Button6.Text = "X"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'BunifuDragControl1
        '
        Me.BunifuDragControl1.Fixed = True
        Me.BunifuDragControl1.Horizontal = True
        Me.BunifuDragControl1.TargetControl = Me.pnl_header
        Me.BunifuDragControl1.Vertical = True
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.Uc_classlist1)
        Me.PanelControl3.Controls.Add(Me.Uc_grades1)
        Me.PanelControl3.Controls.Add(Me.Uc_subjects1)
        Me.PanelControl3.Controls.Add(Me.Uc_students1)
        Me.PanelControl3.Controls.Add(Me.Uc_faculties1)
        Me.PanelControl3.Controls.Add(Me.Uc_enrollment1)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl3.Location = New System.Drawing.Point(239, 35)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(997, 590)
        Me.PanelControl3.TabIndex = 3
        '
        'Uc_classlist1
        '
        Me.Uc_classlist1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_classlist1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_classlist1.Name = "Uc_classlist1"
        Me.Uc_classlist1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_classlist1.TabIndex = 5
        '
        'Uc_grades1
        '
        Me.Uc_grades1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_grades1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_grades1.Name = "Uc_grades1"
        Me.Uc_grades1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_grades1.TabIndex = 4
        '
        'Uc_subjects1
        '
        Me.Uc_subjects1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_subjects1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_subjects1.Name = "Uc_subjects1"
        Me.Uc_subjects1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_subjects1.TabIndex = 3
        '
        'Uc_students1
        '
        Me.Uc_students1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_students1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_students1.Name = "Uc_students1"
        Me.Uc_students1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_students1.TabIndex = 2
        '
        'Uc_faculties1
        '
        Me.Uc_faculties1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_faculties1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_faculties1.Name = "Uc_faculties1"
        Me.Uc_faculties1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_faculties1.TabIndex = 1
        '
        'Uc_enrollment1
        '
        Me.Uc_enrollment1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Uc_enrollment1.Location = New System.Drawing.Point(2, 2)
        Me.Uc_enrollment1.Name = "Uc_enrollment1"
        Me.Uc_enrollment1.Size = New System.Drawing.Size(993, 586)
        Me.Uc_enrollment1.TabIndex = 0
        '
        'PanelControl4
        '
        Me.PanelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl4.Controls.Add(Me.SeparatorControl1)
        Me.PanelControl4.Controls.Add(Me.SeparatorControl4)
        Me.PanelControl4.Controls.Add(Me.lbl_currentuser)
        Me.PanelControl4.Controls.Add(Me.Label8)
        Me.PanelControl4.Controls.Add(Me.lbl_date)
        Me.PanelControl4.Controls.Add(Me.Label6)
        Me.PanelControl4.Controls.Add(Me.lbl_time)
        Me.PanelControl4.Controls.Add(Me.Label3)
        Me.PanelControl4.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelControl4.Location = New System.Drawing.Point(239, 625)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(997, 31)
        Me.PanelControl4.TabIndex = 6
        '
        'SeparatorControl1
        '
        Me.SeparatorControl1.LineAlignment = DevExpress.XtraEditors.Alignment.Near
        Me.SeparatorControl1.LineOrientation = System.Windows.Forms.Orientation.Vertical
        Me.SeparatorControl1.Location = New System.Drawing.Point(585, 0)
        Me.SeparatorControl1.Name = "SeparatorControl1"
        Me.SeparatorControl1.Size = New System.Drawing.Size(19, 31)
        Me.SeparatorControl1.TabIndex = 12
        '
        'SeparatorControl4
        '
        Me.SeparatorControl4.LineAlignment = DevExpress.XtraEditors.Alignment.Near
        Me.SeparatorControl4.LineOrientation = System.Windows.Forms.Orientation.Vertical
        Me.SeparatorControl4.Location = New System.Drawing.Point(811, 0)
        Me.SeparatorControl4.Name = "SeparatorControl4"
        Me.SeparatorControl4.Size = New System.Drawing.Size(19, 31)
        Me.SeparatorControl4.TabIndex = 11
        '
        'lbl_currentuser
        '
        Me.lbl_currentuser.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_currentuser.AutoSize = True
        Me.lbl_currentuser.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_currentuser.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl_currentuser.Location = New System.Drawing.Point(103, 8)
        Me.lbl_currentuser.Name = "lbl_currentuser"
        Me.lbl_currentuser.Size = New System.Drawing.Size(88, 14)
        Me.lbl_currentuser.TabIndex = 10
        Me.lbl_currentuser.Text = "Current User : "
        '
        'Label8
        '
        Me.Label8.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label8.Location = New System.Drawing.Point(9, 8)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(88, 14)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Current User : "
        '
        'lbl_date
        '
        Me.lbl_date.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_date.AutoSize = True
        Me.lbl_date.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl_date.Location = New System.Drawing.Point(653, 8)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(45, 14)
        Me.lbl_date.TabIndex = 8
        Me.lbl_date.Text = "Date : "
        '
        'Label6
        '
        Me.Label6.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(610, 8)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 14)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Date : "
        '
        'lbl_time
        '
        Me.lbl_time.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lbl_time.AutoSize = True
        Me.lbl_time.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_time.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lbl_time.Location = New System.Drawing.Point(879, 8)
        Me.lbl_time.Name = "lbl_time"
        Me.lbl_time.Size = New System.Drawing.Size(46, 14)
        Me.lbl_time.TabIndex = 6
        Me.lbl_time.Text = "Time : "
        '
        'Label3
        '
        Me.Label3.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(836, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 14)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Time : "
        '
        'tmr_date
        '
        Me.tmr_date.Enabled = True
        Me.tmr_date.Interval = 1000
        '
        'Form1
        '
        Me.ClientSize = New System.Drawing.Size(1236, 656)
        Me.ControlBox = False
        Me.Controls.Add(Me.PanelControl3)
        Me.Controls.Add(Me.PanelControl4)
        Me.Controls.Add(Me.pnl_header)
        Me.Controls.Add(Me.PanelControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.pnl_header.ResumeLayout(False)
        Me.pnl_header.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        Me.PanelControl4.PerformLayout()
        CType(Me.SeparatorControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SeparatorControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents DefaultLookAndFeel1 As DevExpress.LookAndFeel.DefaultLookAndFeel
    Friend WithEvents RibbonPage2 As DevExpress.XtraBars.Ribbon.RibbonPage
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents pnl_header As System.Windows.Forms.Panel
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_class_list As System.Windows.Forms.Button
    Friend WithEvents btn_faculties As System.Windows.Forms.Button
    Friend WithEvents btn_stud_grades As System.Windows.Forms.Button
    Friend WithEvents btn_enrollment As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BunifuDragControl1 As ns1.BunifuDragControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Uc_enrollment1 As MPNHS_Enrollment_System.uc_enrollment
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents lbl_currentuser As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lbl_date As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents lbl_time As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents SeparatorControl1 As DevExpress.XtraEditors.SeparatorControl
    Friend WithEvents SeparatorControl4 As DevExpress.XtraEditors.SeparatorControl
    Friend WithEvents tmr_date As System.Windows.Forms.Timer
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents PictureEdit1 As DevExpress.XtraEditors.PictureEdit
    Friend WithEvents Uc_faculties1 As MPNHS_Enrollment_System.uc_faculties
    Friend WithEvents btn_stud_reg As System.Windows.Forms.Button
    Friend WithEvents btn_subjects As System.Windows.Forms.Button
    Friend WithEvents Uc_students1 As MPNHS_Enrollment_System.uc_students
    Friend WithEvents Uc_subjects1 As MPNHS_Enrollment_System.uc_subjects
    Friend WithEvents Uc_grades1 As MPNHS_Enrollment_System.uc_grades
    Friend WithEvents Uc_classlist1 As MPNHS_Enrollment_System.uc_classlist

#End Region

End Class
