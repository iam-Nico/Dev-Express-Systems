﻿Partial Public Class MPNHS_DBDataSet

End Class
