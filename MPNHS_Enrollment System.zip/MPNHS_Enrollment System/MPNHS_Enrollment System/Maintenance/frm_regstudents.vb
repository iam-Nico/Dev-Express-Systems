﻿Public Class frm_regstudents

    Dim age As Double

    Private Sub btn_register_Click(sender As Object, e As EventArgs) Handles btn_register.Click
        AddStudents(txt_fname.Text, txt_mname.Text, txt_lname.Text, cbo_gender.Text, cbo_bday.Text, CInt(txt_age.Text), txt_address.Text, txt_contact.Text, txt_mother.Text, txt_father.Text)
        Me.Close()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ClearFields()
        Me.Close()
    End Sub

    Private Sub frm_regstudents_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Command = 1 Then
            btn_register.Enabled = True
            btn_save.Enabled = False
        Else
            btn_register.Enabled = False
            btn_save.Enabled = True
        End If
    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click

        EditStudents(txt_stuid.Text, txt_fname.Text, txt_mname.Text, txt_lname.Text, cbo_bday.Text, txt_age.Text, cbo_gender.Text, txt_address.Text, txt_contact.Text, txt_mother.Text, txt_father.Text)
        MessageBox.Show("Updated!")
        Me.Close()
    End Sub

    Private Sub cbo_bday_ValueChanged(sender As Object, e As EventArgs) Handles cbo_bday.ValueChanged
        txt_age.Text = Fix((DateDiff(DateInterval.Day, cbo_bday.Value, Now.Date)) / 365)
    End Sub

    'Private Sub dtp_ValueChanged(sender As Object, e As EventArgs)
    '    age = Fix((DateDiff(DateInterval.Day, dtp.Value, Now.Date)) / 365)
    '    txt_age.Text = CStr(age)
    'End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        ClearFields()
        Me.Close()
    End Sub
End Class