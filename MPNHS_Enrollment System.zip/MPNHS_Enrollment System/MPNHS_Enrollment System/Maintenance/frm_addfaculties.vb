﻿Public Class frm_addfaculties 

    Private Sub btn_add_Click(sender As Object, e As EventArgs) Handles btn_add.Click

        If txt_fname.Text = "" Or txt_mname.Text = "" Or txt_lname.Text = "" Or txt_address.Text = "" Or txt_contact.Text = "" Or txt_username.Text = "" Or txt_password.Text = "" Or cbo_gradelvl.Text = "" Or cbo_section.Text = "" Then

            MessageBox.Show("Please complete the information")
            Exit Sub

        End If

        If IsNumeric(txt_contact.Text) = True Then
            MessageBox.Show("invalid contact number")
            Exit Sub
        End If



        If txt_fname.Text = "" Then
            MessageBox.Show("Please complete the information!")
        Else
            AddFaculties(txt_fname.Text, txt_mname.Text, txt_lname.Text, txt_address.Text, txt_contact.Text, txt_username.Text, txt_password.Text, cbo_gradelvl.Text, cbo_section.Text)
            MessageBox.Show("Faculty successfully added!")
        End If

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ClearFields()
        Me.Close()
    End Sub

    Private Sub frm_addfaculties_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Command = 1 Then
            btn_add.Enabled = True
            btn_save.Enabled = False
        Else
            btn_add.Enabled = False
            btn_save.Enabled = True
        End If
    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        If txt_fname.Text = "" Or txt_mname.Text = "" Or txt_lname.Text = "" Or txt_address.Text = "" Or txt_contact.Text = "" Or txt_username.Text = "" Or txt_password.Text = "" Or cbo_gradelvl.Text = "" Or cbo_section.Text = "" Then

            MessageBox.Show("Please complete the information")
            Exit Sub

        End If

        If IsNumeric(txt_contact.Text) = True Then
            MessageBox.Show("invalid contact number")
            Exit Sub
        End If
        EditFaculties(txt_facid.Text, txt_fname.Text, txt_mname.Text, txt_lname.Text, txt_address.Text, txt_contact.Text, txt_username.Text, txt_password.Text)
        MessageBox.Show("Updated!")
    End Sub

    Private Sub cbo_gradelvl_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_gradelvl.SelectedIndexChanged
        If cbo_gradelvl.Text = "Grade 7" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Generosity")
            cbo_section.Properties.Items.Add("Patience")

        ElseIf cbo_gradelvl.Text = "Grade 8" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Responsibility")
            cbo_section.Properties.Items.Add("Hardwork")

        ElseIf cbo_gradelvl.Text = "Grade 9" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Initiative")
            cbo_section.Properties.Items.Add("Sincerity")

        ElseIf cbo_gradelvl.Text = "Grade 10" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Discipline")
            cbo_section.Properties.Items.Add("Punctuality")

        End If

    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        ClearFields()
        Me.Close()
    End Sub
End Class