﻿Public Class frm_addsubjects 

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        Me.Close()
    End Sub

    Private Sub btn_add_Click(sender As Object, e As EventArgs) Handles btn_add.Click

        If txt_subcode.Text = "" Or txt_desc.Text = "" Or cbo_gradelvl.Text = "" Or cbo_teacher.Text = "" Or cbo_from.Text = "" Or cbo_to.Text = "" Then

            MessageBox.Show("Please complete the information")
            Exit Sub

        End If

        AddSubjects(txt_subcode.Text, txt_desc.Text, cbo_from.Text, cbo_to.Text, cbo_teacher.Text, cbo_gradelvl.Text)
        MessageBox.Show("Subject successfully added!")
    End Sub

    Private Sub frm_addsubjects_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Command = 1 Then
            btn_add.Enabled = True
            btn_save.Enabled = False
        Else
            btn_add.Enabled = False
            btn_save.Enabled = True
        End If
        dropdowns_F()

    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        If txt_subcode.Text = "" Or txt_desc.Text = "" Or cbo_gradelvl.Text = "" Or cbo_teacher.Text = "" Or cbo_from.Text = "" Or cbo_to.Text = "" Then

            MessageBox.Show("Please complete the information")
            Exit Sub

        End If
        EditSubjects(txt_subcode.Text, txt_desc.Text, cbo_from.Text, cbo_to.Text, cbo_teacher.Text, cbo_gradelvl.Text)
        MessageBox.Show("Updated!")
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        ClearFields()
        Me.Close()
    End Sub
End Class