﻿Public Class frm_enrollstudents

    Public _StudentID As String


    Private Sub frm_enrollstudents_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        If Command = 1 Then
            btn_enroll.Enabled = True
            btn_save.Enabled = False
        Else
            btn_enroll.Enabled = False
            btn_save.Enabled = True
        End If


        txt_studname.MaskBox.AutoCompleteCustomSource = Collection
        txt_studname.MaskBox.AutoCompleteMode = AutoCompleteMode.Suggest
        txt_studname.MaskBox.AutoCompleteSource = AutoCompleteSource.CustomSource

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        ClearFields()
        Me.Close()
    End Sub

    Private Sub btn_enroll_Click(sender As Object, e As EventArgs) Handles btn_enroll.Click

        If txt_studid.Text = "" Or txt_studname.Text = "" Or cbo_gradelvl.Text = "" Or cbo_section.Text = "" Then
            MessageBox.Show("Please complete the information")
            Exit Sub
        End If

        Enroll(txt_studid.Text, frm_login._UserID, cbo_gradelvl.Text, cbo_section.Text, Form1.lbl_date.Text + " " + Form1.lbl_time.Text, "2019-2019")
        AddtoGrades()
        ''-->Update Student status to Enrolled
        MessageBox.Show("Student successfully enrolled")
        Me.dg_subjects.DataSource = GetEnrolledSubjects()
        lbl_notfound.Visible = False
        Me.Close()
    End Sub

    'Private Sub txt_studname_LostFocus(sender As Object, e As EventArgs) Handles txt_studname.LostFocus
    '    getstudids()
    '    txt_studid.Text = _StudentID
    'End Sub

    Private Sub txt_studname_TextChanged(sender As Object, e As EventArgs) Handles txt_studname.TextChanged
        Try
            dropdowns_S()
        Catch ex As Exception
            MessageBox.Show("Try again,if error occurs again restart the system.")
            txt_studname.Text = ""
        End Try

    End Sub

    Private Sub cbo_gradelvl_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbo_gradelvl.SelectedIndexChanged

        If cbo_gradelvl.Text = "Grade 7" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Generosity")
            cbo_section.Properties.Items.Add("Patience")

        ElseIf cbo_gradelvl.Text = "Grade 8" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Responsibility")
            cbo_section.Properties.Items.Add("Hardwork")

        ElseIf cbo_gradelvl.Text = "Grade 9" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Initiative")
            cbo_section.Properties.Items.Add("Sincerity")

        ElseIf cbo_gradelvl.Text = "Grade 10" Then

            cbo_section.Properties.Items.Clear()
            cbo_section.SelectedIndex = -1
            cbo_section.Properties.Items.Add("Discipline")
            cbo_section.Properties.Items.Add("Punctuality")

        End If

        dg_subjects.DataSource = GetEnrolledSubjects()

    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        If txt_studid.Text = "" Or txt_studname.Text = "" Or cbo_gradelvl.Text = "" Or cbo_section.Text = "" Then
            MessageBox.Show("Please complete the information")
            Exit Sub
        End If
        EditEnrolled(txt_studid.Text, cbo_gradelvl.Text, cbo_section.Text)
        MessageBox.Show("Updated!")
        Me.dg_subjects.DataSource = GetEnrolledSubjects()
        lbl_notfound.Visible = False
        Me.Close()
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        ClearFields()
        Me.Close()
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txt_studid.TextChanged
        If txt_studid.textlength = 10 Then

            dropdowns_S()
            txt_studname.Text = _StudentID

        Else
            lbl_notfound.Visible = False
        End If
        
    End Sub
End Class