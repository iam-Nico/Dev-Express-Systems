﻿Public Class frm_printgrades 

    Private Sub frm_printgrades_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        lbl_print.Visible = True

        dg_generosity.DataSource = GetGrades()

        lbl_gs.Text = _GradeLevel + "/" + _Section
        lbl_subject.Text = Form1.Uc_grades1.cbo_subjects.Text
        lbl_period.Text = Form1.Uc_grades1.cbo_period.Text
        lbl_dateprinted.Text = Date.Now.ToLongDateString

        dg_generosity.ClearSelection()
    End Sub

    Private Sub lbl_print_Click(sender As Object, e As EventArgs) Handles lbl_print.Click
        lbl_print.Visible = False
        PrintDialog1.Document = Me.PrintDocument1

        Dim ButtonPressed As DialogResult = PrintDialog1.ShowDialog()
        If (ButtonPressed = DialogResult.OK) Then
            PrintDocument1.Print()
            'Me.Close()
        End If
        Me.Close()
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.Panel1.Width, Me.Panel1.Height)

        Me.Panel1.DrawToBitmap(bm, New Rectangle(0, 0, Me.Panel1.Width, Me.Panel1.Height))

        e.Graphics.DrawImage(bm, 50, 60)
        Dim aPS As New PageSetupDialog
        aPS.Document = PrintDocument1
    End Sub

    Private Sub dg_generosity_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dg_generosity.CellContentClick

    End Sub

    Private Sub dg_generosity_SelectionChanged(sender As Object, e As EventArgs) Handles dg_generosity.SelectionChanged
        dg_generosity.ClearSelection()
    End Sub
End Class