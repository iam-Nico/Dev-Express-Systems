﻿Public Class uc_students


    Dim Vals(100), S_ids As String

    Private Sub uc_students_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GridView1.BestFitColumns()
        dg_faculties.DataSource = GetStudents()

    End Sub

    Private Sub btn_new_Click(sender As Object, e As EventArgs) Handles btn_new.Click
        Command = 1
        frm_regstudents.Show()
    End Sub

    Private Sub SimpleButton5_Click(sender As Object, e As EventArgs) Handles SimpleButton5.Click
        dg_faculties.DataSource = GetStudents()
    End Sub

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles SimpleButton2.Click
        Command = 2

        frm_regstudents.txt_stuid.Text = Vals(0)
        frm_regstudents.txt_fname.Text = Vals(1)
        frm_regstudents.txt_mname.Text = Vals(2)
        frm_regstudents.txt_lname.Text = Vals(3)
        frm_regstudents.cbo_bday.Text = Vals(4)
        frm_regstudents.txt_age.Text = Vals(5)
        frm_regstudents.cbo_gender.Text = Vals(6)
        frm_regstudents.txt_address.Text = Vals(7)
        frm_regstudents.txt_contact.Text = Vals(8)
        frm_regstudents.txt_mother.Text = Vals(9)
        frm_regstudents.txt_father.Text = Vals(10)

        frm_regstudents.Show()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "stud_id").ToString
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "stud_fname").ToString
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "stud_lname").ToString
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "stud_fname").ToString
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "stud_bday").ToString
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "stud_age").ToString
        Vals(6) = view.GetRowCellValue(view.FocusedRowHandle, "stud_gender").ToString
        Vals(7) = view.GetRowCellValue(view.FocusedRowHandle, "stud_address").ToString
        Vals(8) = view.GetRowCellValue(view.FocusedRowHandle, "stud_contactnumber").ToString
        Vals(9) = view.GetRowCellValue(view.FocusedRowHandle, "stud_mother").ToString
        Vals(10) = view.GetRowCellValue(view.FocusedRowHandle, "stud_father").ToString

        S_ids = Vals(0).ToString

    End Sub

    Private Sub SimpleButton3_Click(sender As Object, e As EventArgs) Handles SimpleButton3.Click

    End Sub

    Private Sub SimpleButton6_Click(sender As Object, e As EventArgs) Handles SimpleButton6.Click
        frm_rptstudents.ShowDialog()
    End Sub
End Class
