﻿Public Class uc_grades


    Dim _AveRecitation As Decimal
    Dim _AveQuiz As Decimal
    Dim _AveProject As Decimal
    Dim _AveExam As Decimal
    Dim _AveFinalGrade As Decimal



    Private Sub btn_load_Click(sender As Object, e As EventArgs) Handles btn_load.Click


        'MessageBox.Show(XtraTabControl1.SelectedTabPage.Text)
        'MessageBox.Show(_Section)


        If _Section = "Generosity" Then
            dg_generosity.DataSource = GetGrades()
        ElseIf _Section = "Patience" Then
            dgpatience.DataSource = GetGrades()
        ElseIf _Section = "Responsibility" Then
            dgresponsibility.DataSource = GetGrades()
        ElseIf _Section = "Hardwork" Then
            dghardwork.DataSource = GetGrades()
        ElseIf _Section = "Initiative" Then
            dginitiative.DataSource = GetGrades()
        ElseIf _Section = "Sincerity" Then
            dgsincerity.DataSource = GetGrades()
        ElseIf _Section = "Discipline" Then
            dgdiscipline.DataSource = GetGrades()
        ElseIf _Section = "Punctuality" Then
            dgpunctuality.DataSource = GetGrades()
        End If

        'MessageBox.Show(dg_generosity.Rows(0).Cells(10).Value.ToString)

    End Sub



    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click



        If _Section = "Generosity" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dg_generosity.DataSource = GetGrades()
        ElseIf _Section = "Patience" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dgpatience.DataSource = GetGrades()
        ElseIf _Section = "Responsibility" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dgresponsibility.DataSource = GetGrades()
        ElseIf _Section = "Hardwork" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dghardwork.DataSource = GetGrades()
        ElseIf _Section = "Initiative" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dginitiative.DataSource = GetGrades()
        ElseIf _Section = "Sincerity" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dgsincerity.DataSource = GetGrades()
        ElseIf _Section = "Discipline" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dgdiscipline.DataSource = GetGrades()
        ElseIf _Section = "Punctuality" Then
            EditGrades()
            MessageBox.Show("Grade Updated!")
            dgpunctuality.DataSource = GetGrades()
        End If



    End Sub

    Private Sub XtraTabControl1_Click(sender As Object, e As EventArgs) Handles XtraTabControl1.Click

        _GradeLevel = XtraTabControl1.SelectedTabPage.Text

    End Sub

    Private Sub XtraTabControl21_Click(sender As Object, e As EventArgs) Handles XtraTabControl2.Click

        _Section = XtraTabControl2.SelectedTabPage.Text

    End Sub
    Private Sub XtraTabControl22_Click(sender As Object, e As EventArgs) Handles XtraTabControl3.Click

        _Section = XtraTabControl3.SelectedTabPage.Text

    End Sub
    Private Sub XtraTabControl23_Click(sender As Object, e As EventArgs) Handles XtraTabControl4.Click

        _Section = XtraTabControl4.SelectedTabPage.Text

    End Sub
    Private Sub XtraTabControl24_Click(sender As Object, e As EventArgs) Handles Xtratab2.Click

        _Section = Xtratab2.SelectedTabPage.Text

    End Sub

    Private Sub dg_generosity_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dg_generosity.CellContentClick

    End Sub

    Private Sub dg_generosity_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dg_generosity.CellEndEdit

        Dim dgrow As New DataGridViewRow

        For Each dgrow In dg_generosity.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next

    End Sub

    Private Sub btn_refresh_Click(sender As Object, e As EventArgs) Handles btn_refresh.Click

        Try
            Dim dgrow As New DataGridViewRow

            For Each dgrow In dg_generosity.SelectedRows


                _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
                _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
                _AveProject = CDec(dgrow.Cells(6).Value)
                _AveExam = CDec(dgrow.Cells(7).Value)
                _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


                dgrow.Cells(10).Value = _AveFinalGrade

            Next
        Catch ex As Exception
            MessageBox.Show("Please select data before refresh")
        End Try

       
    End Sub

    Private Sub dgpatience_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgpatience.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dgpatience.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dgresponsibility_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgresponsibility.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dgresponsibility.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dghardwork_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dghardwork.CellContentClick

    End Sub

    Private Sub dghardwork_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dghardwork.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dghardwork.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dginitiative_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dginitiative.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dginitiative.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dgsincerity_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgsincerity.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dgsincerity.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dgdiscipline_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgdiscipline.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dgdiscipline.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub dgpunctuality_CellEndEdit(sender As Object, e As DataGridViewCellEventArgs) Handles dgpunctuality.CellEndEdit
        Dim dgrow As New DataGridViewRow

        For Each dgrow In dgpunctuality.SelectedRows


            _AveRecitation = (CDec(dgrow.Cells(1).Value) + CDec(dgrow.Cells(2).Value)) / 2
            _AveQuiz = (CDec(dgrow.Cells(3).Value) + CDec(dgrow.Cells(4).Value) + CDec(dgrow.Cells(5).Value)) / 3
            _AveProject = CDec(dgrow.Cells(6).Value)
            _AveExam = CDec(dgrow.Cells(7).Value)
            _AveFinalGrade = (_AveRecitation + _AveQuiz + _AveProject + _AveExam) / 4


            dgrow.Cells(10).Value = _AveFinalGrade


        Next
    End Sub

    Private Sub btn_printprev_Click(sender As Object, e As EventArgs) Handles btn_printprev.Click



        frm_printgrades.ShowDialog()




        'GetGrades()

        'Dim dt As New DataTable
        'With dt

        '    .Columns.Add("stud_id")
        '    .Columns.Add("grade_recitation1")
        '    .Columns.Add("grade_recitation2")
        '    .Columns.Add("grade_quiz1")
        '    .Columns.Add("grade_quiz2")
        '    .Columns.Add("grade_quiz3")
        '    .Columns.Add("grade_project")
        '    .Columns.Add("grade_exam")
        '    .Columns.Add("stud_name")
        '    .Columns.Add("grade_id")
        '    .Columns.Add("grade_final")

        'End With

        'For Each row As DataGridViewRow In Me.dg_generosity.Rows

        '    dt.Rows.Add(row.Cells(0).Value, row.Cells(1).Value, row.Cells(2).Value, row.Cells(3).Value, row.Cells(4).Value, row.Cells(5).Value, row.Cells(6).Value, row.Cells(7).Value, row.Cells(8).Value, row.Cells(9).Value, row.Cells(10).Value)

        'Next

        'frm_finalgrade.ReportViewer1.LocalReport.DataSources.Item(0).Value = dt
        'frm_finalgrade.ShowDialog()




    End Sub
End Class