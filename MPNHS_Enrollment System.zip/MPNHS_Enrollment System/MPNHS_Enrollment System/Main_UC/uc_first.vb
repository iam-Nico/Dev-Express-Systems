﻿Public Class uc_classlist

    Private Sub uc_classlist_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GridView1.BestFitColumns()

        dg_faculties.DataSource = GetClasslist()

    End Sub

    Private Sub SimpleButton5_Click(sender As Object, e As EventArgs) Handles SimpleButton5.Click
        dg_faculties.DataSource = GetClasslist()
    End Sub

    Private Sub btn_load_Click(sender As Object, e As EventArgs) Handles btn_load.Click
        dg_faculties.DataSource = FilterClasslist()
    End Sub

    Private Sub SimpleButton6_Click(sender As Object, e As EventArgs) Handles SimpleButton6.Click
        frm_rptclasslist.ShowDialog()
    End Sub
End Class
