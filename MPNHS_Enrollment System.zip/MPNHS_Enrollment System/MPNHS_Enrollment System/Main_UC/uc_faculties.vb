﻿Public Class uc_faculties

    Dim Vals(100), F_ids As String


    Private Sub SimpleButton1_Click(sender As Object, e As EventArgs) Handles SimpleButton1.Click
        Command = 1
        frm_addfaculties.ShowDialog()
    End Sub

    Private Sub uc_faculties_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GridView1.BestFitColumns()

        dg_faculties.DataSource = GetFaculties()

    End Sub

    Private Sub SimpleButton5_Click(sender As Object, e As EventArgs) Handles SimpleButton5.Click
        Me.dg_faculties.DataSource = GetFaculties()
    End Sub

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles SimpleButton2.Click
        Command = 2

        frm_addfaculties.txt_facid.Text = Vals(0)
        frm_addfaculties.txt_fname.Text = Vals(1)
        frm_addfaculties.txt_mname.Text = Vals(2)
        frm_addfaculties.txt_lname.Text = Vals(3)
        frm_addfaculties.txt_address.Text = Vals(4)
        frm_addfaculties.txt_contact.Text = Vals(5)
        frm_addfaculties.txt_username.Text = Vals(6)
        frm_addfaculties.txt_password.Text = Vals(7)


        frm_addfaculties.ShowDialog()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_id").ToString
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_fname").ToString
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_mname").ToString
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_lname").ToString
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_address").ToString
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_contactnumber").ToString
        Vals(6) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_username").ToString
        Vals(7) = view.GetRowCellValue(view.FocusedRowHandle, "faculties_password").ToString

        F_ids = Vals(0).ToString

    End Sub

    Private Sub SimpleButton3_Click(sender As Object, e As EventArgs) Handles SimpleButton3.Click
        DeleteFaculties(Vals(0))
        MessageBox.Show("Deleted")
    End Sub

    Private Sub SimpleButton6_Click(sender As Object, e As EventArgs) Handles SimpleButton6.Click

        frm_rptfacultylist.ShowDialog()

    End Sub
End Class
