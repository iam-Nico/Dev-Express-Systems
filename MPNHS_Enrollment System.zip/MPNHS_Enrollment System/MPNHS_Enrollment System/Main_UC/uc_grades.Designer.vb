﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uc_grades
    Inherits DevExpress.XtraEditors.XtraUserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uc_grades))
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle8 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cbo_period = New DevExpress.XtraEditors.ComboBoxEdit()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.cbo_subjects = New DevExpress.XtraEditors.ComboBoxEdit()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SeparatorControl4 = New DevExpress.XtraEditors.SeparatorControl()
        Me.PanelControl6 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_refresh = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_printprev = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl7 = New DevExpress.XtraEditors.PanelControl()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.SeparatorControl2 = New DevExpress.XtraEditors.SeparatorControl()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_save = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl5 = New DevExpress.XtraEditors.PanelControl()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_load = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.XtraTabControl1 = New DevExpress.XtraTab.XtraTabControl()
        Me.tab_g7 = New DevExpress.XtraTab.XtraTabPage()
        Me.XtraTabControl2 = New DevExpress.XtraTab.XtraTabControl()
        Me.tab_generosity = New DevExpress.XtraTab.XtraTabPage()
        Me.dg_generosity = New System.Windows.Forms.DataGridView()
        Me.col_studid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_studname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_recitation1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_recitation2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_proj1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_qexam = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_finalgrade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_gradeid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_patience = New DevExpress.XtraTab.XtraTabPage()
        Me.dgpatience = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn64 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn71 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_g8 = New DevExpress.XtraTab.XtraTabPage()
        Me.XtraTabControl3 = New DevExpress.XtraTab.XtraTabControl()
        Me.tab_hardwork = New DevExpress.XtraTab.XtraTabPage()
        Me.dghardwork = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn66 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn73 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_responsibility = New DevExpress.XtraTab.XtraTabPage()
        Me.dgresponsibility = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn65 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn72 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_g9 = New DevExpress.XtraTab.XtraTabPage()
        Me.XtraTabControl4 = New DevExpress.XtraTab.XtraTabControl()
        Me.tab_initiative = New DevExpress.XtraTab.XtraTabPage()
        Me.dginitiative = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn74 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_sincerity = New DevExpress.XtraTab.XtraTabPage()
        Me.dgsincerity = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn38 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn39 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn40 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn41 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn42 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn43 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn44 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn45 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn67 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn68 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn75 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_g10 = New DevExpress.XtraTab.XtraTabPage()
        Me.Xtratab2 = New DevExpress.XtraTab.XtraTabControl()
        Me.tab_punctuality = New DevExpress.XtraTab.XtraTabPage()
        Me.dgpunctuality = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn55 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn56 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn57 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn58 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn59 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn60 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn61 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn62 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn63 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn69 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn77 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.tab_discipline = New DevExpress.XtraTab.XtraTabPage()
        Me.dgdiscipline = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn46 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn47 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn48 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn49 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn50 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn51 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn52 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn53 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn54 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn70 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn76 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.cbo_period.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cbo_subjects.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.SeparatorControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl6.SuspendLayout()
        CType(Me.PanelControl7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl7.SuspendLayout()
        CType(Me.SeparatorControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl5.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl1.SuspendLayout()
        Me.tab_g7.SuspendLayout()
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl2.SuspendLayout()
        Me.tab_generosity.SuspendLayout()
        CType(Me.dg_generosity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_patience.SuspendLayout()
        CType(Me.dgpatience, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_g8.SuspendLayout()
        CType(Me.XtraTabControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl3.SuspendLayout()
        Me.tab_hardwork.SuspendLayout()
        CType(Me.dghardwork, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_responsibility.SuspendLayout()
        CType(Me.dgresponsibility, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_g9.SuspendLayout()
        CType(Me.XtraTabControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.XtraTabControl4.SuspendLayout()
        Me.tab_initiative.SuspendLayout()
        CType(Me.dginitiative, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_sincerity.SuspendLayout()
        CType(Me.dgsincerity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_g10.SuspendLayout()
        CType(Me.Xtratab2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Xtratab2.SuspendLayout()
        Me.tab_punctuality.SuspendLayout()
        CType(Me.dgpunctuality, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tab_discipline.SuspendLayout()
        CType(Me.dgdiscipline, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(426, 15)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 14)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Period : "
        '
        'cbo_period
        '
        Me.cbo_period.Location = New System.Drawing.Point(485, 13)
        Me.cbo_period.Name = "cbo_period"
        Me.cbo_period.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cbo_period.Properties.Items.AddRange(New Object() {"First Grading", "Second Grading", "Third Grading", "Fourth Grading"})
        Me.cbo_period.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor
        Me.cbo_period.Size = New System.Drawing.Size(100, 20)
        Me.cbo_period.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(595, 15)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 14)
        Me.Label3.TabIndex = 17
        Me.Label3.Text = "Subject : "
        '
        'cbo_subjects
        '
        Me.cbo_subjects.Location = New System.Drawing.Point(662, 13)
        Me.cbo_subjects.Name = "cbo_subjects"
        Me.cbo_subjects.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cbo_subjects.Size = New System.Drawing.Size(213, 20)
        Me.cbo_subjects.TabIndex = 16
        '
        'PanelControl1
        '
        Me.PanelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl1.Controls.Add(Me.Label1)
        Me.PanelControl1.Controls.Add(Me.Label2)
        Me.PanelControl1.Controls.Add(Me.SeparatorControl4)
        Me.PanelControl1.Controls.Add(Me.PanelControl6)
        Me.PanelControl1.Controls.Add(Me.SeparatorControl2)
        Me.PanelControl1.Controls.Add(Me.PanelControl4)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl1.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(997, 80)
        Me.PanelControl1.TabIndex = 19
        '
        'Label1
        '
        Me.Label1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(895, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(86, 14)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "SY 2018-2019"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(563, 58)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(157, 14)
        Me.Label2.TabIndex = 11
        Me.Label2.Text = "Grade Recording Module"
        '
        'SeparatorControl4
        '
        Me.SeparatorControl4.LineAlignment = DevExpress.XtraEditors.Alignment.Near
        Me.SeparatorControl4.LineOrientation = System.Windows.Forms.Orientation.Vertical
        Me.SeparatorControl4.Location = New System.Drawing.Point(237, -9)
        Me.SeparatorControl4.Name = "SeparatorControl4"
        Me.SeparatorControl4.Size = New System.Drawing.Size(19, 95)
        Me.SeparatorControl4.TabIndex = 8
        '
        'PanelControl6
        '
        Me.PanelControl6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl6.Controls.Add(Me.btn_refresh)
        Me.PanelControl6.Controls.Add(Me.btn_printprev)
        Me.PanelControl6.Controls.Add(Me.PanelControl7)
        Me.PanelControl6.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl6.Location = New System.Drawing.Point(98, 0)
        Me.PanelControl6.Name = "PanelControl6"
        Me.PanelControl6.Size = New System.Drawing.Size(144, 80)
        Me.PanelControl6.TabIndex = 7
        '
        'btn_refresh
        '
        Me.btn_refresh.AppearanceHovered.BackColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_refresh.AppearanceHovered.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_refresh.AppearanceHovered.Options.UseBackColor = True
        Me.btn_refresh.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_refresh.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_refresh.ImageOptions.Image = CType(resources.GetObject("btn_refresh.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_refresh.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.TopCenter
        Me.btn_refresh.Location = New System.Drawing.Point(87, 0)
        Me.btn_refresh.Name = "btn_refresh"
        Me.btn_refresh.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.[False]
        Me.btn_refresh.Size = New System.Drawing.Size(46, 58)
        Me.btn_refresh.TabIndex = 8
        Me.btn_refresh.Text = "Refresh"
        '
        'btn_printprev
        '
        Me.btn_printprev.AppearanceHovered.BackColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_printprev.AppearanceHovered.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_printprev.AppearanceHovered.BorderColor = System.Drawing.Color.Silver
        Me.btn_printprev.AppearanceHovered.Options.UseBackColor = True
        Me.btn_printprev.AppearanceHovered.Options.UseBorderColor = True
        Me.btn_printprev.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_printprev.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_printprev.ImageOptions.Image = CType(resources.GetObject("btn_printprev.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_printprev.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.TopCenter
        Me.btn_printprev.Location = New System.Drawing.Point(0, 0)
        Me.btn_printprev.Name = "btn_printprev"
        Me.btn_printprev.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.[False]
        Me.btn_printprev.Size = New System.Drawing.Size(87, 58)
        Me.btn_printprev.TabIndex = 12
        Me.btn_printprev.Text = "Print Preview"
        '
        'PanelControl7
        '
        Me.PanelControl7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl7.Controls.Add(Me.LabelControl2)
        Me.PanelControl7.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelControl7.Location = New System.Drawing.Point(0, 58)
        Me.PanelControl7.Name = "PanelControl7"
        Me.PanelControl7.Size = New System.Drawing.Size(144, 22)
        Me.PanelControl7.TabIndex = 6
        '
        'LabelControl2
        '
        Me.LabelControl2.Location = New System.Drawing.Point(38, 3)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(71, 13)
        Me.LabelControl2.TabIndex = 0
        Me.LabelControl2.Text = "Printing Option"
        '
        'SeparatorControl2
        '
        Me.SeparatorControl2.Dock = System.Windows.Forms.DockStyle.Left
        Me.SeparatorControl2.LineAlignment = DevExpress.XtraEditors.Alignment.Near
        Me.SeparatorControl2.LineOrientation = System.Windows.Forms.Orientation.Vertical
        Me.SeparatorControl2.Location = New System.Drawing.Point(79, 0)
        Me.SeparatorControl2.Name = "SeparatorControl2"
        Me.SeparatorControl2.Size = New System.Drawing.Size(19, 80)
        Me.SeparatorControl2.TabIndex = 6
        '
        'PanelControl4
        '
        Me.PanelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl4.Controls.Add(Me.btn_save)
        Me.PanelControl4.Controls.Add(Me.PanelControl5)
        Me.PanelControl4.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl4.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(79, 80)
        Me.PanelControl4.TabIndex = 5
        '
        'btn_save
        '
        Me.btn_save.AppearanceHovered.BackColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_save.AppearanceHovered.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.btn_save.AppearanceHovered.BorderColor = System.Drawing.Color.Silver
        Me.btn_save.AppearanceHovered.Options.UseBackColor = True
        Me.btn_save.AppearanceHovered.Options.UseBorderColor = True
        Me.btn_save.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_save.Dock = System.Windows.Forms.DockStyle.Left
        Me.btn_save.ImageOptions.Image = CType(resources.GetObject("btn_save.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_save.ImageOptions.ImageToTextAlignment = DevExpress.XtraEditors.ImageAlignToText.TopCenter
        Me.btn_save.Location = New System.Drawing.Point(0, 0)
        Me.btn_save.Name = "btn_save"
        Me.btn_save.ShowFocusRectangle = DevExpress.Utils.DefaultBoolean.[False]
        Me.btn_save.Size = New System.Drawing.Size(79, 58)
        Me.btn_save.TabIndex = 12
        Me.btn_save.Text = "Save"
        '
        'PanelControl5
        '
        Me.PanelControl5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl5.Controls.Add(Me.LabelControl1)
        Me.PanelControl5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelControl5.Location = New System.Drawing.Point(0, 58)
        Me.PanelControl5.Name = "PanelControl5"
        Me.PanelControl5.Size = New System.Drawing.Size(79, 22)
        Me.PanelControl5.TabIndex = 6
        '
        'LabelControl1
        '
        Me.LabelControl1.Location = New System.Drawing.Point(13, 3)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(51, 13)
        Me.LabelControl1.TabIndex = 0
        Me.LabelControl1.Text = "Navigation"
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.btn_load)
        Me.PanelControl3.Controls.Add(Me.PanelControl2)
        Me.PanelControl3.Controls.Add(Me.cbo_subjects)
        Me.PanelControl3.Controls.Add(Me.cbo_period)
        Me.PanelControl3.Controls.Add(Me.Label3)
        Me.PanelControl3.Controls.Add(Me.Label5)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl3.Location = New System.Drawing.Point(0, 80)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(997, 500)
        Me.PanelControl3.TabIndex = 8
        '
        'btn_load
        '
        Me.btn_load.Location = New System.Drawing.Point(888, 12)
        Me.btn_load.Name = "btn_load"
        Me.btn_load.Size = New System.Drawing.Size(75, 23)
        Me.btn_load.TabIndex = 20
        Me.btn_load.Text = "Load"
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.XtraTabControl1)
        Me.PanelControl2.Location = New System.Drawing.Point(18, 41)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(963, 445)
        Me.PanelControl2.TabIndex = 19
        '
        'XtraTabControl1
        '
        Me.XtraTabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl1.Location = New System.Drawing.Point(2, 2)
        Me.XtraTabControl1.Name = "XtraTabControl1"
        Me.XtraTabControl1.SelectedTabPage = Me.tab_g7
        Me.XtraTabControl1.Size = New System.Drawing.Size(959, 441)
        Me.XtraTabControl1.TabIndex = 9
        Me.XtraTabControl1.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tab_g7, Me.tab_g8, Me.tab_g9, Me.tab_g10})
        '
        'tab_g7
        '
        Me.tab_g7.Controls.Add(Me.XtraTabControl2)
        Me.tab_g7.Name = "tab_g7"
        Me.tab_g7.Size = New System.Drawing.Size(957, 416)
        Me.tab_g7.Text = "Grade 7"
        '
        'XtraTabControl2
        '
        Me.XtraTabControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl2.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl2.Name = "XtraTabControl2"
        Me.XtraTabControl2.SelectedTabPage = Me.tab_generosity
        Me.XtraTabControl2.Size = New System.Drawing.Size(957, 416)
        Me.XtraTabControl2.TabIndex = 8
        Me.XtraTabControl2.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tab_generosity, Me.tab_patience})
        '
        'tab_generosity
        '
        Me.tab_generosity.Controls.Add(Me.dg_generosity)
        Me.tab_generosity.Name = "tab_generosity"
        Me.tab_generosity.Size = New System.Drawing.Size(955, 391)
        Me.tab_generosity.Text = "Generosity"
        '
        'dg_generosity
        '
        Me.dg_generosity.AllowUserToAddRows = False
        Me.dg_generosity.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dg_generosity.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dg_generosity.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dg_generosity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dg_generosity.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_studid, Me.col_studname, Me.col_recitation1, Me.col_recitation2, Me.col_quiz1, Me.col_quiz2, Me.col_quiz3, Me.col_proj1, Me.col_qexam, Me.col_finalgrade, Me.col_gradeid})
        Me.dg_generosity.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dg_generosity.Location = New System.Drawing.Point(0, 0)
        Me.dg_generosity.MultiSelect = False
        Me.dg_generosity.Name = "dg_generosity"
        Me.dg_generosity.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dg_generosity.Size = New System.Drawing.Size(955, 391)
        Me.dg_generosity.TabIndex = 6
        '
        'col_studid
        '
        Me.col_studid.DataPropertyName = "stud_id"
        Me.col_studid.HeaderText = "Student ID"
        Me.col_studid.Name = "col_studid"
        '
        'col_studname
        '
        Me.col_studname.DataPropertyName = "stud_name"
        Me.col_studname.HeaderText = "Name"
        Me.col_studname.Name = "col_studname"
        Me.col_studname.Width = 250
        '
        'col_recitation1
        '
        Me.col_recitation1.DataPropertyName = "grade_recitation1"
        Me.col_recitation1.HeaderText = "Recitation 1"
        Me.col_recitation1.Name = "col_recitation1"
        Me.col_recitation1.Width = 70
        '
        'col_recitation2
        '
        Me.col_recitation2.DataPropertyName = "grade_recitation2"
        Me.col_recitation2.HeaderText = "Recitation 2"
        Me.col_recitation2.Name = "col_recitation2"
        Me.col_recitation2.Width = 70
        '
        'col_quiz1
        '
        Me.col_quiz1.DataPropertyName = "grade_quiz1"
        Me.col_quiz1.HeaderText = "Quiz 1"
        Me.col_quiz1.Name = "col_quiz1"
        Me.col_quiz1.Width = 75
        '
        'col_quiz2
        '
        Me.col_quiz2.DataPropertyName = "grade_quiz2"
        Me.col_quiz2.HeaderText = "Quiz 2"
        Me.col_quiz2.Name = "col_quiz2"
        Me.col_quiz2.Width = 75
        '
        'col_quiz3
        '
        Me.col_quiz3.DataPropertyName = "grade_quiz3"
        Me.col_quiz3.HeaderText = "Quiz 3"
        Me.col_quiz3.Name = "col_quiz3"
        Me.col_quiz3.Width = 75
        '
        'col_proj1
        '
        Me.col_proj1.DataPropertyName = "grade_project"
        Me.col_proj1.HeaderText = "Project"
        Me.col_proj1.Name = "col_proj1"
        Me.col_proj1.Width = 95
        '
        'col_qexam
        '
        Me.col_qexam.DataPropertyName = "grade_exam"
        Me.col_qexam.HeaderText = "Quarter Exam"
        Me.col_qexam.Name = "col_qexam"
        Me.col_qexam.Width = 95
        '
        'col_finalgrade
        '
        Me.col_finalgrade.DataPropertyName = "grade_final"
        Me.col_finalgrade.HeaderText = "Final Grade"
        Me.col_finalgrade.Name = "col_finalgrade"
        '
        'col_gradeid
        '
        Me.col_gradeid.DataPropertyName = "grade_id"
        Me.col_gradeid.HeaderText = "Grade ID"
        Me.col_gradeid.Name = "col_gradeid"
        Me.col_gradeid.Visible = False
        '
        'tab_patience
        '
        Me.tab_patience.Controls.Add(Me.dgpatience)
        Me.tab_patience.Name = "tab_patience"
        Me.tab_patience.Size = New System.Drawing.Size(951, 388)
        Me.tab_patience.Text = "Patience"
        '
        'dgpatience
        '
        Me.dgpatience.AllowUserToAddRows = False
        Me.dgpatience.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dgpatience.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgpatience.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle2
        Me.dgpatience.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpatience.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn64, Me.DataGridViewTextBoxColumn71})
        Me.dgpatience.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgpatience.Location = New System.Drawing.Point(0, 0)
        Me.dgpatience.MultiSelect = False
        Me.dgpatience.Name = "dgpatience"
        Me.dgpatience.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgpatience.Size = New System.Drawing.Size(951, 388)
        Me.dgpatience.TabIndex = 7
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 250
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 70
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 70
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.Width = 75
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn15.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.Width = 75
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn16.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.Width = 75
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn17.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.Width = 95
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn18.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.Width = 95
        '
        'DataGridViewTextBoxColumn64
        '
        Me.DataGridViewTextBoxColumn64.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn64.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn64.Name = "DataGridViewTextBoxColumn64"
        '
        'DataGridViewTextBoxColumn71
        '
        Me.DataGridViewTextBoxColumn71.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn71.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn71.Name = "DataGridViewTextBoxColumn71"
        Me.DataGridViewTextBoxColumn71.Visible = False
        '
        'tab_g8
        '
        Me.tab_g8.Controls.Add(Me.XtraTabControl3)
        Me.tab_g8.Name = "tab_g8"
        Me.tab_g8.Size = New System.Drawing.Size(957, 416)
        Me.tab_g8.Text = "Grade 8"
        '
        'XtraTabControl3
        '
        Me.XtraTabControl3.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl3.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl3.Name = "XtraTabControl3"
        Me.XtraTabControl3.SelectedTabPage = Me.tab_hardwork
        Me.XtraTabControl3.Size = New System.Drawing.Size(957, 416)
        Me.XtraTabControl3.TabIndex = 9
        Me.XtraTabControl3.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tab_responsibility, Me.tab_hardwork})
        '
        'tab_hardwork
        '
        Me.tab_hardwork.Controls.Add(Me.dghardwork)
        Me.tab_hardwork.Name = "tab_hardwork"
        Me.tab_hardwork.Size = New System.Drawing.Size(955, 391)
        Me.tab_hardwork.Text = "Hardwork"
        '
        'dghardwork
        '
        Me.dghardwork.AllowUserToAddRows = False
        Me.dghardwork.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dghardwork.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dghardwork.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dghardwork.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dghardwork.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24, Me.DataGridViewTextBoxColumn25, Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn27, Me.DataGridViewTextBoxColumn66, Me.DataGridViewTextBoxColumn73})
        Me.dghardwork.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dghardwork.Location = New System.Drawing.Point(0, 0)
        Me.dghardwork.MultiSelect = False
        Me.dghardwork.Name = "dghardwork"
        Me.dghardwork.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dghardwork.Size = New System.Drawing.Size(955, 391)
        Me.dghardwork.TabIndex = 7
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn19.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn20.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.Width = 250
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn21.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.Width = 70
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn22.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.Width = 70
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn23.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        Me.DataGridViewTextBoxColumn23.Width = 75
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn24.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        Me.DataGridViewTextBoxColumn24.Width = 75
        '
        'DataGridViewTextBoxColumn25
        '
        Me.DataGridViewTextBoxColumn25.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn25.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        Me.DataGridViewTextBoxColumn25.Width = 75
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn26.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        Me.DataGridViewTextBoxColumn26.Width = 95
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn27.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        Me.DataGridViewTextBoxColumn27.Width = 95
        '
        'DataGridViewTextBoxColumn66
        '
        Me.DataGridViewTextBoxColumn66.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn66.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn66.Name = "DataGridViewTextBoxColumn66"
        '
        'DataGridViewTextBoxColumn73
        '
        Me.DataGridViewTextBoxColumn73.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn73.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn73.Name = "DataGridViewTextBoxColumn73"
        Me.DataGridViewTextBoxColumn73.Visible = False
        '
        'tab_responsibility
        '
        Me.tab_responsibility.Controls.Add(Me.dgresponsibility)
        Me.tab_responsibility.Name = "tab_responsibility"
        Me.tab_responsibility.Size = New System.Drawing.Size(955, 391)
        Me.tab_responsibility.Text = "Responsibility"
        '
        'dgresponsibility
        '
        Me.dgresponsibility.AllowUserToAddRows = False
        Me.dgresponsibility.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dgresponsibility.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgresponsibility.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dgresponsibility.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgresponsibility.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn65, Me.DataGridViewTextBoxColumn72})
        Me.dgresponsibility.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgresponsibility.Location = New System.Drawing.Point(0, 0)
        Me.dgresponsibility.MultiSelect = False
        Me.dgresponsibility.Name = "dgresponsibility"
        Me.dgresponsibility.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgresponsibility.Size = New System.Drawing.Size(955, 391)
        Me.dgresponsibility.TabIndex = 7
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn1.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 250
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 70
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 70
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 75
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 75
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 75
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 95
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 95
        '
        'DataGridViewTextBoxColumn65
        '
        Me.DataGridViewTextBoxColumn65.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn65.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn65.Name = "DataGridViewTextBoxColumn65"
        '
        'DataGridViewTextBoxColumn72
        '
        Me.DataGridViewTextBoxColumn72.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn72.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn72.Name = "DataGridViewTextBoxColumn72"
        Me.DataGridViewTextBoxColumn72.Visible = False
        '
        'tab_g9
        '
        Me.tab_g9.Controls.Add(Me.XtraTabControl4)
        Me.tab_g9.Name = "tab_g9"
        Me.tab_g9.Size = New System.Drawing.Size(957, 416)
        Me.tab_g9.Text = "Grade 9"
        '
        'XtraTabControl4
        '
        Me.XtraTabControl4.Dock = System.Windows.Forms.DockStyle.Fill
        Me.XtraTabControl4.Location = New System.Drawing.Point(0, 0)
        Me.XtraTabControl4.Name = "XtraTabControl4"
        Me.XtraTabControl4.SelectedTabPage = Me.tab_initiative
        Me.XtraTabControl4.Size = New System.Drawing.Size(957, 416)
        Me.XtraTabControl4.TabIndex = 10
        Me.XtraTabControl4.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tab_initiative, Me.tab_sincerity})
        '
        'tab_initiative
        '
        Me.tab_initiative.Controls.Add(Me.dginitiative)
        Me.tab_initiative.Name = "tab_initiative"
        Me.tab_initiative.Size = New System.Drawing.Size(955, 391)
        Me.tab_initiative.Text = "Initiative"
        '
        'dginitiative
        '
        Me.dginitiative.AllowUserToAddRows = False
        Me.dginitiative.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dginitiative.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dginitiative.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle5
        Me.dginitiative.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dginitiative.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34, Me.DataGridViewTextBoxColumn35, Me.DataGridViewTextBoxColumn36, Me.DataGridViewTextBoxColumn37, Me.DataGridViewTextBoxColumn74})
        Me.dginitiative.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dginitiative.Location = New System.Drawing.Point(0, 0)
        Me.dginitiative.MultiSelect = False
        Me.dginitiative.Name = "dginitiative"
        Me.dginitiative.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dginitiative.Size = New System.Drawing.Size(955, 391)
        Me.dginitiative.TabIndex = 7
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn28.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn29.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        Me.DataGridViewTextBoxColumn29.Width = 250
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn30.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        Me.DataGridViewTextBoxColumn30.Width = 70
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn31.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        Me.DataGridViewTextBoxColumn31.Width = 70
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn32.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        Me.DataGridViewTextBoxColumn32.Width = 75
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn33.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        Me.DataGridViewTextBoxColumn33.Width = 75
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn34.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        Me.DataGridViewTextBoxColumn34.Width = 75
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn35.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        Me.DataGridViewTextBoxColumn35.Width = 95
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn36.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        Me.DataGridViewTextBoxColumn36.Width = 95
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn37.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        '
        'DataGridViewTextBoxColumn74
        '
        Me.DataGridViewTextBoxColumn74.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn74.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn74.Name = "DataGridViewTextBoxColumn74"
        Me.DataGridViewTextBoxColumn74.Visible = False
        '
        'tab_sincerity
        '
        Me.tab_sincerity.Controls.Add(Me.dgsincerity)
        Me.tab_sincerity.Name = "tab_sincerity"
        Me.tab_sincerity.Size = New System.Drawing.Size(955, 391)
        Me.tab_sincerity.Text = "Sincerity"
        '
        'dgsincerity
        '
        Me.dgsincerity.AllowUserToAddRows = False
        Me.dgsincerity.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dgsincerity.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgsincerity.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle6
        Me.dgsincerity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgsincerity.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn38, Me.DataGridViewTextBoxColumn39, Me.DataGridViewTextBoxColumn40, Me.DataGridViewTextBoxColumn41, Me.DataGridViewTextBoxColumn42, Me.DataGridViewTextBoxColumn43, Me.DataGridViewTextBoxColumn44, Me.DataGridViewTextBoxColumn45, Me.DataGridViewTextBoxColumn67, Me.DataGridViewTextBoxColumn68, Me.DataGridViewTextBoxColumn75})
        Me.dgsincerity.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgsincerity.Location = New System.Drawing.Point(0, 0)
        Me.dgsincerity.MultiSelect = False
        Me.dgsincerity.Name = "dgsincerity"
        Me.dgsincerity.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgsincerity.Size = New System.Drawing.Size(955, 391)
        Me.dgsincerity.TabIndex = 7
        '
        'DataGridViewTextBoxColumn38
        '
        Me.DataGridViewTextBoxColumn38.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn38.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn38.Name = "DataGridViewTextBoxColumn38"
        '
        'DataGridViewTextBoxColumn39
        '
        Me.DataGridViewTextBoxColumn39.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn39.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn39.Name = "DataGridViewTextBoxColumn39"
        Me.DataGridViewTextBoxColumn39.Width = 250
        '
        'DataGridViewTextBoxColumn40
        '
        Me.DataGridViewTextBoxColumn40.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn40.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn40.Name = "DataGridViewTextBoxColumn40"
        Me.DataGridViewTextBoxColumn40.Width = 70
        '
        'DataGridViewTextBoxColumn41
        '
        Me.DataGridViewTextBoxColumn41.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn41.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn41.Name = "DataGridViewTextBoxColumn41"
        Me.DataGridViewTextBoxColumn41.Width = 70
        '
        'DataGridViewTextBoxColumn42
        '
        Me.DataGridViewTextBoxColumn42.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn42.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn42.Name = "DataGridViewTextBoxColumn42"
        Me.DataGridViewTextBoxColumn42.Width = 75
        '
        'DataGridViewTextBoxColumn43
        '
        Me.DataGridViewTextBoxColumn43.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn43.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn43.Name = "DataGridViewTextBoxColumn43"
        Me.DataGridViewTextBoxColumn43.Width = 75
        '
        'DataGridViewTextBoxColumn44
        '
        Me.DataGridViewTextBoxColumn44.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn44.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn44.Name = "DataGridViewTextBoxColumn44"
        Me.DataGridViewTextBoxColumn44.Width = 75
        '
        'DataGridViewTextBoxColumn45
        '
        Me.DataGridViewTextBoxColumn45.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn45.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn45.Name = "DataGridViewTextBoxColumn45"
        Me.DataGridViewTextBoxColumn45.Width = 95
        '
        'DataGridViewTextBoxColumn67
        '
        Me.DataGridViewTextBoxColumn67.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn67.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn67.Name = "DataGridViewTextBoxColumn67"
        Me.DataGridViewTextBoxColumn67.Width = 95
        '
        'DataGridViewTextBoxColumn68
        '
        Me.DataGridViewTextBoxColumn68.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn68.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn68.Name = "DataGridViewTextBoxColumn68"
        '
        'DataGridViewTextBoxColumn75
        '
        Me.DataGridViewTextBoxColumn75.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn75.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn75.Name = "DataGridViewTextBoxColumn75"
        Me.DataGridViewTextBoxColumn75.Visible = False
        '
        'tab_g10
        '
        Me.tab_g10.Controls.Add(Me.Xtratab2)
        Me.tab_g10.Name = "tab_g10"
        Me.tab_g10.Size = New System.Drawing.Size(957, 416)
        Me.tab_g10.Text = "Grade 10"
        '
        'Xtratab2
        '
        Me.Xtratab2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Xtratab2.Location = New System.Drawing.Point(0, 0)
        Me.Xtratab2.Name = "Xtratab2"
        Me.Xtratab2.SelectedTabPage = Me.tab_punctuality
        Me.Xtratab2.Size = New System.Drawing.Size(957, 416)
        Me.Xtratab2.TabIndex = 10
        Me.Xtratab2.TabPages.AddRange(New DevExpress.XtraTab.XtraTabPage() {Me.tab_discipline, Me.tab_punctuality})
        '
        'tab_punctuality
        '
        Me.tab_punctuality.Controls.Add(Me.dgpunctuality)
        Me.tab_punctuality.Name = "tab_punctuality"
        Me.tab_punctuality.Size = New System.Drawing.Size(955, 391)
        Me.tab_punctuality.Text = "Punctuality"
        '
        'dgpunctuality
        '
        Me.dgpunctuality.AllowUserToAddRows = False
        Me.dgpunctuality.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dgpunctuality.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle7.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgpunctuality.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle7
        Me.dgpunctuality.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpunctuality.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn55, Me.DataGridViewTextBoxColumn56, Me.DataGridViewTextBoxColumn57, Me.DataGridViewTextBoxColumn58, Me.DataGridViewTextBoxColumn59, Me.DataGridViewTextBoxColumn60, Me.DataGridViewTextBoxColumn61, Me.DataGridViewTextBoxColumn62, Me.DataGridViewTextBoxColumn63, Me.DataGridViewTextBoxColumn69, Me.DataGridViewTextBoxColumn77})
        Me.dgpunctuality.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgpunctuality.Location = New System.Drawing.Point(0, 0)
        Me.dgpunctuality.MultiSelect = False
        Me.dgpunctuality.Name = "dgpunctuality"
        Me.dgpunctuality.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgpunctuality.Size = New System.Drawing.Size(955, 391)
        Me.dgpunctuality.TabIndex = 7
        '
        'DataGridViewTextBoxColumn55
        '
        Me.DataGridViewTextBoxColumn55.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn55.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn55.Name = "DataGridViewTextBoxColumn55"
        '
        'DataGridViewTextBoxColumn56
        '
        Me.DataGridViewTextBoxColumn56.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn56.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn56.Name = "DataGridViewTextBoxColumn56"
        Me.DataGridViewTextBoxColumn56.Width = 250
        '
        'DataGridViewTextBoxColumn57
        '
        Me.DataGridViewTextBoxColumn57.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn57.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn57.Name = "DataGridViewTextBoxColumn57"
        Me.DataGridViewTextBoxColumn57.Width = 70
        '
        'DataGridViewTextBoxColumn58
        '
        Me.DataGridViewTextBoxColumn58.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn58.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn58.Name = "DataGridViewTextBoxColumn58"
        Me.DataGridViewTextBoxColumn58.Width = 70
        '
        'DataGridViewTextBoxColumn59
        '
        Me.DataGridViewTextBoxColumn59.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn59.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn59.Name = "DataGridViewTextBoxColumn59"
        Me.DataGridViewTextBoxColumn59.Width = 75
        '
        'DataGridViewTextBoxColumn60
        '
        Me.DataGridViewTextBoxColumn60.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn60.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn60.Name = "DataGridViewTextBoxColumn60"
        Me.DataGridViewTextBoxColumn60.Width = 75
        '
        'DataGridViewTextBoxColumn61
        '
        Me.DataGridViewTextBoxColumn61.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn61.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn61.Name = "DataGridViewTextBoxColumn61"
        Me.DataGridViewTextBoxColumn61.Width = 75
        '
        'DataGridViewTextBoxColumn62
        '
        Me.DataGridViewTextBoxColumn62.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn62.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn62.Name = "DataGridViewTextBoxColumn62"
        Me.DataGridViewTextBoxColumn62.Width = 95
        '
        'DataGridViewTextBoxColumn63
        '
        Me.DataGridViewTextBoxColumn63.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn63.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn63.Name = "DataGridViewTextBoxColumn63"
        Me.DataGridViewTextBoxColumn63.Width = 95
        '
        'DataGridViewTextBoxColumn69
        '
        Me.DataGridViewTextBoxColumn69.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn69.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn69.Name = "DataGridViewTextBoxColumn69"
        '
        'DataGridViewTextBoxColumn77
        '
        Me.DataGridViewTextBoxColumn77.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn77.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn77.Name = "DataGridViewTextBoxColumn77"
        Me.DataGridViewTextBoxColumn77.Visible = False
        '
        'tab_discipline
        '
        Me.tab_discipline.Controls.Add(Me.dgdiscipline)
        Me.tab_discipline.Name = "tab_discipline"
        Me.tab_discipline.Size = New System.Drawing.Size(955, 391)
        Me.tab_discipline.Text = "Discipline"
        '
        'dgdiscipline
        '
        Me.dgdiscipline.AllowUserToAddRows = False
        Me.dgdiscipline.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer), CType(CType(215, Byte), Integer))
        Me.dgdiscipline.BorderStyle = System.Windows.Forms.BorderStyle.None
        DataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle8.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgdiscipline.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle8
        Me.dgdiscipline.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgdiscipline.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn46, Me.DataGridViewTextBoxColumn47, Me.DataGridViewTextBoxColumn48, Me.DataGridViewTextBoxColumn49, Me.DataGridViewTextBoxColumn50, Me.DataGridViewTextBoxColumn51, Me.DataGridViewTextBoxColumn52, Me.DataGridViewTextBoxColumn53, Me.DataGridViewTextBoxColumn54, Me.DataGridViewTextBoxColumn70, Me.DataGridViewTextBoxColumn76})
        Me.dgdiscipline.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgdiscipline.Location = New System.Drawing.Point(0, 0)
        Me.dgdiscipline.MultiSelect = False
        Me.dgdiscipline.Name = "dgdiscipline"
        Me.dgdiscipline.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgdiscipline.Size = New System.Drawing.Size(955, 391)
        Me.dgdiscipline.TabIndex = 7
        '
        'DataGridViewTextBoxColumn46
        '
        Me.DataGridViewTextBoxColumn46.DataPropertyName = "stud_id"
        Me.DataGridViewTextBoxColumn46.HeaderText = "Student ID"
        Me.DataGridViewTextBoxColumn46.Name = "DataGridViewTextBoxColumn46"
        '
        'DataGridViewTextBoxColumn47
        '
        Me.DataGridViewTextBoxColumn47.DataPropertyName = "stud_name"
        Me.DataGridViewTextBoxColumn47.HeaderText = "Name"
        Me.DataGridViewTextBoxColumn47.Name = "DataGridViewTextBoxColumn47"
        Me.DataGridViewTextBoxColumn47.Width = 250
        '
        'DataGridViewTextBoxColumn48
        '
        Me.DataGridViewTextBoxColumn48.DataPropertyName = "grade_recitation1"
        Me.DataGridViewTextBoxColumn48.HeaderText = "Recitation 1"
        Me.DataGridViewTextBoxColumn48.Name = "DataGridViewTextBoxColumn48"
        Me.DataGridViewTextBoxColumn48.Width = 70
        '
        'DataGridViewTextBoxColumn49
        '
        Me.DataGridViewTextBoxColumn49.DataPropertyName = "grade_recitation2"
        Me.DataGridViewTextBoxColumn49.HeaderText = "Recitation 2"
        Me.DataGridViewTextBoxColumn49.Name = "DataGridViewTextBoxColumn49"
        Me.DataGridViewTextBoxColumn49.Width = 70
        '
        'DataGridViewTextBoxColumn50
        '
        Me.DataGridViewTextBoxColumn50.DataPropertyName = "grade_quiz1"
        Me.DataGridViewTextBoxColumn50.HeaderText = "Quiz 1"
        Me.DataGridViewTextBoxColumn50.Name = "DataGridViewTextBoxColumn50"
        Me.DataGridViewTextBoxColumn50.Width = 75
        '
        'DataGridViewTextBoxColumn51
        '
        Me.DataGridViewTextBoxColumn51.DataPropertyName = "grade_quiz2"
        Me.DataGridViewTextBoxColumn51.HeaderText = "Quiz 2"
        Me.DataGridViewTextBoxColumn51.Name = "DataGridViewTextBoxColumn51"
        Me.DataGridViewTextBoxColumn51.Width = 75
        '
        'DataGridViewTextBoxColumn52
        '
        Me.DataGridViewTextBoxColumn52.DataPropertyName = "grade_quiz3"
        Me.DataGridViewTextBoxColumn52.HeaderText = "Quiz 3"
        Me.DataGridViewTextBoxColumn52.Name = "DataGridViewTextBoxColumn52"
        Me.DataGridViewTextBoxColumn52.Width = 75
        '
        'DataGridViewTextBoxColumn53
        '
        Me.DataGridViewTextBoxColumn53.DataPropertyName = "grade_project"
        Me.DataGridViewTextBoxColumn53.HeaderText = "Project"
        Me.DataGridViewTextBoxColumn53.Name = "DataGridViewTextBoxColumn53"
        Me.DataGridViewTextBoxColumn53.Width = 95
        '
        'DataGridViewTextBoxColumn54
        '
        Me.DataGridViewTextBoxColumn54.DataPropertyName = "grade_exam"
        Me.DataGridViewTextBoxColumn54.HeaderText = "Quarter Exam"
        Me.DataGridViewTextBoxColumn54.Name = "DataGridViewTextBoxColumn54"
        Me.DataGridViewTextBoxColumn54.Width = 95
        '
        'DataGridViewTextBoxColumn70
        '
        Me.DataGridViewTextBoxColumn70.DataPropertyName = "grade_final"
        Me.DataGridViewTextBoxColumn70.HeaderText = "Final Grade"
        Me.DataGridViewTextBoxColumn70.Name = "DataGridViewTextBoxColumn70"
        '
        'DataGridViewTextBoxColumn76
        '
        Me.DataGridViewTextBoxColumn76.DataPropertyName = "grade_id"
        Me.DataGridViewTextBoxColumn76.HeaderText = "Grade ID"
        Me.DataGridViewTextBoxColumn76.Name = "DataGridViewTextBoxColumn76"
        Me.DataGridViewTextBoxColumn76.Visible = False
        '
        'uc_grades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.PanelControl3)
        Me.Controls.Add(Me.PanelControl1)
        Me.Name = "uc_grades"
        Me.Size = New System.Drawing.Size(997, 580)
        CType(Me.cbo_period.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cbo_subjects.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.SeparatorControl4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl6.ResumeLayout(False)
        CType(Me.PanelControl7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl7.ResumeLayout(False)
        Me.PanelControl7.PerformLayout()
        CType(Me.SeparatorControl2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl5.ResumeLayout(False)
        Me.PanelControl5.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        Me.PanelControl3.PerformLayout()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        CType(Me.XtraTabControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl1.ResumeLayout(False)
        Me.tab_g7.ResumeLayout(False)
        CType(Me.XtraTabControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl2.ResumeLayout(False)
        Me.tab_generosity.ResumeLayout(False)
        CType(Me.dg_generosity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_patience.ResumeLayout(False)
        CType(Me.dgpatience, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_g8.ResumeLayout(False)
        CType(Me.XtraTabControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl3.ResumeLayout(False)
        Me.tab_hardwork.ResumeLayout(False)
        CType(Me.dghardwork, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_responsibility.ResumeLayout(False)
        CType(Me.dgresponsibility, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_g9.ResumeLayout(False)
        CType(Me.XtraTabControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.XtraTabControl4.ResumeLayout(False)
        Me.tab_initiative.ResumeLayout(False)
        CType(Me.dginitiative, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_sincerity.ResumeLayout(False)
        CType(Me.dgsincerity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_g10.ResumeLayout(False)
        CType(Me.Xtratab2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Xtratab2.ResumeLayout(False)
        Me.tab_punctuality.ResumeLayout(False)
        CType(Me.dgpunctuality, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tab_discipline.ResumeLayout(False)
        CType(Me.dgdiscipline, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cbo_period As DevExpress.XtraEditors.ComboBoxEdit
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cbo_subjects As DevExpress.XtraEditors.ComboBoxEdit
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents SeparatorControl4 As DevExpress.XtraEditors.SeparatorControl
    Friend WithEvents PanelControl6 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_refresh As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_printprev As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PanelControl7 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents SeparatorControl2 As DevExpress.XtraEditors.SeparatorControl
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_save As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PanelControl5 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents XtraTabControl1 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tab_g10 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents Xtratab2 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tab_punctuality As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_discipline As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_g7 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabControl2 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tab_patience As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_generosity As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents dg_generosity As System.Windows.Forms.DataGridView
    Friend WithEvents tab_g8 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabControl3 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tab_hardwork As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_responsibility As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_g9 As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents XtraTabControl4 As DevExpress.XtraTab.XtraTabControl
    Friend WithEvents tab_sincerity As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents tab_initiative As DevExpress.XtraTab.XtraTabPage
    Friend WithEvents btn_load As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents col_studid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_studname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_recitation1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_recitation2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_proj1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_qexam As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_finalgrade As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gradeid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgpatience As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn64 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn71 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dghardwork As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn66 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn73 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgresponsibility As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn65 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn72 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dginitiative As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn74 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgsincerity As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn38 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn39 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn40 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn41 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn42 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn43 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn44 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn45 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn67 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn68 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn75 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgdiscipline As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn46 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn47 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn48 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn49 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn50 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn51 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn52 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn53 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn54 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn70 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn76 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents dgpunctuality As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn55 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn56 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn57 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn58 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn59 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn60 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn61 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn62 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn63 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn69 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn77 As System.Windows.Forms.DataGridViewTextBoxColumn

End Class
