﻿Public Class uc_enrollment


    Public Vals(10), S_ids As String


    Private Sub uc_enrollment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GridView1.BestFitColumns()
        dg_enrollment.DataSource = GetEnrolledStudents()

    End Sub

    Private Sub SimpleButton1_Click(sender As Object, e As EventArgs) Handles SimpleButton1.Click
        Command = 1
        frm_enrollstudents.ShowDialog()
    End Sub

    Private Sub SimpleButton5_Click(sender As Object, e As EventArgs) Handles SimpleButton5.Click
        dg_enrollment.DataSource = GetEnrolledStudents()
    End Sub

    Private Sub dg_enrollment_Click(sender As Object, e As EventArgs) Handles dg_enrollment.Click

    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        'DevExpress.XtraGrid.Views.Base.ColumnViewOptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Default

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "stud_id").ToString
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "stud_name").ToString
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "school_year").ToString
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "stud_gradelevel").ToString
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "stud_section").ToString
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "enroll_id").ToString
    
        S_ids = Vals(0).ToString

        'view.FocusedRowHandle
        ' view.FocusedColumn
        'MessageBox.Show(Vals(0).ToString)

        'place your code here
    End Sub

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles SimpleButton2.Click

        Command = 2

        frm_enrollstudents.txt_studid.Text = Vals(0)
        frm_enrollstudents.txt_studname.Text = Vals(1)
        frm_enrollstudents.cbo_gradelvl.Text = Vals(3)
        frm_enrollstudents.cbo_section.Text = Vals(4)


        'If frm_enrollstudents.cbo_gradelvl.Text = "Grade 7" Then

        '    frm_enrollstudents.cbo_section.Properties.Items.Clear()
        '    frm_enrollstudents.cbo_section.SelectedIndex = -1
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Generosity")
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Patience")

        'ElseIf frm_enrollstudents.cbo_gradelvl.Text = "Grade 8" Then

        '    frm_enrollstudents.cbo_section.Properties.Items.Clear()
        '    frm_enrollstudents.cbo_section.SelectedIndex = -1
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Responsibility")
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Hardwork")

        'ElseIf frm_enrollstudents.cbo_gradelvl.Text = "Grade 9" Then

        '    frm_enrollstudents.cbo_section.Properties.Items.Clear()
        '    frm_enrollstudents.cbo_section.SelectedIndex = -1
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Initiative")
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Sincerity")

        'ElseIf frm_enrollstudents.cbo_gradelvl.Text = "Grade 10" Then

        '    frm_enrollstudents.cbo_section.Properties.Items.Clear()
        '    frm_enrollstudents.cbo_section.SelectedIndex = -1
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Discipline")
        '    frm_enrollstudents.cbo_section.Properties.Items.Add("Punctuality")

        'End If

        frm_enrollstudents.dg_subjects.DataSource = GetEnrolledSubjects()
        frm_enrollstudents.ShowDialog()

    End Sub

    Private Sub SimpleButton3_Click(sender As Object, e As EventArgs) Handles SimpleButton3.Click
        frm_enrollstudents.dg_subjects.DataSource = GetEnrolledSubjects()
        DeleteEnrolled(Vals(5), Vals(0))
    End Sub

    Private Sub SimpleButton6_Click(sender As Object, e As EventArgs) Handles SimpleButton6.Click
        frm_rptenrolledlist.ShowDialog()
    End Sub
End Class
