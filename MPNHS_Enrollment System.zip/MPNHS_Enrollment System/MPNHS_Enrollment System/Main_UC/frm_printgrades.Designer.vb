﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_printgrades
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lbl_print = New System.Windows.Forms.Label()
        Me.lbl_dateprinted = New System.Windows.Forms.Label()
        Me.lbl_period = New System.Windows.Forms.Label()
        Me.lbl_subject = New System.Windows.Forms.Label()
        Me.lbl_gs = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dg_generosity = New System.Windows.Forms.DataGridView()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintDialog1 = New System.Windows.Forms.PrintDialog()
        Me.col_studid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_studname = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_recitation1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_recitation2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_quiz3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_proj1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_qexam = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_finalgrade = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.col_gradeid = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dg_generosity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.lbl_print)
        Me.Panel1.Controls.Add(Me.lbl_dateprinted)
        Me.Panel1.Controls.Add(Me.lbl_period)
        Me.Panel1.Controls.Add(Me.lbl_subject)
        Me.Panel1.Controls.Add(Me.lbl_gs)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.dg_generosity)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(700, 561)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.MPNHS_Enrollment_System.My.Resources.Resources.ph_57_batangas_malaking
        Me.PictureBox1.Location = New System.Drawing.Point(12, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(104, 80)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 25
        Me.PictureBox1.TabStop = False
        '
        'lbl_print
        '
        Me.lbl_print.AutoSize = True
        Me.lbl_print.Cursor = System.Windows.Forms.Cursors.Hand
        Me.lbl_print.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_print.ForeColor = System.Drawing.Color.Red
        Me.lbl_print.Location = New System.Drawing.Point(622, 28)
        Me.lbl_print.Name = "lbl_print"
        Me.lbl_print.Size = New System.Drawing.Size(42, 14)
        Me.lbl_print.TabIndex = 17
        Me.lbl_print.Text = "[Print]"
        '
        'lbl_dateprinted
        '
        Me.lbl_dateprinted.AutoSize = True
        Me.lbl_dateprinted.Location = New System.Drawing.Point(488, 119)
        Me.lbl_dateprinted.Name = "lbl_dateprinted"
        Me.lbl_dateprinted.Size = New System.Drawing.Size(43, 13)
        Me.lbl_dateprinted.TabIndex = 16
        Me.lbl_dateprinted.Text = "______"
        '
        'lbl_period
        '
        Me.lbl_period.AutoSize = True
        Me.lbl_period.Location = New System.Drawing.Point(488, 95)
        Me.lbl_period.Name = "lbl_period"
        Me.lbl_period.Size = New System.Drawing.Size(43, 13)
        Me.lbl_period.TabIndex = 15
        Me.lbl_period.Text = "______"
        '
        'lbl_subject
        '
        Me.lbl_subject.AutoSize = True
        Me.lbl_subject.Location = New System.Drawing.Point(109, 119)
        Me.lbl_subject.Name = "lbl_subject"
        Me.lbl_subject.Size = New System.Drawing.Size(43, 13)
        Me.lbl_subject.TabIndex = 14
        Me.lbl_subject.Text = "______"
        '
        'lbl_gs
        '
        Me.lbl_gs.AutoSize = True
        Me.lbl_gs.Location = New System.Drawing.Point(109, 95)
        Me.lbl_gs.Name = "lbl_gs"
        Me.lbl_gs.Size = New System.Drawing.Size(43, 13)
        Me.lbl_gs.TabIndex = 13
        Me.lbl_gs.Text = "______"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(404, 119)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(84, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Date Printed :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(404, 95)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Period :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(9, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 13)
        Me.Label3.TabIndex = 10
        Me.Label3.Text = "Subject :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(9, 95)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(95, 13)
        Me.Label2.TabIndex = 9
        Me.Label2.Text = "Grade/Section :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(241, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(202, 13)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "Malaking Pulo National High School"
        '
        'dg_generosity
        '
        Me.dg_generosity.AllowUserToAddRows = False
        Me.dg_generosity.BackgroundColor = System.Drawing.Color.White
        Me.dg_generosity.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer), CType(CType(195, Byte), Integer))
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dg_generosity.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle4
        Me.dg_generosity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dg_generosity.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.col_studid, Me.col_studname, Me.col_recitation1, Me.col_recitation2, Me.col_quiz1, Me.col_quiz2, Me.col_quiz3, Me.col_proj1, Me.col_qexam, Me.col_finalgrade, Me.col_gradeid})
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle6.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        DataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dg_generosity.DefaultCellStyle = DataGridViewCellStyle6
        Me.dg_generosity.Location = New System.Drawing.Point(3, 155)
        Me.dg_generosity.Name = "dg_generosity"
        Me.dg_generosity.ReadOnly = True
        Me.dg_generosity.RowHeadersVisible = False
        Me.dg_generosity.ScrollBars = System.Windows.Forms.ScrollBars.None
        Me.dg_generosity.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dg_generosity.Size = New System.Drawing.Size(695, 371)
        Me.dg_generosity.TabIndex = 7
        '
        'PrintDocument1
        '
        '
        'PrintDialog1
        '
        Me.PrintDialog1.UseEXDialog = True
        '
        'col_studid
        '
        Me.col_studid.DataPropertyName = "stud_id"
        Me.col_studid.HeaderText = "Student ID"
        Me.col_studid.Name = "col_studid"
        Me.col_studid.ReadOnly = True
        '
        'col_studname
        '
        Me.col_studname.DataPropertyName = "stud_name"
        Me.col_studname.HeaderText = "Name"
        Me.col_studname.Name = "col_studname"
        Me.col_studname.ReadOnly = True
        Me.col_studname.Width = 225
        '
        'col_recitation1
        '
        Me.col_recitation1.DataPropertyName = "grade_recitation1"
        Me.col_recitation1.HeaderText = "R1"
        Me.col_recitation1.Name = "col_recitation1"
        Me.col_recitation1.ReadOnly = True
        Me.col_recitation1.Width = 40
        '
        'col_recitation2
        '
        Me.col_recitation2.DataPropertyName = "grade_recitation2"
        Me.col_recitation2.HeaderText = "R2"
        Me.col_recitation2.Name = "col_recitation2"
        Me.col_recitation2.ReadOnly = True
        Me.col_recitation2.Width = 40
        '
        'col_quiz1
        '
        Me.col_quiz1.DataPropertyName = "grade_quiz1"
        Me.col_quiz1.HeaderText = "Q1"
        Me.col_quiz1.Name = "col_quiz1"
        Me.col_quiz1.ReadOnly = True
        Me.col_quiz1.Width = 40
        '
        'col_quiz2
        '
        Me.col_quiz2.DataPropertyName = "grade_quiz2"
        Me.col_quiz2.HeaderText = "Q2"
        Me.col_quiz2.Name = "col_quiz2"
        Me.col_quiz2.ReadOnly = True
        Me.col_quiz2.Width = 40
        '
        'col_quiz3
        '
        Me.col_quiz3.DataPropertyName = "grade_quiz3"
        Me.col_quiz3.HeaderText = "Q3"
        Me.col_quiz3.Name = "col_quiz3"
        Me.col_quiz3.ReadOnly = True
        Me.col_quiz3.Width = 40
        '
        'col_proj1
        '
        Me.col_proj1.DataPropertyName = "grade_project"
        Me.col_proj1.HeaderText = "P"
        Me.col_proj1.Name = "col_proj1"
        Me.col_proj1.ReadOnly = True
        Me.col_proj1.Width = 40
        '
        'col_qexam
        '
        Me.col_qexam.DataPropertyName = "grade_exam"
        Me.col_qexam.HeaderText = "QE"
        Me.col_qexam.Name = "col_qexam"
        Me.col_qexam.ReadOnly = True
        Me.col_qexam.Width = 40
        '
        'col_finalgrade
        '
        Me.col_finalgrade.DataPropertyName = "grade_final"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle5.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle5.NullValue = Nothing
        Me.col_finalgrade.DefaultCellStyle = DataGridViewCellStyle5
        Me.col_finalgrade.HeaderText = "Final Grade"
        Me.col_finalgrade.Name = "col_finalgrade"
        Me.col_finalgrade.ReadOnly = True
        Me.col_finalgrade.Width = 90
        '
        'col_gradeid
        '
        Me.col_gradeid.DataPropertyName = "grade_id"
        Me.col_gradeid.HeaderText = "Grade ID"
        Me.col_gradeid.Name = "col_gradeid"
        Me.col_gradeid.ReadOnly = True
        Me.col_gradeid.Visible = False
        '
        'frm_printgrades
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(700, 561)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "frm_printgrades"
        Me.Text = "frm_printgrades"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dg_generosity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents dg_generosity As System.Windows.Forms.DataGridView
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lbl_dateprinted As System.Windows.Forms.Label
    Friend WithEvents lbl_period As System.Windows.Forms.Label
    Friend WithEvents lbl_subject As System.Windows.Forms.Label
    Friend WithEvents lbl_gs As System.Windows.Forms.Label
    Friend WithEvents lbl_print As System.Windows.Forms.Label
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintDialog1 As System.Windows.Forms.PrintDialog
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents col_studid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_studname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_recitation1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_recitation2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_quiz3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_proj1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_qexam As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_finalgrade As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents col_gradeid As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
