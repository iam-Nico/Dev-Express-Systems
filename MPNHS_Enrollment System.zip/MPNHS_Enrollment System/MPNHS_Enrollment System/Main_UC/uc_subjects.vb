﻿Public Class uc_subjects

    Dim Vals(100), S_ids As String


    Private Sub uc_subjects_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        GridView1.BestFitColumns()

        dg_faculties.DataSource = GetSubjects()

    End Sub

    Private Sub SimpleButton1_Click(sender As Object, e As EventArgs) Handles SimpleButton1.Click
        Command = 1
        frm_addsubjects.ShowDialog()
    End Sub

    Private Sub SimpleButton5_Click(sender As Object, e As EventArgs) Handles SimpleButton5.Click
        dg_faculties.DataSource = GetSubjects()
    End Sub

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles SimpleButton2.Click
        Command = 2

        MessageBox.Show(Vals(4))


        frm_addsubjects.txt_subcode.Text = Vals(0)
        frm_addsubjects.txt_desc.Text = Vals(1)
        frm_addsubjects.cbo_from.Text = Vals(2)
        frm_addsubjects.cbo_to.Text = Vals(3)
        frm_addsubjects.cbo_teacher.Text = Vals(4)
        frm_addsubjects.cbo_gradelvl.Text = Vals(5)

        frm_addsubjects.ShowDialog()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "subject_id").ToString
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "subject_description").ToString
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "subject_starttime").ToString
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "subject_endtime").ToString
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "subject_teacher").ToString
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "subject_grade").ToString

        S_ids = Vals(0).ToString
      
    End Sub

    Private Sub SimpleButton3_Click(sender As Object, e As EventArgs) Handles SimpleButton3.Click

        DeleteSubjects(Vals(0))
        MessageBox.Show("Deleted")

    End Sub

    Private Sub SimpleButton6_Click(sender As Object, e As EventArgs) Handles SimpleButton6.Click
        frm_rptsubjects.ShowDialog()
    End Sub
End Class
