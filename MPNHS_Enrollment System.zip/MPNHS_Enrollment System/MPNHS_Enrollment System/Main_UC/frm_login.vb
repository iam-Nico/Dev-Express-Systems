﻿Public Class frm_login

    Public _User, _UserID As String

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles btn_login.Click

        Login(txt_username.Text, txt_password.Text)

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        End
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Me.txt_username.Text = ""
        Me.txt_password.Text = ""
    End Sub
End Class