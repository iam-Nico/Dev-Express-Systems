﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_finalgrade
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.ReportViewer1 = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.RibbonPage2 = New DevExpress.XtraBars.Ribbon.RibbonPage()
        Me.MPNHS_DBDataSet = New MPNHS_Enrollment_System.MPNHS_DBDataSet()
        Me.dg_gradesBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.MPNHS_DBDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dg_gradesBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'ReportViewer1
        '
        Me.ReportViewer1.Dock = System.Windows.Forms.DockStyle.Fill
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.dg_gradesBindingSource
        Me.ReportViewer1.LocalReport.DataSources.Add(ReportDataSource1)
        Me.ReportViewer1.LocalReport.ReportEmbeddedResource = "MPNHS_Enrollment_System.Report1.rdlc"
        Me.ReportViewer1.Location = New System.Drawing.Point(0, 0)
        Me.ReportViewer1.Name = "ReportViewer1"
        Me.ReportViewer1.Size = New System.Drawing.Size(682, 310)
        Me.ReportViewer1.TabIndex = 0
        '
        'RibbonPage2
        '
        Me.RibbonPage2.Name = "RibbonPage2"
        Me.RibbonPage2.Text = "RibbonPage2"
        '
        'MPNHS_DBDataSet
        '
        Me.MPNHS_DBDataSet.DataSetName = "MPNHS_DBDataSet"
        Me.MPNHS_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'dg_gradesBindingSource
        '
        Me.dg_gradesBindingSource.DataMember = "dg_grades"
        Me.dg_gradesBindingSource.DataSource = Me.MPNHS_DBDataSet
        '
        'frm_finalgrade
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(682, 310)
        Me.Controls.Add(Me.ReportViewer1)
        Me.Name = "frm_finalgrade"
        Me.Text = "frm_finalgrade"
        CType(Me.MPNHS_DBDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dg_gradesBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ReportViewer1 As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents RibbonPage2 As DevExpress.XtraBars.Ribbon.RibbonPage
    Friend WithEvents dg_gradesBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents MPNHS_DBDataSet As MPNHS_Enrollment_System.MPNHS_DBDataSet
End Class
