﻿Public Class frm_enrollment 

    Private Sub frm_enrollment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        GridView1.BestFitColumns()

    End Sub
End Class