﻿Partial Class POSDataSet1

End Class
