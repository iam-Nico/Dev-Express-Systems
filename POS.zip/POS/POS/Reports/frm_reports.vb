﻿Public Class frm_reports


    Dim dictio As New Dictionary(Of String, String)

    Private Sub DocumentViewer1_Load(sender As Object, e As EventArgs) Handles DocumentViewer1.Load


        Dim report As report = New report

        With report

            Dim obj As New SqlHelper
            Dim dt As DataTable

            dt = obj.GetData("Select * from tbl_products")
            .DataSource = dt
            DocumentViewer1.DocumentSource = report
            .CreateDocument()
        End With

    End Sub
End Class