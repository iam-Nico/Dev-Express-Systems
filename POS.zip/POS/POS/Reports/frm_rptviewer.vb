﻿Public Class frm_rptviewer 

    Private Sub frm_rptviewer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class