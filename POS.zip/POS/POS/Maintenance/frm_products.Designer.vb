﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_products
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_products))
        Dim GridLevelNode1 As DevExpress.XtraGrid.GridLevelNode = New DevExpress.XtraGrid.GridLevelNode()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.btn_uploadprods = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_newprod = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_updateprod = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_deleteprod = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl5 = New DevExpress.XtraEditors.PanelControl()
        Me.txt_searchprod = New DevExpress.XtraEditors.TextEdit()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.dgprods = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.col_product_id = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_code = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_type = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_description = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_weight_pac = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_uom_pac = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_weight_bx = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_uom_bx = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.col_product_list_price = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.ofd = New System.Windows.Forms.OpenFileDialog()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl5.SuspendLayout()
        CType(Me.txt_searchprod.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        Me.SuspendLayout()
        '
        'PanelControl1
        '
        Me.PanelControl1.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.PanelControl1.Appearance.Options.UseBackColor = True
        Me.PanelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl1.Controls.Add(Me.LabelControl1)
        Me.PanelControl1.Controls.Add(Me.btn_uploadprods)
        Me.PanelControl1.Controls.Add(Me.btn_newprod)
        Me.PanelControl1.Controls.Add(Me.btn_updateprod)
        Me.PanelControl1.Controls.Add(Me.btn_deleteprod)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl1.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(233, 472)
        Me.PanelControl1.TabIndex = 37
        '
        'LabelControl1
        '
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Segoe UI Semibold", 20.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelControl1.Appearance.ForeColor = System.Drawing.Color.White
        Me.LabelControl1.Appearance.Options.UseFont = True
        Me.LabelControl1.Appearance.Options.UseForeColor = True
        Me.LabelControl1.Location = New System.Drawing.Point(9, 12)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(51, 37)
        Me.LabelControl1.TabIndex = 46
        Me.LabelControl1.Text = "POS"
        '
        'btn_uploadprods
        '
        Me.btn_uploadprods.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_uploadprods.Appearance.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_uploadprods.Appearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_uploadprods.Appearance.Options.UseBackColor = True
        Me.btn_uploadprods.Appearance.Options.UseBorderColor = True
        Me.btn_uploadprods.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_uploadprods.ImageOptions.Image = CType(resources.GetObject("btn_uploadprods.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_uploadprods.Location = New System.Drawing.Point(9, 69)
        Me.btn_uploadprods.Name = "btn_uploadprods"
        Me.btn_uploadprods.Size = New System.Drawing.Size(218, 40)
        Me.btn_uploadprods.TabIndex = 45
        Me.btn_uploadprods.Text = "Upload Products"
        '
        'btn_newprod
        '
        Me.btn_newprod.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_newprod.Appearance.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_newprod.Appearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_newprod.Appearance.Options.UseBackColor = True
        Me.btn_newprod.Appearance.Options.UseBorderColor = True
        Me.btn_newprod.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_newprod.ImageOptions.Image = CType(resources.GetObject("btn_newprod.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_newprod.Location = New System.Drawing.Point(9, 115)
        Me.btn_newprod.Name = "btn_newprod"
        Me.btn_newprod.Size = New System.Drawing.Size(218, 40)
        Me.btn_newprod.TabIndex = 43
        Me.btn_newprod.Text = "New Product"
        '
        'btn_updateprod
        '
        Me.btn_updateprod.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_updateprod.Appearance.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_updateprod.Appearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_updateprod.Appearance.Options.UseBackColor = True
        Me.btn_updateprod.Appearance.Options.UseBorderColor = True
        Me.btn_updateprod.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_updateprod.ImageOptions.Image = CType(resources.GetObject("btn_updateprod.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_updateprod.Location = New System.Drawing.Point(9, 161)
        Me.btn_updateprod.Name = "btn_updateprod"
        Me.btn_updateprod.Size = New System.Drawing.Size(218, 40)
        Me.btn_updateprod.TabIndex = 44
        Me.btn_updateprod.Text = "Update"
        '
        'btn_deleteprod
        '
        Me.btn_deleteprod.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_deleteprod.Appearance.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_deleteprod.Appearance.BorderColor = System.Drawing.Color.FromArgb(CType(CType(246, Byte), Integer), CType(CType(250, Byte), Integer), CType(CType(251, Byte), Integer))
        Me.btn_deleteprod.Appearance.Options.UseBackColor = True
        Me.btn_deleteprod.Appearance.Options.UseBorderColor = True
        Me.btn_deleteprod.ButtonStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.btn_deleteprod.ImageOptions.Image = CType(resources.GetObject("btn_deleteprod.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_deleteprod.Location = New System.Drawing.Point(9, 207)
        Me.btn_deleteprod.Name = "btn_deleteprod"
        Me.btn_deleteprod.Size = New System.Drawing.Size(218, 40)
        Me.btn_deleteprod.TabIndex = 45
        Me.btn_deleteprod.Text = "Delete"
        '
        'PanelControl5
        '
        Me.PanelControl5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl5.Controls.Add(Me.txt_searchprod)
        Me.PanelControl5.Controls.Add(Me.Label5)
        Me.PanelControl5.Location = New System.Drawing.Point(6, 406)
        Me.PanelControl5.Name = "PanelControl5"
        Me.PanelControl5.Size = New System.Drawing.Size(80, 50)
        Me.PanelControl5.TabIndex = 1
        Me.PanelControl5.Visible = False
        '
        'txt_searchprod
        '
        Me.txt_searchprod.Location = New System.Drawing.Point(75, 14)
        Me.txt_searchprod.Name = "txt_searchprod"
        Me.txt_searchprod.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_searchprod.Properties.Appearance.Options.UseFont = True
        Me.txt_searchprod.Size = New System.Drawing.Size(272, 26)
        Me.txt_searchprod.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(13, 17)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 19)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Search"
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.DataGridView1)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelControl3.Location = New System.Drawing.Point(233, 409)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(727, 63)
        Me.PanelControl3.TabIndex = 39
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(74, 17)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(411, 10)
        Me.DataGridView1.TabIndex = 1
        Me.DataGridView1.Visible = False
        '
        'dgprods
        '
        Me.dgprods.Dock = System.Windows.Forms.DockStyle.Fill
        GridLevelNode1.RelationName = "Level1"
        Me.dgprods.LevelTree.Nodes.AddRange(New DevExpress.XtraGrid.GridLevelNode() {GridLevelNode1})
        Me.dgprods.Location = New System.Drawing.Point(2, 2)
        Me.dgprods.LookAndFeel.SkinName = "Office 2016 Colorful"
        Me.dgprods.MainView = Me.GridView1
        Me.dgprods.Name = "dgprods"
        Me.dgprods.Size = New System.Drawing.Size(723, 405)
        Me.dgprods.TabIndex = 0
        Me.dgprods.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.col_product_id, Me.col_product_code, Me.col_product_type, Me.col_product_description, Me.col_product_weight_pac, Me.col_product_uom_pac, Me.col_product_weight_bx, Me.col_product_uom_bx, Me.col_product_list_price})
        Me.GridView1.GridControl = Me.dgprods
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsFind.AlwaysVisible = True
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'col_product_id
        '
        Me.col_product_id.Caption = "Product ID"
        Me.col_product_id.FieldName = "product_id"
        Me.col_product_id.ImageOptions.Image = CType(resources.GetObject("col_product_id.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_id.Name = "col_product_id"
        Me.col_product_id.Visible = True
        Me.col_product_id.VisibleIndex = 0
        '
        'col_product_code
        '
        Me.col_product_code.Caption = "Product Code"
        Me.col_product_code.FieldName = "product_code"
        Me.col_product_code.ImageOptions.Image = CType(resources.GetObject("col_product_code.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_code.Name = "col_product_code"
        Me.col_product_code.Visible = True
        Me.col_product_code.VisibleIndex = 3
        '
        'col_product_type
        '
        Me.col_product_type.Caption = "Type"
        Me.col_product_type.FieldName = "product_type"
        Me.col_product_type.ImageOptions.Image = CType(resources.GetObject("col_product_type.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_type.Name = "col_product_type"
        Me.col_product_type.Visible = True
        Me.col_product_type.VisibleIndex = 1
        '
        'col_product_description
        '
        Me.col_product_description.Caption = "Description"
        Me.col_product_description.FieldName = "product_description"
        Me.col_product_description.ImageOptions.Image = CType(resources.GetObject("col_product_description.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_description.Name = "col_product_description"
        Me.col_product_description.Visible = True
        Me.col_product_description.VisibleIndex = 2
        '
        'col_product_weight_pac
        '
        Me.col_product_weight_pac.Caption = "Weight Pac"
        Me.col_product_weight_pac.FieldName = "product_weight_pac"
        Me.col_product_weight_pac.ImageOptions.Image = CType(resources.GetObject("col_product_weight_pac.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_weight_pac.Name = "col_product_weight_pac"
        Me.col_product_weight_pac.Visible = True
        Me.col_product_weight_pac.VisibleIndex = 4
        '
        'col_product_uom_pac
        '
        Me.col_product_uom_pac.Caption = "UOM (Pac)"
        Me.col_product_uom_pac.FieldName = "product_uom_pac"
        Me.col_product_uom_pac.Name = "col_product_uom_pac"
        Me.col_product_uom_pac.Visible = True
        Me.col_product_uom_pac.VisibleIndex = 5
        '
        'col_product_weight_bx
        '
        Me.col_product_weight_bx.Caption = "Weight Bx"
        Me.col_product_weight_bx.FieldName = "product_weight_bx"
        Me.col_product_weight_bx.ImageOptions.Image = CType(resources.GetObject("col_product_weight_bx.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_weight_bx.Name = "col_product_weight_bx"
        Me.col_product_weight_bx.Visible = True
        Me.col_product_weight_bx.VisibleIndex = 6
        '
        'col_product_uom_bx
        '
        Me.col_product_uom_bx.Caption = "UOM (Bx)"
        Me.col_product_uom_bx.FieldName = "product_uom_bx"
        Me.col_product_uom_bx.Name = "col_product_uom_bx"
        Me.col_product_uom_bx.Visible = True
        Me.col_product_uom_bx.VisibleIndex = 7
        '
        'col_product_list_price
        '
        Me.col_product_list_price.Caption = "List Price"
        Me.col_product_list_price.FieldName = "product_list_price"
        Me.col_product_list_price.ImageOptions.Image = CType(resources.GetObject("col_product_list_price.ImageOptions.Image"), System.Drawing.Image)
        Me.col_product_list_price.Name = "col_product_list_price"
        Me.col_product_list_price.Visible = True
        Me.col_product_list_price.VisibleIndex = 8
        '
        'ofd
        '
        Me.ofd.FileName = "OpenFileDialog1"
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.dgprods)
        Me.PanelControl2.Controls.Add(Me.PanelControl5)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl2.Location = New System.Drawing.Point(233, 0)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(727, 409)
        Me.PanelControl2.TabIndex = 40
        '
        'frm_products
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(960, 472)
        Me.Controls.Add(Me.PanelControl2)
        Me.Controls.Add(Me.PanelControl3)
        Me.Controls.Add(Me.PanelControl1)
        Me.Name = "frm_products"
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl5.ResumeLayout(False)
        Me.PanelControl5.PerformLayout()
        CType(Me.txt_searchprod.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents txt_searchprod As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_newprod As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents dgprods As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents btn_deleteprod As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_updateprod As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents PanelControl5 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents btn_uploadprods As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents ofd As System.Windows.Forms.OpenFileDialog
    Friend WithEvents col_product_id As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_code As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_type As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_description As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_weight_pac As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_uom_pac As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_weight_bx As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_uom_bx As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents col_product_list_price As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
End Class
