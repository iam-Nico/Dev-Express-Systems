﻿Public Class frm_modcashier 

    Private Sub frm_modcashier_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click
        If st = 1 Then
            Try

                AddCashier(txt_fname.Text, txt_mname.Text, txt_lname.Text, txt_cusername.Text, txt_cpassword.Text)
                MessageBox.Show("User has been successfully added!")
                Dim dt As DataTable = GetCashier()
                frm_cashier.dg_cashier.DataSource = dt
                st = 0
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try

        ElseIf st = 2 Then
            Try
                EditCashier(txt_fname.Text, txt_mname.Text, txt_lname.Text, txt_cusername.Text, txt_cpassword.Text)
                MessageBox.Show("Data has been successfully modified!")
                Dim dt As DataTable = GetCashier()
                frm_cashier.dg_cashier.DataSource = dt
                st = 0
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try


        End If
    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Me.Close()
    End Sub
End Class