﻿Public Class frm_modcustomers 

    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click

        If st = 1 Then
            Try

                AddUsers(txt_customname.Text, txt_deladdress.Text)
                MessageBox.Show("Customer has been successfully added!")
                Dim dt As DataTable = GetCustomers()
                frm_customers.dgcustomers.DataSource = dt
                st = 0
                GetCustIDAll()
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try

        ElseIf st = 2 Then
            Try
                EditUsers(txt_customname.Text, txt_deladdress.Text)
                MessageBox.Show("Data has been successfully modified!")
                Dim dt As DataTable = GetCustomers()
                frm_customers.dgcustomers.DataSource = dt
                st = 0
                GetCustIDAll()
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try


        End If


    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        UsersClear()
        st = 0
        Me.Close()
    End Sub

    Private Sub frm_modcustomers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class