﻿Public Class frm_modproducts


    Private Sub btn_save_Click(sender As Object, e As EventArgs) Handles btn_save.Click

        If st = 1 Then
            Try

                AddProducts(txt_prodtype.Text, txt_desc.Text, txt_product_code.Text, txt_wpac.Text, txt_pac.Text, txt_wbx.Text, txt_bx.Text, txt_price.Text)
                MessageBox.Show("Product has been successfully added!")
                Dim dt As DataTable = GetProducts()
                frm_products.dgprods.DataSource = dt
                st = 0
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try

        ElseIf st = 2 Then
            Try
                EditProducts(txt_prodtype.Text, txt_desc.Text, txt_product_code.Text, txt_wpac.Text, txt_pac.Text, txt_wbx.Text, txt_bx.Text, txt_price.Text)
                MessageBox.Show("Data has been successfully modified!")
                Dim dt As DataTable = GetProducts()
                frm_products.dgprods.DataSource = dt
                st = 0
                Me.Close()
            Catch ex As Exception
                MessageBox.Show("Error")
            End Try


        End If


    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        UsersClear()
        st = 0
        Me.Close()
    End Sub

    Private Sub frm_modproducts_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class