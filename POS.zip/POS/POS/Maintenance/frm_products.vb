﻿Public Class frm_products

    Public Vals(8) As Object
    Public P_ids As Integer
    Dim dt As DataTable

    Private Sub frm_products_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dgprods.DataSource = GetProducts()

        GridView1.BestFitColumns()


    End Sub

    Private Sub btn_newprod_Click(sender As Object, e As EventArgs) Handles btn_newprod.Click

        st = 1
        UsersClear()
        frm_modproducts.ShowDialog()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        'DevExpress.XtraGrid.Views.Base.ColumnViewOptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Default

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "product_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "product_type")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "product_description")
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "product_code")
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "product_weight_pac")
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "product_uom_pac")
        Vals(6) = view.GetRowCellValue(view.FocusedRowHandle, "product_weight_bx")
        Vals(7) = view.GetRowCellValue(view.FocusedRowHandle, "product_uom_bx")
        Vals(8) = view.GetRowCellValue(view.FocusedRowHandle, "product_list_price")

        P_ids = Vals(0).ToString

        'view.FocusedRowHandle
        ' view.FocusedColumn
        'MessageBox.Show(Vals(0).ToString)

        'place your code here
    End Sub


    Private Sub btn_updateprod_Click(sender As Object, e As EventArgs) Handles btn_updateprod.Click
        st = 2
        With frm_modproducts
            .txt_prodid.Text = Vals(0)
            .txt_prodtype.Text = Vals(1)
            .txt_desc.Text = Vals(2)
            .txt_product_code.Text = Vals(3)
            .txt_wpac.Text = Vals(4)
            .txt_pac.Text = Vals(5)
            .txt_wbx.Text = Vals(6)
            .txt_bx.Text = Vals(7)
            .txt_price.Text = Vals(8)

        End With
        frm_modproducts.ShowDialog()
    End Sub

    Private Sub btn_deleteprod_Click(sender As Object, e As EventArgs) Handles btn_deleteprod.Click
        Try
            DeleteProducts(P_ids)
            MessageBox.Show("Data has been successfully deleted!")
            Dim dt As DataTable = GetCustomers()
            Me.dgprods.DataSource = dt
            st = 0
            UsersClear()
        Catch ex As Exception
            MessageBox.Show("Error")
        End Try
    End Sub

    Private Sub txt_searchprod_TextChanged(sender As Object, e As EventArgs) Handles txt_searchprod.TextChanged
        searchproduct(txt_searchprod.Text)
    End Sub

    Private Sub btn_uploadprods_Click(sender As Object, e As EventArgs) Handles btn_uploadprods.Click
        With ofd
            .FileName = "*.xls"
            .Filter = "office files|*.xls"

            If .ShowDialog() = System.Windows.Forms.DialogResult.OK Then

                Dim file As String = Nothing
                For Each file In .FileNames
                    Dim x As String = file
                    dt = OpenFile(file)
                Next
                Me.DataGridView1.DataSource = dt


                With Me.DataGridView1
                    .Columns(0).HeaderCell.Value = "PRODUCT TYPE"
                    .Columns(1).HeaderCell.Value = "PRODUCT DESCRIPTION"
                    .Columns(2).HeaderCell.Value = "PRODUCT CODE"
                    .Columns(3).HeaderCell.Value = "PRODUCT WEIGHT PAC"
                    .Columns(4).HeaderCell.Value = "PRODUCT UOM PAC"
                    .Columns(5).HeaderCell.Value = "PRODUCT WEIGHT BX"
                    .Columns(6).HeaderCell.Value = "PRODUCT UOM BX"
                    .Columns(7).HeaderCell.Value = "PRODUCT LIST PRICE"

                    .Columns(0).Width = 190
                    .Columns(1).Width = 190
                    .Columns(2).Width = 190
                    .Columns(3).Width = 190
                    .Columns(4).Width = 190
                    .Columns(5).Width = 190
                    .Columns(6).Width = 190
                    .Columns(7).Width = 190

                End With

            Else
                Exit Sub

            End If
        End With

        Try
            Dim dt As DataTable = Me.DataGridView1.DataSource
            Dim counter As Integer = 0
            Dim total As Integer = dt.Rows.Count
            If dt.Rows.Count <> 0 Then

                For Each i As DataGridViewRow In Me.DataGridView1.Rows

                    If IsNumeric((i).Cells(3).Value.ToString()) = False Or IsNumeric((i).Cells(5).Value.ToString()) = False Or IsNumeric((i).Cells(7).Value.ToString()) = False Then
                        i.DefaultCellStyle.BackColor = Color.FromArgb(231, 76, 60)
                    ElseIf (i).Cells(0).Value.ToString() = "" Then
                        i.DefaultCellStyle.BackColor = Color.FromArgb(231, 76, 60)
                    ElseIf (i).Cells(1).Value.ToString() = "" Or (i).Cells(2).Value.ToString() = "" Or (i).Cells(4).Value.ToString() = "" Or (i).Cells(6).Value.ToString() = "" Then
                        i.DefaultCellStyle.BackColor = Color.FromArgb(231, 76, 60)
                    End If

                    counter = counter + 1
                    If total = counter Then
                        Exit For
                    End If
                Next
            End If

            UploadProds()
            dgprods.DataSource = GetProducts()
        Catch ex As Exception

        End Try
    End Sub
End Class