﻿Public Class frm_cashier

    Public Vals(5) As Object
    Public C_ids As Integer

    Private Sub frm_cashier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dg_cashier.DataSource = GetCashier()
    End Sub



    Private Sub btn_newcashier_Click(sender As Object, e As EventArgs) Handles btn_newcashier.Click
        st = 1
        UsersClear()
        frm_modcashier.ShowDialog()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        'DevExpress.XtraGrid.Views.Base.ColumnViewOptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Default

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_fname")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_mname")
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_lname")
        Vals(4) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_username")
        Vals(5) = view.GetRowCellValue(view.FocusedRowHandle, "cashier_password")

        C_ids = Vals(0).ToString

        txt_cashierid.Text = Vals(0)
        txt_fname.Text = Vals(1)
        txt_mname.Text = Vals(2)
        txt_lname.Text = Vals(3)
        'view.FocusedRowHandle
        ' view.FocusedColumn
        'MessageBox.Show(Vals(0).ToString)

        'place your code here
    End Sub


    Private Sub btn_updatecustom_Click(sender As Object, e As EventArgs) Handles btn_updatecustom.Click
        st = 2
        With frm_modcashier
            .txt_cashierid.Text = Vals(0)
            .txt_fname.Text = Vals(1)
            .txt_mname.Text = Vals(2)
            .txt_lname.Text = Vals(3)
            .txt_cusername.Text = Vals(4)
            .txt_cpassword.Text = Vals(5)
        End With
        frm_modcashier.ShowDialog()
    End Sub

    Private Sub btn_deletecustom_Click(sender As Object, e As EventArgs) Handles btn_deletecustom.Click
        Try
            DeleteCashier(C_ids)
            MessageBox.Show("Data has been successfully deleted!")
            Dim dt As DataTable = GetCashier()
            Me.dg_cashier.DataSource = dt
            st = 0
            UsersClear()
        Catch ex As Exception
            MessageBox.Show("Error")
        End Try
    End Sub
End Class