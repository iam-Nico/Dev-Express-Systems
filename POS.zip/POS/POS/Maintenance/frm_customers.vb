﻿Public Class frm_customers



    Public U_ids As Integer

    Public Vals(5) As Object

    Private Sub frm_customers_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dgcustomers.DataSource = GetCustomers()

    End Sub

    Private Sub btn_newcustom_Click(sender As Object, e As EventArgs) Handles btn_newcustom.Click

        'GetIDs()

        st = 1
        UsersClear()
        frm_modcustomers.ShowDialog()

    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        'DevExpress.XtraGrid.Views.Base.ColumnViewOptionsBehavior.EditorShowMode = DevExpress.Utils.EditorShowMode.Default

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "customer_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "customer_name")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "customer_del_address")
        U_ids = Vals(0).ToString

        txt_customid.Text = Vals(0)
        txt_customname.Text = Vals(1)
        txt_deladdress.Text = Vals(2)

        'view.FocusedRowHandle
        ' view.FocusedColumn
        'MessageBox.Show(Vals(0).ToString)

        'place your code here
    End Sub

    Private Sub btn_updatecustom_Click(sender As Object, e As EventArgs) Handles btn_updatecustom.Click
        st = 2
        With frm_modcustomers
            .txt_customid.Text = Vals(0)
            .txt_customname.Text = Vals(1)
            .txt_deladdress.Text = Vals(2)
        End With
        frm_modcustomers.ShowDialog()
    End Sub

    Private Sub btn_deletecustom_Click(sender As Object, e As EventArgs) Handles btn_deletecustom.Click
        Try
            DeleteUsers(U_ids)
            MessageBox.Show("Data has been successfully deleted!")
            Dim dt As DataTable = GetCustomers()
            Me.dgcustomers.DataSource = dt
            st = 0
            UsersClear()
        Catch ex As Exception
            MessageBox.Show("Error")
        End Try

    End Sub

    Private Sub txt_search_TextChanged(sender As Object, e As EventArgs) Handles txt_search.TextChanged
        search(txt_search.Text)
    End Sub
End Class