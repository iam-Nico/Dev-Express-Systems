﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_cashier
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_cashier))
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.txt_lname = New DevExpress.XtraEditors.TextEdit()
        Me.txt_cashierid = New DevExpress.XtraEditors.TextEdit()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_mname = New DevExpress.XtraEditors.TextEdit()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_fname = New DevExpress.XtraEditors.TextEdit()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.PanelControl5 = New DevExpress.XtraEditors.PanelControl()
        Me.txt_search = New DevExpress.XtraEditors.TextEdit()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_deletecustom = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_updatecustom = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_newcashier = New DevExpress.XtraEditors.SimpleButton()
        Me.dg_cashier = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        CType(Me.txt_lname.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_cashierid.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_mname.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_fname.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl5.SuspendLayout()
        CType(Me.txt_search.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        CType(Me.dg_cashier, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.txt_lname)
        Me.PanelControl2.Controls.Add(Me.txt_cashierid)
        Me.PanelControl2.Controls.Add(Me.Label4)
        Me.PanelControl2.Controls.Add(Me.Label1)
        Me.PanelControl2.Controls.Add(Me.txt_mname)
        Me.PanelControl2.Controls.Add(Me.Label3)
        Me.PanelControl2.Controls.Add(Me.txt_fname)
        Me.PanelControl2.Controls.Add(Me.Label2)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl2.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(1370, 126)
        Me.PanelControl2.TabIndex = 40
        '
        'txt_lname
        '
        Me.txt_lname.Enabled = False
        Me.txt_lname.Location = New System.Drawing.Point(593, 67)
        Me.txt_lname.Name = "txt_lname"
        Me.txt_lname.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_lname.Properties.Appearance.Options.UseFont = True
        Me.txt_lname.Size = New System.Drawing.Size(272, 26)
        Me.txt_lname.TabIndex = 42
        '
        'txt_cashierid
        '
        Me.txt_cashierid.Enabled = False
        Me.txt_cashierid.Location = New System.Drawing.Point(148, 30)
        Me.txt_cashierid.Name = "txt_cashierid"
        Me.txt_cashierid.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_cashierid.Properties.Appearance.ForeColor = System.Drawing.Color.Firebrick
        Me.txt_cashierid.Properties.Appearance.Options.UseFont = True
        Me.txt_cashierid.Properties.Appearance.Options.UseForeColor = True
        Me.txt_cashierid.Size = New System.Drawing.Size(272, 26)
        Me.txt_cashierid.TabIndex = 36
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(504, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 19)
        Me.Label4.TabIndex = 41
        Me.Label4.Text = "Last Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 31)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(83, 19)
        Me.Label1.TabIndex = 35
        Me.Label1.Text = "Cashier ID"
        '
        'txt_mname
        '
        Me.txt_mname.Enabled = False
        Me.txt_mname.Location = New System.Drawing.Point(593, 30)
        Me.txt_mname.Name = "txt_mname"
        Me.txt_mname.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_mname.Properties.Appearance.ForeColor = System.Drawing.Color.Black
        Me.txt_mname.Properties.Appearance.Options.UseFont = True
        Me.txt_mname.Properties.Appearance.Options.UseForeColor = True
        Me.txt_mname.Size = New System.Drawing.Size(272, 26)
        Me.txt_mname.TabIndex = 40
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(486, 33)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(101, 19)
        Me.Label3.TabIndex = 39
        Me.Label3.Text = "Middle Name"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'txt_fname
        '
        Me.txt_fname.Enabled = False
        Me.txt_fname.Location = New System.Drawing.Point(148, 71)
        Me.txt_fname.Name = "txt_fname"
        Me.txt_fname.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_fname.Properties.Appearance.ForeColor = System.Drawing.Color.Black
        Me.txt_fname.Properties.Appearance.Options.UseFont = True
        Me.txt_fname.Properties.Appearance.Options.UseForeColor = True
        Me.txt_fname.Size = New System.Drawing.Size(272, 26)
        Me.txt_fname.TabIndex = 38
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(19, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 19)
        Me.Label2.TabIndex = 37
        Me.Label2.Text = "First Name"
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.PanelControl5)
        Me.PanelControl3.Controls.Add(Me.PanelControl4)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl3.Location = New System.Drawing.Point(0, 126)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(1370, 54)
        Me.PanelControl3.TabIndex = 42
        '
        'PanelControl5
        '
        Me.PanelControl5.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl5.Controls.Add(Me.txt_search)
        Me.PanelControl5.Controls.Add(Me.Label5)
        Me.PanelControl5.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelControl5.Location = New System.Drawing.Point(945, 2)
        Me.PanelControl5.Name = "PanelControl5"
        Me.PanelControl5.Size = New System.Drawing.Size(423, 50)
        Me.PanelControl5.TabIndex = 1
        '
        'txt_search
        '
        Me.txt_search.Location = New System.Drawing.Point(130, 9)
        Me.txt_search.Name = "txt_search"
        Me.txt_search.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_search.Properties.Appearance.Options.UseFont = True
        Me.txt_search.Size = New System.Drawing.Size(272, 26)
        Me.txt_search.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(68, 12)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(56, 19)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Search"
        '
        'PanelControl4
        '
        Me.PanelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl4.Controls.Add(Me.btn_deletecustom)
        Me.PanelControl4.Controls.Add(Me.btn_updatecustom)
        Me.PanelControl4.Controls.Add(Me.btn_newcashier)
        Me.PanelControl4.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl4.Location = New System.Drawing.Point(2, 2)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(438, 50)
        Me.PanelControl4.TabIndex = 1
        '
        'btn_deletecustom
        '
        Me.btn_deletecustom.ImageOptions.Image = CType(resources.GetObject("btn_deletecustom.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_deletecustom.Location = New System.Drawing.Point(285, 8)
        Me.btn_deletecustom.Name = "btn_deletecustom"
        Me.btn_deletecustom.Size = New System.Drawing.Size(128, 31)
        Me.btn_deletecustom.TabIndex = 45
        Me.btn_deletecustom.Text = "Delete"
        '
        'btn_updatecustom
        '
        Me.btn_updatecustom.ImageOptions.Image = CType(resources.GetObject("btn_updatecustom.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_updatecustom.Location = New System.Drawing.Point(151, 8)
        Me.btn_updatecustom.Name = "btn_updatecustom"
        Me.btn_updatecustom.Size = New System.Drawing.Size(128, 31)
        Me.btn_updatecustom.TabIndex = 44
        Me.btn_updatecustom.Text = "Update"
        '
        'btn_newcashier
        '
        Me.btn_newcashier.ImageOptions.Image = CType(resources.GetObject("btn_newcashier.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_newcashier.Location = New System.Drawing.Point(17, 8)
        Me.btn_newcashier.Name = "btn_newcashier"
        Me.btn_newcashier.Size = New System.Drawing.Size(128, 31)
        Me.btn_newcashier.TabIndex = 43
        Me.btn_newcashier.Text = "New Cashier"
        '
        'dg_cashier
        '
        Me.dg_cashier.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dg_cashier.Location = New System.Drawing.Point(0, 180)
        Me.dg_cashier.MainView = Me.GridView1
        Me.dg_cashier.Name = "dg_cashier"
        Me.dg_cashier.Size = New System.Drawing.Size(1370, 281)
        Me.dg_cashier.TabIndex = 43
        Me.dg_cashier.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.GridControl = Me.dg_cashier
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        '
        'frm_cashier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 461)
        Me.Controls.Add(Me.dg_cashier)
        Me.Controls.Add(Me.PanelControl3)
        Me.Controls.Add(Me.PanelControl2)
        Me.Name = "frm_cashier"
        Me.Text = "frm_cashier"
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.PanelControl2.PerformLayout()
        CType(Me.txt_lname.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_cashierid.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_mname.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_fname.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl5.ResumeLayout(False)
        Me.PanelControl5.PerformLayout()
        CType(Me.txt_search.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        CType(Me.dg_cashier, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents txt_lname As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txt_cashierid As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_mname As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_fname As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl5 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents txt_search As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_deletecustom As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_updatecustom As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_newcashier As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents dg_cashier As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
End Class
