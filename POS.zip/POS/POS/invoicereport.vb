﻿
Imports DevExpress.XtraReports.UI

Public Class invoicereport

    Dim RowCount = 0

    Private Sub Detail1_BeforePrint(sender As Object, e As Printing.PrintEventArgs) Handles Detail1.BeforePrint
        RowCount += 1


        'MessageBox.Show(CStr(RowCount))
        If RowCount = 2 Then

            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 325

        ElseIf RowCount = 3 Then

            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 300


        ElseIf RowCount = 4 Then

            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 275


        ElseIf RowCount = 5 Then

            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 250


        ElseIf RowCount = 6 Then

            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 225


        ElseIf RowCount = 7 Then

            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 200


        ElseIf RowCount = 8 Then

            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 175


        ElseIf RowCount = 9 Then

            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 150


        ElseIf RowCount = 10 Then

            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 125


        ElseIf RowCount = 11 Then

            XrTable7.DeleteRow(XrTableRow7)
            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 100


        ElseIf RowCount = 12 Then

            XrTable6.DeleteRow(XrTableRow6)
            XrTable7.DeleteRow(XrTableRow7)
            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 75


        ElseIf RowCount = 13 Then

            XrTable5.DeleteRow(XrTableRow5)
            XrTable6.DeleteRow(XrTableRow6)
            XrTable7.DeleteRow(XrTableRow7)
            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 50


        ElseIf RowCount = 14 Then

            XrTable4.DeleteRow(XrTableRow4)
            XrTable5.DeleteRow(XrTableRow5)
            XrTable6.DeleteRow(XrTableRow6)
            XrTable7.DeleteRow(XrTableRow7)
            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 25


        ElseIf RowCount = 15 Then

            XrTable3.DeleteRow(XrTableRow3)
            XrTable4.DeleteRow(XrTableRow4)
            XrTable5.DeleteRow(XrTableRow5)
            XrTable6.DeleteRow(XrTableRow6)
            XrTable7.DeleteRow(XrTableRow7)
            XrTable8.DeleteRow(XrTableRow8)
            XrTable9.DeleteRow(XrTableRow9)
            XrTable10.DeleteRow(XrTableRow10)
            XrTable11.DeleteRow(XrTableRow11)
            XrTable12.DeleteRow(XrTableRow12)
            XrTable14.DeleteRow(XrTableRow14)
            XrTable15.DeleteRow(XrTableRow15)
            XrTable13.DeleteRow(XrTableRow13)
            XrTable16.DeleteRow(XrTableRow16)

            GroupFooter1.Height = 0

        End If

    End Sub

    Public Event ParametersRequestSubmit(sender As Object, e As DevExpress.XtraReports.Parameters.ParametersRequestEventArgs)


    Private Sub GroupFooter1_BeforePrint(sender As Object, e As Printing.PrintEventArgs) Handles GroupFooter1.BeforePrint

    End Sub

    Private Sub GroupFooter2_BeforePrint(sender As Object, e As Printing.PrintEventArgs) Handles GroupFooter2.BeforePrint



        GroupFooter2.HeightF = 1000




    End Sub

    Private Sub invoicereport_ParametersRequestValueChanged(sender As Object, e As DevExpress.XtraReports.Parameters.ParametersRequestValueChangedEventArgs) Handles MyBase.ParametersRequestValueChanged
        RowCount = 0
    End Sub
End Class