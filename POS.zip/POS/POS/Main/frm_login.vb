﻿Public Class frm_login 

    Dim X, Y As Integer
    Dim NewPoint As New System.Drawing.Point

    Public _Cashier, _Cashiername As String

    Private Sub frm_login_MouseDown(sender As Object, e As MouseEventArgs) Handles Me.MouseDown
        X = Control.MousePosition.X - Me.Location.X
        Y = Control.MousePosition.Y - Me.Location.Y
    End Sub

    Private Sub frm_login_MouseMove(sender As Object, e As MouseEventArgs) Handles Me.MouseMove
        If e.Button = System.Windows.Forms.MouseButtons.Left Then
            NewPoint = Control.MousePosition
            NewPoint.X -= (X)
            NewPoint.Y -= (Y)
            Me.Location = NewPoint

        End If
    End Sub

    Private Sub btn_close_Click(sender As Object, e As EventArgs) Handles btn_close.Click
        End
    End Sub

    Private Sub btn_login_Click(sender As Object, e As EventArgs) Handles btn_login.Click

        If txt_username.Text.Contains("'") Then
            MessageBox.Show("Invalid Input!")

        Else
            Try
                Login(txt_username.Text, txt_password.Text)
                ' MessageBox.Show(_Cashier)

            Catch ex As Exception
                Exit Sub
            End Try

        End If


    End Sub

    Private Sub btn_minimize_Click(sender As Object, e As EventArgs) Handles btn_minimize.Click
        Me.WindowState = FormWindowState.Minimized
    End Sub

    Private Sub frm_login_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class