﻿
Imports DevExpress.XtraSplashScreen

Public Class frm_main


    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click
        SplashScreenManager.ShowForm(GetType(WaitForm1))

        frm_transaction.MdiParent = Me
        frm_transaction.WindowState = FormWindowState.Maximized
        frm_transaction.Show()

        SplashScreenManager.CloseForm()
    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        SplashScreenManager.ShowForm(GetType(WaitForm1))
        frm_products.MdiParent = Me
        frm_products.WindowState = FormWindowState.Maximized
        frm_products.Show()
        SplashScreenManager.CloseForm()

    End Sub

    Private Sub ToolStripButton5_Click(sender As Object, e As EventArgs) Handles ToolStripButton5.Click
        SplashScreenManager.ShowForm(GetType(WaitForm1))
        frm_cashier.MdiParent = Me
        frm_cashier.WindowState = FormWindowState.Maximized
        frm_cashier.Show()
        SplashScreenManager.CloseForm()
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        SplashScreenManager.ShowForm(GetType(WaitForm1))
        frm_customers.MdiParent = Me
        frm_customers.WindowState = FormWindowState.Maximized
        frm_customers.Show()
        SplashScreenManager.CloseForm()
    End Sub

    Private Sub ToolStripButton6_Click(sender As Object, e As EventArgs) Handles ToolStripButton6.Click
        SplashScreenManager.ShowForm(GetType(WaitForm1))
        frm_rptviewer.MdiParent = Me
        frm_rptviewer.WindowState = FormWindowState.Maximized
        frm_rptviewer.Show()
        SplashScreenManager.CloseForm()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'While (PanelControl1.Height <> 0)
        '    PanelControl1.Height -= 1
        'End While
        PanelControl1.Hide()
        PanelControl2.Visible = True

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        PanelControl2.Visible = False
        PanelControl1.Show()
        'While (PanelControl1.Height <> 75)
        '    PanelControl1.Height += 1
        'End While
    End Sub

    Private Sub frm_main_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

        With frm_login
            .txt_username.Text = ""
            .txt_password.Text = ""

        End With

        frm_login.Show()

    End Sub

End Class