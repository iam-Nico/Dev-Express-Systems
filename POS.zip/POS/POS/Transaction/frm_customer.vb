﻿Public Class frm_customer

    Public Vals(5)

    Private Sub frm_customer_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dgprods.DataSource = GetCustomers()

    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "customer_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "customer_name")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "customer_del_address")

    End Sub

    Private Sub btn_select_Click(sender As Object, e As EventArgs) Handles btn_select.Click

        frm_transaction.txt_custid.Text = Vals(0).ToString
        frm_transaction.txt_deladdress.Text = Vals(2).ToString
        Me.Close()
    End Sub
End Class