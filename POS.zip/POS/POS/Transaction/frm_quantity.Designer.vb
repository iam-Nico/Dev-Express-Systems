﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_quantity
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_quantity))
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txt_quantity = New DevExpress.XtraEditors.TextEdit()
        Me.btn_ok = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_cancel = New DevExpress.XtraEditors.SimpleButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.cbo_uom = New DevExpress.XtraEditors.ComboBoxEdit()
        CType(Me.txt_quantity.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cbo_uom.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(27, 62)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(55, 16)
        Me.Label14.TabIndex = 44
        Me.Label14.Text = "Quantity"
        '
        'txt_quantity
        '
        Me.txt_quantity.Location = New System.Drawing.Point(31, 84)
        Me.txt_quantity.Name = "txt_quantity"
        Me.txt_quantity.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_quantity.Properties.Appearance.Options.UseFont = True
        Me.txt_quantity.Size = New System.Drawing.Size(198, 22)
        Me.txt_quantity.TabIndex = 43
        '
        'btn_ok
        '
        Me.btn_ok.ImageOptions.Image = CType(resources.GetObject("btn_ok.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_ok.Location = New System.Drawing.Point(34, 126)
        Me.btn_ok.Name = "btn_ok"
        Me.btn_ok.Size = New System.Drawing.Size(93, 28)
        Me.btn_ok.TabIndex = 53
        Me.btn_ok.Text = "Ok"
        '
        'btn_cancel
        '
        Me.btn_cancel.ImageOptions.Image = CType(resources.GetObject("btn_cancel.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_cancel.Location = New System.Drawing.Point(133, 126)
        Me.btn_cancel.Name = "btn_cancel"
        Me.btn_cancel.Size = New System.Drawing.Size(96, 28)
        Me.btn_cancel.TabIndex = 54
        Me.btn_cancel.Text = "Cancel"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(27, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 16)
        Me.Label1.TabIndex = 56
        Me.Label1.Text = "UOM"
        '
        'cbo_uom
        '
        Me.cbo_uom.Location = New System.Drawing.Point(30, 37)
        Me.cbo_uom.Name = "cbo_uom"
        Me.cbo_uom.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_uom.Properties.Appearance.Options.UseFont = True
        Me.cbo_uom.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cbo_uom.Properties.DropDownRows = 3
        Me.cbo_uom.Properties.Items.AddRange(New Object() {"BX", "PAC"})
        Me.cbo_uom.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor
        Me.cbo_uom.Size = New System.Drawing.Size(199, 22)
        Me.cbo_uom.TabIndex = 61
        '
        'frm_quantity
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(251, 168)
        Me.Controls.Add(Me.cbo_uom)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btn_cancel)
        Me.Controls.Add(Me.btn_ok)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.txt_quantity)
        Me.Name = "frm_quantity"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frm_quantity"
        CType(Me.txt_quantity.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cbo_uom.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txt_quantity As DevExpress.XtraEditors.TextEdit
    Friend WithEvents btn_ok As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_cancel As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbo_uom As DevExpress.XtraEditors.ComboBoxEdit
End Class
