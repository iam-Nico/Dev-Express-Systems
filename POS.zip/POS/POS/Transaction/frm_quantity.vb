﻿Imports POS.frm_transaction
Public Class frm_quantity

    Public comm As Integer

    Public quantity, twpac, listprice, discount, netprice, netamount As Decimal
    Dim uom As String


    Private Sub frm_quantity_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        frm_transaction.dgpos.Columns(4).DefaultCellStyle.Format = "N2"
        frm_transaction.dgpos.Columns(5).DefaultCellStyle.Format = "N2"
        frm_transaction.dgpos.Columns(6).DefaultCellStyle.Format = "N2"
        frm_transaction.dgpos.Columns(7).DefaultCellStyle.Format = "N2"

    End Sub

    Private Sub btn_ok_Click(sender As Object, e As EventArgs) Handles btn_ok.Click

        If frm_transaction.txt_custid.Text = "" Or frm_transaction.txt_deladdress.Text = "" Or frm_transaction.cbo_discount.Text = "" Or txt_quantity.Text = "" Or cbo_uom.Text = "" Then
            MessageBox.Show("Please complete customer's information")
            Exit Sub

        ElseIf IsNumeric(txt_quantity.Text) = False Then

            MessageBox.Show("Invaild Input")

        Else
            If comm = 1 Then

                quantity = CDec(txt_quantity.Text)
                twpac = (CDec(frm_transaction.Vals(3)) * CDec(txt_quantity.Text))
                uom = cbo_uom.Text
                listprice = CDec(frm_transaction.Vals(2))
                'discount = ((CDec(frm_transaction.cbo_discount.Text) / 100) * CDec(listprice))
                discount = (CDec(frm_transaction.cbo_discount.Text) * CDec(listprice))
                netprice = listprice - discount
                netamount = netprice * CDec(quantity)

                Try
                    frm_transaction.dgpos.AllowUserToAddRows = False
                    frm_transaction.dgpos.Rows.Add(frm_transaction.Vals(0), frm_transaction.Vals(1), quantity, twpac, uom, listprice, discount, netprice, netamount)
                Catch ex As Exception

                End Try

            Else

                Dim edquantity As String = txt_quantity.Text
                Dim dgrow As New DataGridViewRow


                discount = ((CDec(frm_transaction.cbo_discount.Text) / 100) * CDec(listprice))
                netamount = netprice * CDec(edquantity)

                For Each dgrow In frm_transaction.dgpos.SelectedRows
                    dgrow.Cells(2).Value = CDec(edquantity)
                    dgrow.Cells(8).Value = CDec(netamount)
                Next
            End If

            Gettotalap()
            txt_quantity.Text = ""

            Me.Close()
        End If

        DgposDesign()


    End Sub

    Private Sub btn_cancel_Click(sender As Object, e As EventArgs) Handles btn_cancel.Click
        Me.Close()
    End Sub


End Class