﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_customer
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_select = New DevExpress.XtraEditors.SimpleButton()
        Me.dgprods = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Col_customerid = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_custname = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_custdeladd = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.btn_select)
        Me.PanelControl1.Controls.Add(Me.dgprods)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl1.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(602, 275)
        Me.PanelControl1.TabIndex = 1
        '
        'btn_select
        '
        Me.btn_select.Location = New System.Drawing.Point(507, 15)
        Me.btn_select.Name = "btn_select"
        Me.btn_select.Size = New System.Drawing.Size(75, 23)
        Me.btn_select.TabIndex = 1
        Me.btn_select.Text = "Select"
        '
        'dgprods
        '
        Me.dgprods.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgprods.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgprods.Location = New System.Drawing.Point(2, 2)
        Me.dgprods.MainView = Me.GridView1
        Me.dgprods.Name = "dgprods"
        Me.dgprods.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemButtonEdit1})
        Me.dgprods.Size = New System.Drawing.Size(598, 271)
        Me.dgprods.TabIndex = 45
        Me.dgprods.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.Col_customerid, Me.Col_custname, Me.Col_custdeladd})
        Me.GridView1.GridControl = Me.dgprods
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsFind.AlwaysVisible = True
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'Col_customerid
        '
        Me.Col_customerid.Caption = "Customer ID"
        Me.Col_customerid.FieldName = "customer_id"
        Me.Col_customerid.Name = "Col_customerid"
        Me.Col_customerid.Visible = True
        Me.Col_customerid.VisibleIndex = 0
        '
        'Col_custname
        '
        Me.Col_custname.Caption = "Name"
        Me.Col_custname.FieldName = "customer_name"
        Me.Col_custname.Name = "Col_custname"
        Me.Col_custname.Visible = True
        Me.Col_custname.VisibleIndex = 1
        '
        'Col_custdeladd
        '
        Me.Col_custdeladd.Caption = "Delivery Address"
        Me.Col_custdeladd.FieldName = "customer_del_address"
        Me.Col_custdeladd.Name = "Col_custdeladd"
        Me.Col_custdeladd.Visible = True
        Me.Col_custdeladd.VisibleIndex = 2
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph)})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        Me.RepositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor
        '
        'frm_customer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(602, 275)
        Me.Controls.Add(Me.PanelControl1)
        Me.MaximizeBox = False
        Me.Name = "frm_customer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "frm_customer"
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_select As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents dgprods As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Col_customerid As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_custname As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_custdeladd As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
End Class
