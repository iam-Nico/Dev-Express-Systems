﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_popup
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim EditorButtonImageOptions1 As DevExpress.XtraEditors.Controls.EditorButtonImageOptions = New DevExpress.XtraEditors.Controls.EditorButtonImageOptions()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_popup))
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject2 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject3 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject4 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Me.lbl_datetime = New System.Windows.Forms.Timer(Me.components)
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.dgprods = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Col_prodid = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_uom = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_price = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_desc = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.btn_addtocart = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.btn_select = New DevExpress.XtraEditors.SimpleButton()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_datetime
        '
        Me.lbl_datetime.Enabled = True
        Me.lbl_datetime.Interval = 1000
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.dgprods)
        Me.PanelControl1.Controls.Add(Me.btn_select)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl1.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(610, 310)
        Me.PanelControl1.TabIndex = 0
        '
        'dgprods
        '
        Me.dgprods.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgprods.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgprods.Location = New System.Drawing.Point(2, 2)
        Me.dgprods.MainView = Me.GridView1
        Me.dgprods.Name = "dgprods"
        Me.dgprods.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemButtonEdit1})
        Me.dgprods.Size = New System.Drawing.Size(606, 306)
        Me.dgprods.TabIndex = 43
        Me.dgprods.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.Col_prodid, Me.Col_uom, Me.Col_price, Me.Col_desc, Me.btn_addtocart})
        Me.GridView1.GridControl = Me.dgprods
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsFind.AlwaysVisible = True
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'Col_prodid
        '
        Me.Col_prodid.Caption = "Product ID"
        Me.Col_prodid.FieldName = "prod_id"
        Me.Col_prodid.Name = "Col_prodid"
        Me.Col_prodid.Visible = True
        Me.Col_prodid.VisibleIndex = 0
        '
        'Col_uom
        '
        Me.Col_uom.Caption = "UOM"
        Me.Col_uom.FieldName = "uom"
        Me.Col_uom.Name = "Col_uom"
        Me.Col_uom.Visible = True
        Me.Col_uom.VisibleIndex = 1
        '
        'Col_price
        '
        Me.Col_price.Caption = "List Price"
        Me.Col_price.FieldName = "list_price"
        Me.Col_price.Name = "Col_price"
        Me.Col_price.Visible = True
        Me.Col_price.VisibleIndex = 2
        '
        'Col_desc
        '
        Me.Col_desc.Caption = "Description"
        Me.Col_desc.FieldName = "prod_desc"
        Me.Col_desc.Name = "Col_desc"
        Me.Col_desc.Visible = True
        Me.Col_desc.VisibleIndex = 3
        '
        'btn_addtocart
        '
        Me.btn_addtocart.Caption = "Add to Cart"
        Me.btn_addtocart.ColumnEdit = Me.RepositoryItemButtonEdit1
        Me.btn_addtocart.ImageOptions.Image = CType(resources.GetObject("btn_addtocart.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_addtocart.Name = "btn_addtocart"
        Me.btn_addtocart.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow
        Me.btn_addtocart.Visible = True
        Me.btn_addtocart.VisibleIndex = 4
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        EditorButtonImageOptions1.Image = CType(resources.GetObject("EditorButtonImageOptions1.Image"), System.Drawing.Image)
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, True, True, False, EditorButtonImageOptions1, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, SerializableAppearanceObject2, SerializableAppearanceObject3, SerializableAppearanceObject4, "", Nothing, Nothing, DevExpress.Utils.ToolTipAnchor.[Default])})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        Me.RepositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor
        '
        'btn_select
        '
        Me.btn_select.Location = New System.Drawing.Point(507, 15)
        Me.btn_select.Name = "btn_select"
        Me.btn_select.Size = New System.Drawing.Size(75, 23)
        Me.btn_select.TabIndex = 1
        Me.btn_select.Text = "Select"
        '
        'frm_popup
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(610, 310)
        Me.Controls.Add(Me.PanelControl1)
        Me.Name = "frm_popup"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Product Lookup"
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbl_datetime As System.Windows.Forms.Timer
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_select As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents dgprods As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Col_prodid As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_uom As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_price As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_desc As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents btn_addtocart As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
End Class
