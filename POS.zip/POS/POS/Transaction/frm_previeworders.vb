﻿Public Class frm_previeworders

    Dim vatsales As Decimal = 0


    Private Sub btn_createinvoice_Click(sender As Object, e As EventArgs) Handles btn_createinvoice.Click

        'Dim counter As Integer = 0
        'Dim total As Integer = dgpos.Rows.Count - 1

        'Try
        '    If dgpos.Rows.Count <> 0 Then

        '        Me.Cursor = Cursors.WaitCursor
        '        For i As Integer = 0 To dgpos.Rows.Count - 1

        '            'Decimal.TryParse(dgpos.Rows(i).Cells(2).Value.ToString(), prodcode)

        '            transaction(frm_pos.cbo_customer.Text, dgpos.Rows(i).Cells(0).Value.ToString, dgpos.Rows(i).Cells(2).Value.ToString(), dgpos.Rows(i).Cells(3).Value.ToString, dgpos.Rows(i).Cells(4).Value.ToString(), dgpos.Rows(i).Cells(5).Value.ToString(), dgpos.Rows(i).Cells(6).Value.ToString(), dgpos.Rows(i).Cells(7).Value.ToString(), Date.Now.ToString("yyyy-MM-dd hh:mm:ss"))

        '            'MessageBox.Show("Data Error")
        '            Me.Cursor = Cursors.Default
        '            counter = counter + 1
        '            If total = counter Then
        '                Exit For
        '            End If
        '        Next
        '        Me.Cursor = Cursors.Default
        '        MessageBox.Show("Order Successful!")
        '    End If
        'Catch ex As Exception
        '    MessageBox.Show("Data Error")
        '    Exit Sub
        'End Try


        
    End Sub

    Private Sub SimpleButton1_Click(sender As Object, e As EventArgs) Handles SimpleButton1.Click
        GetVats()
    End Sub

    Private Sub frm_previeworders_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class