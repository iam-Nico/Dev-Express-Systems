﻿Public Class frm_popup 

    Public Vals(5) As Object
    Dim P_ids As String

    Private Sub frm_popup_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        dgprods.DataSource = GetProducts()

        GetCustIDAll()
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "prod_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "prod_desc")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "list_price")
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "uom")

        P_ids = Vals(0).ToString

        'txt_customid.Text = Vals(0)
        'txt_customname.Text = Vals(1)

        frm_quantity.ShowDialog()
    End Sub



    Private Sub gridView1_Click(sender As Object, e As DevExpress.XtraGrid.Views.Grid.RowCellClickEventArgs) Handles GridView1.RowCellClick

    End Sub
End Class