﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_transaction
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_transaction))
        Me.tmr_datetime = New System.Windows.Forms.Timer(Me.components)
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.lbl_itemnum = New DevExpress.XtraEditors.LabelControl()
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl()
        Me.dgpos = New System.Windows.Forms.DataGridView()
        Me.prodcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.pwpac = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.uom = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.unitprice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.discount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.netprice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.netamount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.lbl_ototal = New System.Windows.Forms.Label()
        Me.btn_rmvitem = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_edtquantity = New DevExpress.XtraEditors.SimpleButton()
        Me.PanelControl5 = New DevExpress.XtraEditors.PanelControl()
        Me.PanelControl7 = New DevExpress.XtraEditors.PanelControl()
        Me.dgprods = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Col_prodcode = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_description = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_price = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_Wpac = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.cbo_discount = New System.Windows.Forms.ComboBox()
        Me.txt_custid = New DevExpress.XtraEditors.TextEdit()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt_deladdress = New DevExpress.XtraEditors.TextEdit()
        Me.txt_trnoid = New DevExpress.XtraEditors.TextEdit()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.PanelControl6 = New DevExpress.XtraEditors.PanelControl()
        Me.lbl_cahiername = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lbl_date = New System.Windows.Forms.Label()
        Me.lbl_datetime = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.ToolTipController1 = New DevExpress.Utils.ToolTipController(Me.components)
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.dgpos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl5.SuspendLayout()
        CType(Me.PanelControl7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl7.SuspendLayout()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_custid.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_deladdress.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_trnoid.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl6.SuspendLayout()
        Me.SuspendLayout()
        '
        'tmr_datetime
        '
        Me.tmr_datetime.Enabled = True
        Me.tmr_datetime.Interval = 1000
        '
        'PanelControl1
        '
        Me.PanelControl1.Controls.Add(Me.lbl_itemnum)
        Me.PanelControl1.Controls.Add(Me.LabelControl1)
        Me.PanelControl1.Controls.Add(Me.dgpos)
        Me.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl1.Location = New System.Drawing.Point(2, 105)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(817, 642)
        Me.PanelControl1.TabIndex = 70
        '
        'lbl_itemnum
        '
        Me.lbl_itemnum.Appearance.BackColor = System.Drawing.Color.Gainsboro
        Me.lbl_itemnum.Appearance.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.lbl_itemnum.Appearance.Options.UseBackColor = True
        Me.lbl_itemnum.Appearance.Options.UseFont = True
        Me.lbl_itemnum.Location = New System.Drawing.Point(121, 538)
        Me.lbl_itemnum.Name = "lbl_itemnum"
        Me.lbl_itemnum.Size = New System.Drawing.Size(7, 16)
        Me.lbl_itemnum.TabIndex = 64
        Me.lbl_itemnum.Text = "0"
        '
        'LabelControl1
        '
        Me.LabelControl1.Appearance.BackColor = System.Drawing.Color.Gainsboro
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Tahoma", 10.0!)
        Me.LabelControl1.Appearance.Options.UseBackColor = True
        Me.LabelControl1.Appearance.Options.UseFont = True
        Me.LabelControl1.Location = New System.Drawing.Point(10, 538)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(105, 16)
        Me.LabelControl1.TabIndex = 63
        Me.LabelControl1.Text = "Number of Items :"
        '
        'dgpos
        '
        Me.dgpos.BackgroundColor = System.Drawing.Color.Gainsboro
        Me.dgpos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.dgpos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Menu
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgpos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgpos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.prodcode, Me.description, Me.quantity, Me.pwpac, Me.uom, Me.unitprice, Me.discount, Me.netprice, Me.netamount})
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(32, Byte), Integer), CType(CType(31, Byte), Integer), CType(CType(53, Byte), Integer))
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Menu
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgpos.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgpos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgpos.Location = New System.Drawing.Point(2, 2)
        Me.dgpos.MultiSelect = False
        Me.dgpos.Name = "dgpos"
        Me.dgpos.ReadOnly = True
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Menu
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgpos.RowHeadersDefaultCellStyle = DataGridViewCellStyle3
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Menu
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.Black
        Me.dgpos.RowsDefaultCellStyle = DataGridViewCellStyle4
        Me.dgpos.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.SystemColors.Menu
        Me.dgpos.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black
        Me.dgpos.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgpos.Size = New System.Drawing.Size(813, 638)
        Me.dgpos.TabIndex = 62
        '
        'prodcode
        '
        Me.prodcode.HeaderText = "Product Code"
        Me.prodcode.Name = "prodcode"
        Me.prodcode.ReadOnly = True
        '
        'description
        '
        Me.description.HeaderText = "Description"
        Me.description.Name = "description"
        Me.description.ReadOnly = True
        Me.description.Width = 300
        '
        'quantity
        '
        Me.quantity.HeaderText = "Quantity"
        Me.quantity.Name = "quantity"
        Me.quantity.ReadOnly = True
        Me.quantity.Width = 50
        '
        'pwpac
        '
        Me.pwpac.HeaderText = "PWP"
        Me.pwpac.Name = "pwpac"
        Me.pwpac.ReadOnly = True
        Me.pwpac.Visible = False
        '
        'uom
        '
        Me.uom.HeaderText = "UOM"
        Me.uom.Name = "uom"
        Me.uom.ReadOnly = True
        Me.uom.Width = 50
        '
        'unitprice
        '
        Me.unitprice.HeaderText = "Unit Price"
        Me.unitprice.Name = "unitprice"
        Me.unitprice.ReadOnly = True
        Me.unitprice.Width = 75
        '
        'discount
        '
        Me.discount.HeaderText = "Discount"
        Me.discount.Name = "discount"
        Me.discount.ReadOnly = True
        Me.discount.Width = 50
        '
        'netprice
        '
        Me.netprice.HeaderText = "Net Price"
        Me.netprice.Name = "netprice"
        Me.netprice.ReadOnly = True
        Me.netprice.Width = 75
        '
        'netamount
        '
        Me.netamount.HeaderText = "Net Amount"
        Me.netamount.Name = "netamount"
        Me.netamount.ReadOnly = True
        Me.netamount.Width = 75
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.PanelControl1)
        Me.PanelControl2.Controls.Add(Me.Panel1)
        Me.PanelControl2.Controls.Add(Me.PanelControl3)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelControl2.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(821, 749)
        Me.PanelControl2.TabIndex = 71
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Panel1.Controls.Add(Me.LabelControl2)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(2, 76)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(817, 29)
        Me.Panel1.TabIndex = 71
        '
        'LabelControl2
        '
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelControl2.Appearance.ForeColor = System.Drawing.Color.White
        Me.LabelControl2.Appearance.Options.UseFont = True
        Me.LabelControl2.Appearance.Options.UseForeColor = True
        Me.LabelControl2.Location = New System.Drawing.Point(357, 6)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(93, 19)
        Me.LabelControl2.TabIndex = 0
        Me.LabelControl2.Text = "Order Details"
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.SimpleButton2)
        Me.PanelControl3.Controls.Add(Me.PanelControl4)
        Me.PanelControl3.Controls.Add(Me.btn_rmvitem)
        Me.PanelControl3.Controls.Add(Me.btn_edtquantity)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl3.Location = New System.Drawing.Point(2, 2)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(817, 74)
        Me.PanelControl3.TabIndex = 72
        '
        'SimpleButton2
        '
        Me.SimpleButton2.ImageOptions.Image = CType(resources.GetObject("SimpleButton2.ImageOptions.Image"), System.Drawing.Image)
        Me.SimpleButton2.Location = New System.Drawing.Point(644, 15)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(168, 50)
        Me.SimpleButton2.TabIndex = 37
        Me.SimpleButton2.Text = "Create invoice"
        '
        'PanelControl4
        '
        Me.PanelControl4.Controls.Add(Me.lbl_ototal)
        Me.PanelControl4.Location = New System.Drawing.Point(405, 15)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(233, 50)
        Me.PanelControl4.TabIndex = 40
        '
        'lbl_ototal
        '
        Me.lbl_ototal.Dock = System.Windows.Forms.DockStyle.Fill
        Me.lbl_ototal.Font = New System.Drawing.Font("Tahoma", 24.0!, System.Drawing.FontStyle.Bold)
        Me.lbl_ototal.ForeColor = System.Drawing.Color.Firebrick
        Me.lbl_ototal.Location = New System.Drawing.Point(2, 2)
        Me.lbl_ototal.Name = "lbl_ototal"
        Me.lbl_ototal.Size = New System.Drawing.Size(229, 46)
        Me.lbl_ototal.TabIndex = 64
        Me.lbl_ototal.Text = "0.00"
        Me.lbl_ototal.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.ToolTipController1.SetTitle(Me.lbl_ototal, "This:")
        Me.ToolTipController1.SetToolTip(Me.lbl_ototal, "Total amount to pay with VAT")
        '
        'btn_rmvitem
        '
        Me.btn_rmvitem.ImageOptions.Image = CType(resources.GetObject("btn_rmvitem.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_rmvitem.Location = New System.Drawing.Point(280, 16)
        Me.btn_rmvitem.Name = "btn_rmvitem"
        Me.btn_rmvitem.Size = New System.Drawing.Size(119, 50)
        Me.btn_rmvitem.TabIndex = 39
        Me.btn_rmvitem.Text = "Remove"
        '
        'btn_edtquantity
        '
        Me.btn_edtquantity.ImageOptions.Image = CType(resources.GetObject("btn_edtquantity.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_edtquantity.Location = New System.Drawing.Point(10, 15)
        Me.btn_edtquantity.Name = "btn_edtquantity"
        Me.btn_edtquantity.Size = New System.Drawing.Size(264, 50)
        Me.btn_edtquantity.TabIndex = 37
        Me.btn_edtquantity.Text = "Edit Quantity"
        '
        'PanelControl5
        '
        Me.PanelControl5.Controls.Add(Me.PanelControl7)
        Me.PanelControl5.Controls.Add(Me.PanelControl6)
        Me.PanelControl5.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl5.Location = New System.Drawing.Point(821, 0)
        Me.PanelControl5.Name = "PanelControl5"
        Me.PanelControl5.Size = New System.Drawing.Size(549, 749)
        Me.PanelControl5.TabIndex = 72
        '
        'PanelControl7
        '
        Me.PanelControl7.Appearance.BackColor = System.Drawing.Color.White
        Me.PanelControl7.Appearance.Options.UseBackColor = True
        Me.PanelControl7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl7.Controls.Add(Me.dgprods)
        Me.PanelControl7.Controls.Add(Me.cbo_discount)
        Me.PanelControl7.Controls.Add(Me.txt_custid)
        Me.PanelControl7.Controls.Add(Me.Label1)
        Me.PanelControl7.Controls.Add(Me.Label4)
        Me.PanelControl7.Controls.Add(Me.Label6)
        Me.PanelControl7.Controls.Add(Me.txt_deladdress)
        Me.PanelControl7.Controls.Add(Me.txt_trnoid)
        Me.PanelControl7.Controls.Add(Me.Label3)
        Me.PanelControl7.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelControl7.Location = New System.Drawing.Point(2, 183)
        Me.PanelControl7.Name = "PanelControl7"
        Me.PanelControl7.Size = New System.Drawing.Size(545, 564)
        Me.PanelControl7.TabIndex = 1
        '
        'dgprods
        '
        Me.dgprods.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.dgprods.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgprods.Location = New System.Drawing.Point(0, 219)
        Me.dgprods.MainView = Me.GridView1
        Me.dgprods.Name = "dgprods"
        Me.dgprods.Size = New System.Drawing.Size(545, 345)
        Me.dgprods.TabIndex = 62
        Me.dgprods.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.Col_prodcode, Me.Col_description, Me.Col_price, Me.Col_Wpac})
        Me.GridView1.GridControl = Me.dgprods
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsFind.AlwaysVisible = True
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'Col_prodcode
        '
        Me.Col_prodcode.Caption = "Product Code"
        Me.Col_prodcode.FieldName = "product_code"
        Me.Col_prodcode.ImageOptions.Image = CType(resources.GetObject("Col_prodcode.ImageOptions.Image"), System.Drawing.Image)
        Me.Col_prodcode.Name = "Col_prodcode"
        Me.Col_prodcode.Visible = True
        Me.Col_prodcode.VisibleIndex = 0
        '
        'Col_description
        '
        Me.Col_description.Caption = "Description"
        Me.Col_description.FieldName = "product_description"
        Me.Col_description.ImageOptions.Image = CType(resources.GetObject("Col_description.ImageOptions.Image"), System.Drawing.Image)
        Me.Col_description.Name = "Col_description"
        Me.Col_description.Visible = True
        Me.Col_description.VisibleIndex = 1
        '
        'Col_price
        '
        Me.Col_price.Caption = "List Price"
        Me.Col_price.FieldName = "product_list_price"
        Me.Col_price.ImageOptions.Image = CType(resources.GetObject("Col_price.ImageOptions.Image"), System.Drawing.Image)
        Me.Col_price.Name = "Col_price"
        Me.Col_price.Visible = True
        Me.Col_price.VisibleIndex = 3
        '
        'Col_Wpac
        '
        Me.Col_Wpac.Caption = "Product Weight Pac"
        Me.Col_Wpac.FieldName = "product_weight_pac"
        Me.Col_Wpac.Name = "Col_Wpac"
        Me.Col_Wpac.Visible = True
        Me.Col_Wpac.VisibleIndex = 2
        '
        'cbo_discount
        '
        Me.cbo_discount.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.cbo_discount.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cbo_discount.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_discount.FormattingEnabled = True
        Me.cbo_discount.Items.AddRange(New Object() {"0", "0.5", "0.75"})
        Me.cbo_discount.Location = New System.Drawing.Point(82, 110)
        Me.cbo_discount.Name = "cbo_discount"
        Me.cbo_discount.Size = New System.Drawing.Size(123, 24)
        Me.cbo_discount.Sorted = True
        Me.cbo_discount.TabIndex = 59
        '
        'txt_custid
        '
        Me.txt_custid.Location = New System.Drawing.Point(82, 50)
        Me.txt_custid.Name = "txt_custid"
        Me.txt_custid.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_custid.Properties.Appearance.ForeColor = System.Drawing.Color.Firebrick
        Me.txt_custid.Properties.Appearance.Options.UseFont = True
        Me.txt_custid.Properties.Appearance.Options.UseForeColor = True
        Me.txt_custid.Size = New System.Drawing.Size(344, 22)
        Me.txt_custid.TabIndex = 61
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(14, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 16)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Invoice ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(15, 85)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(54, 16)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Address"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(14, 117)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 16)
        Me.Label6.TabIndex = 58
        Me.Label6.Text = "Discount"
        '
        'txt_deladdress
        '
        Me.txt_deladdress.Enabled = False
        Me.txt_deladdress.Location = New System.Drawing.Point(82, 82)
        Me.txt_deladdress.Name = "txt_deladdress"
        Me.txt_deladdress.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_deladdress.Properties.Appearance.ForeColor = System.Drawing.Color.Black
        Me.txt_deladdress.Properties.Appearance.Options.UseFont = True
        Me.txt_deladdress.Properties.Appearance.Options.UseForeColor = True
        Me.txt_deladdress.Size = New System.Drawing.Size(344, 22)
        Me.txt_deladdress.TabIndex = 43
        '
        'txt_trnoid
        '
        Me.txt_trnoid.Enabled = False
        Me.txt_trnoid.Location = New System.Drawing.Point(82, 18)
        Me.txt_trnoid.Name = "txt_trnoid"
        Me.txt_trnoid.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_trnoid.Properties.Appearance.ForeColor = System.Drawing.Color.Firebrick
        Me.txt_trnoid.Properties.Appearance.Options.UseFont = True
        Me.txt_trnoid.Properties.Appearance.Options.UseForeColor = True
        Me.txt_trnoid.Size = New System.Drawing.Size(344, 22)
        Me.txt_trnoid.TabIndex = 34
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(15, 53)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 16)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Customer"
        '
        'PanelControl6
        '
        Me.PanelControl6.Appearance.BackColor = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.PanelControl6.Appearance.BackColor2 = System.Drawing.Color.FromArgb(CType(CType(37, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.PanelControl6.Appearance.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.ForwardDiagonal
        Me.PanelControl6.Appearance.Options.UseBackColor = True
        Me.PanelControl6.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl6.Controls.Add(Me.lbl_cahiername)
        Me.PanelControl6.Controls.Add(Me.Label5)
        Me.PanelControl6.Controls.Add(Me.lbl_date)
        Me.PanelControl6.Controls.Add(Me.lbl_datetime)
        Me.PanelControl6.Controls.Add(Me.Label2)
        Me.PanelControl6.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl6.Location = New System.Drawing.Point(2, 2)
        Me.PanelControl6.Name = "PanelControl6"
        Me.PanelControl6.Size = New System.Drawing.Size(545, 181)
        Me.PanelControl6.TabIndex = 0
        '
        'lbl_cahiername
        '
        Me.lbl_cahiername.AutoSize = True
        Me.lbl_cahiername.BackColor = System.Drawing.Color.Transparent
        Me.lbl_cahiername.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_cahiername.ForeColor = System.Drawing.Color.White
        Me.lbl_cahiername.Location = New System.Drawing.Point(490, 28)
        Me.lbl_cahiername.Name = "lbl_cahiername"
        Me.lbl_cahiername.Size = New System.Drawing.Size(52, 21)
        Me.lbl_cahiername.TabIndex = 39
        Me.lbl_cahiername.Text = "______"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Font = New System.Drawing.Font("Impact", 48.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(3, 88)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(137, 80)
        Me.Label5.TabIndex = 38
        Me.Label5.Text = "POS"
        '
        'lbl_date
        '
        Me.lbl_date.AutoSize = True
        Me.lbl_date.BackColor = System.Drawing.Color.Transparent
        Me.lbl_date.Font = New System.Drawing.Font("Tahoma", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_date.ForeColor = System.Drawing.Color.White
        Me.lbl_date.Location = New System.Drawing.Point(392, 130)
        Me.lbl_date.Name = "lbl_date"
        Me.lbl_date.Size = New System.Drawing.Size(52, 29)
        Me.lbl_date.TabIndex = 37
        Me.lbl_date.Text = "___"
        Me.lbl_date.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lbl_datetime
        '
        Me.lbl_datetime.AutoSize = True
        Me.lbl_datetime.BackColor = System.Drawing.Color.Transparent
        Me.lbl_datetime.Font = New System.Drawing.Font("Tahoma", 26.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_datetime.ForeColor = System.Drawing.Color.White
        Me.lbl_datetime.Location = New System.Drawing.Point(380, 88)
        Me.lbl_datetime.Name = "lbl_datetime"
        Me.lbl_datetime.Size = New System.Drawing.Size(75, 42)
        Me.lbl_datetime.TabIndex = 35
        Me.lbl_datetime.Text = "___"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(420, 28)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(74, 21)
        Me.Label2.TabIndex = 36
        Me.Label2.Text = "Cashier :"
        '
        'frm_transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.PanelControl5)
        Me.Controls.Add(Me.PanelControl2)
        Me.Name = "frm_transaction"
        Me.Text = "frm_transaction"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.dgpos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        CType(Me.PanelControl5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl5.ResumeLayout(False)
        CType(Me.PanelControl7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl7.ResumeLayout(False)
        Me.PanelControl7.PerformLayout()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_custid.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_deladdress.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_trnoid.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl6.ResumeLayout(False)
        Me.PanelControl6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents tmr_datetime As System.Windows.Forms.Timer
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents dgpos As System.Windows.Forms.DataGridView
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_rmvitem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_edtquantity As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents PanelControl5 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl6 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl7 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents txt_custid As DevExpress.XtraEditors.TextEdit
    Friend WithEvents cbo_discount As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lbl_datetime As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt_trnoid As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txt_deladdress As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lbl_date As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lbl_ototal As System.Windows.Forms.Label
    Friend WithEvents ToolTipController1 As DevExpress.Utils.ToolTipController
    Friend WithEvents dgprods As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents Col_prodcode As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_description As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_price As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_Wpac As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents prodcode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents pwpac As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents uom As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents unitprice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents discount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents netprice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents netamount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents lbl_cahiername As System.Windows.Forms.Label
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents lbl_itemnum As DevExpress.XtraEditors.LabelControl
End Class
