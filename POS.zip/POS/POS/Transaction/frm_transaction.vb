﻿Public Class frm_transaction


    Public Vals(5) As Object
    Dim P_ids As String


    Private Sub frm_popup_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        dgprods.DataSource = GetProducts()
        GetCustIDAll()
        GridView1.BestFitColumns()


        lbl_cahiername.Text = frm_login._Cashiername
    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "product_code")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "product_description")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "product_list_price")
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "product_weight_pac")

        P_ids = Vals(0).ToString

        'txt_customid.Text = Vals(0)
        'txt_customname.Text = Vals(1)

        frm_quantity.comm = 1

        frm_quantity.ShowDialog()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles tmr_datetime.Tick

        lbl_datetime.Text = Date.Now.ToShortTimeString.ToString
        lbl_date.Text = Date.Now.ToShortDateString.ToString

    End Sub

    'Private Sub ButtonEdit1_KeyDown(sender As Object, e As KeyEventArgs)
    '    If e.KeyCode = Keys.Enter Then
    '        MsgBox("heihihi")
    '    End If
    'End Sub

    Private Sub SimpleButton2_Click(sender As Object, e As EventArgs) Handles SimpleButton2.Click

        If txt_custid.Text = "" Or txt_deladdress.Text = "" Or cbo_discount.Text = "" Then
            MessageBox.Show("Please complete customer's information")
            Exit Sub

        ElseIf dgpos.Rows.Count < 2 And dgpos.Rows(0).Cells(0).Value Is Nothing Then
            MessageBox.Show("There is no order yet")
        Else

            Dim counter As Integer = 0

            GetVats()
            Get_GenHeaderId()
            Dim total As Integer = dgpos.Rows.Count

            Try
                If dgpos.Rows.Count <> 0 Then

                    Me.Cursor = Cursors.WaitCursor
                    For i As Integer = 0 To dgpos.Rows.Count
                        transaction(txt_custid.Text, dgpos.Rows(i).Cells(0).Value.ToString, dgpos.Rows(i).Cells(2).Value.ToString(), CDec(dgpos.Rows(i).Cells(3).Value.ToString), dgpos.Rows(i).Cells(4).Value.ToString, dgpos.Rows(i).Cells(5).Value.ToString(), dgpos.Rows(i).Cells(6).Value.ToString(), dgpos.Rows(i).Cells(7).Value.ToString(), dgpos.Rows(i).Cells(8).Value.ToString(), Date.Now.ToString("yyyy-MM-dd hh:mm:ss"), GenHeaderID)
                        Me.Cursor = Cursors.Default
                        counter = counter + 1
                        If total = counter Then
                            Exit For
                        End If
                    Next
                    Me.Cursor = Cursors.Default
                    MessageBox.Show("Order Successful!")

                Else
                    MessageBox.Show("Order Failed")
                End If
            Catch ex As Exception
                MessageBox.Show("Data Error")
                Exit Sub
            End Try
            Gettotalap()
            dgpos.Rows.Clear()
            dgpos.AllowUserToAddRows = True
        End If


    End Sub

    'Private Sub cbo_customer_SelectedIndexChanged(sender As Object, e As EventArgs) Handles 
    '    'Getstrings()
    '    txt_deladdress.Text = custadd
    'End Sub


    Private Sub txt_custid_Click(sender As Object, e As EventArgs) Handles txt_custid.Click

        frm_customer.ShowDialog()

    End Sub


    Private Sub btn_edtquantity_Click(sender As Object, e As EventArgs) Handles btn_edtquantity.Click

        If dgpos.Rows.Count < 2 And dgpos.Rows(0).Cells(0).Value Is Nothing Then
            MessageBox.Show("There is no order yet")
        Else
            frm_quantity.comm = 2
            frm_quantity.ShowDialog()
        End If

     
    End Sub

    Private Sub btn_rmvitem_Click(sender As Object, e As EventArgs) Handles btn_rmvitem.Click

        If dgpos.Rows.Count < 2 And dgpos.Rows(0).Cells(0).Value Is Nothing Then
            MessageBox.Show("There is no order yet")
        Else
            For Each row As DataGridViewRow In dgpos.SelectedRows
                dgpos.Rows.Remove(row)
            Next

            Gettotalap()
        End If

        lbl_itemnum.Text = CStr(dgpos.Rows.Count)
        DgposDesign()
    End Sub

End Class