﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_pos
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim EditorButtonImageOptions1 As DevExpress.XtraEditors.Controls.EditorButtonImageOptions = New DevExpress.XtraEditors.Controls.EditorButtonImageOptions()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frm_pos))
        Dim SerializableAppearanceObject1 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject2 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject3 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim SerializableAppearanceObject4 As DevExpress.Utils.SerializableAppearanceObject = New DevExpress.Utils.SerializableAppearanceObject()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgprods = New DevExpress.XtraGrid.GridControl()
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView()
        Me.Col_prodid = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_uom = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_price = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.Col_desc = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.btn_addtocart = New DevExpress.XtraGrid.Columns.GridColumn()
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit()
        Me.txt_cashier = New DevExpress.XtraEditors.TextEdit()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.PanelControl1 = New DevExpress.XtraEditors.PanelControl()
        Me.lbl_subtotal = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbl_datetime = New System.Windows.Forms.Label()
        Me.txt_trnoid = New DevExpress.XtraEditors.TextEdit()
        Me.btn_removeitem = New DevExpress.XtraEditors.SimpleButton()
        Me.btn_newcustomer = New DevExpress.XtraEditors.SimpleButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PanelControl2 = New DevExpress.XtraEditors.PanelControl()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.cbo_prodcode = New DevExpress.XtraEditors.TextEdit()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.cbo_discount = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.cbo_customer = New System.Windows.Forms.ComboBox()
        Me.txt_deladdress = New DevExpress.XtraEditors.TextEdit()
        Me.PanelControl3 = New DevExpress.XtraEditors.PanelControl()
        Me.PanelControl4 = New DevExpress.XtraEditors.PanelControl()
        Me.btn_previnvoice = New DevExpress.XtraEditors.SimpleButton()
        Me.tmr_daytime = New System.Windows.Forms.Timer(Me.components)
        Me.dgpos = New System.Windows.Forms.DataGridView()
        Me.prodcode = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.description = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.unitprice = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.quantity = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.discount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ivat = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.subtotal = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txt_cashier.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl1.SuspendLayout()
        CType(Me.txt_trnoid.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        CType(Me.cbo_prodcode.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel3.SuspendLayout()
        CType(Me.txt_deladdress.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl3.SuspendLayout()
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelControl4.SuspendLayout()
        CType(Me.dgpos, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgprods
        '
        Me.dgprods.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgprods.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dgprods.Location = New System.Drawing.Point(0, 199)
        Me.dgprods.MainView = Me.GridView1
        Me.dgprods.Name = "dgprods"
        Me.dgprods.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemButtonEdit1})
        Me.dgprods.Size = New System.Drawing.Size(1136, 286)
        Me.dgprods.TabIndex = 42
        Me.dgprods.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.Col_prodid, Me.Col_uom, Me.Col_price, Me.Col_desc, Me.btn_addtocart})
        Me.GridView1.GridControl = Me.dgprods
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsBehavior.Editable = False
        Me.GridView1.OptionsBehavior.ReadOnly = True
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'Col_prodid
        '
        Me.Col_prodid.Caption = "Product ID"
        Me.Col_prodid.FieldName = "prod_id"
        Me.Col_prodid.Name = "Col_prodid"
        Me.Col_prodid.Visible = True
        Me.Col_prodid.VisibleIndex = 0
        '
        'Col_uom
        '
        Me.Col_uom.Caption = "UOM"
        Me.Col_uom.FieldName = "uom"
        Me.Col_uom.Name = "Col_uom"
        Me.Col_uom.Visible = True
        Me.Col_uom.VisibleIndex = 1
        '
        'Col_price
        '
        Me.Col_price.Caption = "List Price"
        Me.Col_price.FieldName = "list_price"
        Me.Col_price.Name = "Col_price"
        Me.Col_price.Visible = True
        Me.Col_price.VisibleIndex = 2
        '
        'Col_desc
        '
        Me.Col_desc.Caption = "Description"
        Me.Col_desc.FieldName = "prod_desc"
        Me.Col_desc.Name = "Col_desc"
        Me.Col_desc.Visible = True
        Me.Col_desc.VisibleIndex = 3
        '
        'btn_addtocart
        '
        Me.btn_addtocart.Caption = "Add to Cart"
        Me.btn_addtocart.ColumnEdit = Me.RepositoryItemButtonEdit1
        Me.btn_addtocart.ImageOptions.Image = CType(resources.GetObject("btn_addtocart.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_addtocart.Name = "btn_addtocart"
        Me.btn_addtocart.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow
        Me.btn_addtocart.Visible = True
        Me.btn_addtocart.VisibleIndex = 4
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        EditorButtonImageOptions1.Image = CType(resources.GetObject("EditorButtonImageOptions1.Image"), System.Drawing.Image)
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, True, True, False, EditorButtonImageOptions1, New DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), SerializableAppearanceObject1, SerializableAppearanceObject2, SerializableAppearanceObject3, SerializableAppearanceObject4, "", Nothing, Nothing, DevExpress.Utils.ToolTipAnchor.[Default])})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        Me.RepositoryItemButtonEdit1.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor
        '
        'txt_cashier
        '
        Me.txt_cashier.Enabled = False
        Me.txt_cashier.Location = New System.Drawing.Point(386, 155)
        Me.txt_cashier.Name = "txt_cashier"
        Me.txt_cashier.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_cashier.Properties.Appearance.Options.UseFont = True
        Me.txt_cashier.Size = New System.Drawing.Size(164, 26)
        Me.txt_cashier.TabIndex = 41
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(325, 158)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(61, 19)
        Me.Label9.TabIndex = 40
        Me.Label9.Text = "Cashier"
        '
        'PanelControl1
        '
        Me.PanelControl1.Appearance.BackColor = System.Drawing.Color.White
        Me.PanelControl1.Appearance.Options.UseBackColor = True
        Me.PanelControl1.Controls.Add(Me.lbl_subtotal)
        Me.PanelControl1.Controls.Add(Me.Label7)
        Me.PanelControl1.Location = New System.Drawing.Point(13, 13)
        Me.PanelControl1.Name = "PanelControl1"
        Me.PanelControl1.Size = New System.Drawing.Size(531, 108)
        Me.PanelControl1.TabIndex = 39
        '
        'lbl_subtotal
        '
        Me.lbl_subtotal.AutoSize = True
        Me.lbl_subtotal.BackColor = System.Drawing.Color.Transparent
        Me.lbl_subtotal.Font = New System.Drawing.Font("Tahoma", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_subtotal.ForeColor = System.Drawing.Color.Firebrick
        Me.lbl_subtotal.Location = New System.Drawing.Point(20, 50)
        Me.lbl_subtotal.Name = "lbl_subtotal"
        Me.lbl_subtotal.Size = New System.Drawing.Size(68, 39)
        Me.lbl_subtotal.TabIndex = 10
        Me.lbl_subtotal.Text = "200"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Font = New System.Drawing.Font("Tahoma", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(21, 11)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(128, 33)
        Me.Label7.TabIndex = 9
        Me.Label7.Text = "Sub Total"
        '
        'lbl_datetime
        '
        Me.lbl_datetime.AutoSize = True
        Me.lbl_datetime.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_datetime.ForeColor = System.Drawing.Color.Black
        Me.lbl_datetime.Location = New System.Drawing.Point(123, 158)
        Me.lbl_datetime.Name = "lbl_datetime"
        Me.lbl_datetime.Size = New System.Drawing.Size(36, 19)
        Me.lbl_datetime.TabIndex = 35
        Me.lbl_datetime.Text = "___"
        '
        'txt_trnoid
        '
        Me.txt_trnoid.Enabled = False
        Me.txt_trnoid.Location = New System.Drawing.Point(116, 10)
        Me.txt_trnoid.Name = "txt_trnoid"
        Me.txt_trnoid.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_trnoid.Properties.Appearance.ForeColor = System.Drawing.Color.Firebrick
        Me.txt_trnoid.Properties.Appearance.Options.UseFont = True
        Me.txt_trnoid.Properties.Appearance.Options.UseForeColor = True
        Me.txt_trnoid.Size = New System.Drawing.Size(272, 26)
        Me.txt_trnoid.TabIndex = 34
        '
        'btn_removeitem
        '
        Me.btn_removeitem.ImageOptions.Image = CType(resources.GetObject("btn_removeitem.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_removeitem.Location = New System.Drawing.Point(418, 67)
        Me.btn_removeitem.Name = "btn_removeitem"
        Me.btn_removeitem.Size = New System.Drawing.Size(132, 50)
        Me.btn_removeitem.TabIndex = 33
        Me.btn_removeitem.Text = "Remove Item"
        '
        'btn_newcustomer
        '
        Me.btn_newcustomer.ImageOptions.Image = CType(resources.GetObject("btn_newcustomer.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_newcustomer.Location = New System.Drawing.Point(418, 11)
        Me.btn_newcustomer.Name = "btn_newcustomer"
        Me.btn_newcustomer.Size = New System.Drawing.Size(132, 50)
        Me.btn_newcustomer.TabIndex = 32
        Me.btn_newcustomer.Text = "New Customer"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(184, 140)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(80, 19)
        Me.Label5.TabIndex = 31
        Me.Label5.Text = "Item code"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(28, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 19)
        Me.Label4.TabIndex = 30
        Me.Label4.Text = "Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(28, 44)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 19)
        Me.Label3.TabIndex = 29
        Me.Label3.Text = "Customer"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(28, 158)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(89, 19)
        Me.Label2.TabIndex = 28
        Me.Label2.Text = "Date/Time:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(28, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 19)
        Me.Label1.TabIndex = 27
        Me.Label1.Text = "Invoice ID"
        '
        'PanelControl2
        '
        Me.PanelControl2.Controls.Add(Me.Panel4)
        Me.PanelControl2.Controls.Add(Me.Panel3)
        Me.PanelControl2.Dock = System.Windows.Forms.DockStyle.Top
        Me.PanelControl2.Location = New System.Drawing.Point(0, 0)
        Me.PanelControl2.Name = "PanelControl2"
        Me.PanelControl2.Size = New System.Drawing.Size(1136, 199)
        Me.PanelControl2.TabIndex = 54
        '
        'Panel4
        '
        Me.Panel4.Controls.Add(Me.cbo_prodcode)
        Me.Panel4.Controls.Add(Me.PanelControl1)
        Me.Panel4.Controls.Add(Me.Label5)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Right
        Me.Panel4.Location = New System.Drawing.Point(561, 2)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(573, 195)
        Me.Panel4.TabIndex = 56
        '
        'cbo_prodcode
        '
        Me.cbo_prodcode.Location = New System.Drawing.Point(272, 137)
        Me.cbo_prodcode.Name = "cbo_prodcode"
        Me.cbo_prodcode.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_prodcode.Properties.Appearance.Options.UseFont = True
        Me.cbo_prodcode.Size = New System.Drawing.Size(272, 26)
        Me.cbo_prodcode.TabIndex = 45
        '
        'Panel3
        '
        Me.Panel3.Controls.Add(Me.cbo_discount)
        Me.Panel3.Controls.Add(Me.Label6)
        Me.Panel3.Controls.Add(Me.cbo_customer)
        Me.Panel3.Controls.Add(Me.txt_deladdress)
        Me.Panel3.Controls.Add(Me.txt_cashier)
        Me.Panel3.Controls.Add(Me.Label9)
        Me.Panel3.Controls.Add(Me.Label1)
        Me.Panel3.Controls.Add(Me.lbl_datetime)
        Me.Panel3.Controls.Add(Me.btn_newcustomer)
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Controls.Add(Me.btn_removeitem)
        Me.Panel3.Controls.Add(Me.txt_trnoid)
        Me.Panel3.Controls.Add(Me.Label3)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Dock = System.Windows.Forms.DockStyle.Left
        Me.Panel3.Location = New System.Drawing.Point(2, 2)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(553, 195)
        Me.Panel3.TabIndex = 56
        '
        'cbo_discount
        '
        Me.cbo_discount.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_discount.FormattingEnabled = True
        Me.cbo_discount.Location = New System.Drawing.Point(116, 108)
        Me.cbo_discount.Name = "cbo_discount"
        Me.cbo_discount.Size = New System.Drawing.Size(272, 27)
        Me.cbo_discount.Sorted = True
        Me.cbo_discount.TabIndex = 59
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(28, 108)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(70, 19)
        Me.Label6.TabIndex = 58
        Me.Label6.Text = "Discount"
        '
        'cbo_customer
        '
        Me.cbo_customer.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbo_customer.FormattingEnabled = True
        Me.cbo_customer.Location = New System.Drawing.Point(116, 44)
        Me.cbo_customer.Name = "cbo_customer"
        Me.cbo_customer.Size = New System.Drawing.Size(272, 27)
        Me.cbo_customer.Sorted = True
        Me.cbo_customer.TabIndex = 57
        '
        'txt_deladdress
        '
        Me.txt_deladdress.Enabled = False
        Me.txt_deladdress.Location = New System.Drawing.Point(116, 76)
        Me.txt_deladdress.Name = "txt_deladdress"
        Me.txt_deladdress.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_deladdress.Properties.Appearance.ForeColor = System.Drawing.Color.Black
        Me.txt_deladdress.Properties.Appearance.Options.UseFont = True
        Me.txt_deladdress.Properties.Appearance.Options.UseForeColor = True
        Me.txt_deladdress.Size = New System.Drawing.Size(272, 26)
        Me.txt_deladdress.TabIndex = 43
        '
        'PanelControl3
        '
        Me.PanelControl3.Controls.Add(Me.PanelControl4)
        Me.PanelControl3.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.PanelControl3.Location = New System.Drawing.Point(0, 485)
        Me.PanelControl3.Name = "PanelControl3"
        Me.PanelControl3.Size = New System.Drawing.Size(1136, 67)
        Me.PanelControl3.TabIndex = 55
        '
        'PanelControl4
        '
        Me.PanelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder
        Me.PanelControl4.Controls.Add(Me.btn_previnvoice)
        Me.PanelControl4.Dock = System.Windows.Forms.DockStyle.Right
        Me.PanelControl4.Location = New System.Drawing.Point(833, 2)
        Me.PanelControl4.Name = "PanelControl4"
        Me.PanelControl4.Size = New System.Drawing.Size(301, 63)
        Me.PanelControl4.TabIndex = 34
        '
        'btn_previnvoice
        '
        Me.btn_previnvoice.ImageOptions.Image = CType(resources.GetObject("btn_previnvoice.ImageOptions.Image"), System.Drawing.Image)
        Me.btn_previnvoice.Location = New System.Drawing.Point(18, 10)
        Me.btn_previnvoice.Name = "btn_previnvoice"
        Me.btn_previnvoice.Size = New System.Drawing.Size(273, 50)
        Me.btn_previnvoice.TabIndex = 33
        Me.btn_previnvoice.Text = "Preview Orders"
        '
        'tmr_daytime
        '
        Me.tmr_daytime.Enabled = True
        Me.tmr_daytime.Interval = 1000
        '
        'dgpos
        '
        Me.dgpos.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised
        Me.dgpos.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.[Single]
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Tahoma", 8.25!)
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgpos.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgpos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgpos.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.prodcode, Me.description, Me.unitprice, Me.quantity, Me.discount, Me.ivat, Me.subtotal})
        Me.dgpos.Dock = System.Windows.Forms.DockStyle.Fill
        Me.dgpos.Location = New System.Drawing.Point(0, 199)
        Me.dgpos.Name = "dgpos"
        Me.dgpos.Size = New System.Drawing.Size(1136, 286)
        Me.dgpos.TabIndex = 56
        '
        'prodcode
        '
        Me.prodcode.HeaderText = "Product Code"
        Me.prodcode.Name = "prodcode"
        Me.prodcode.Width = 200
        '
        'description
        '
        Me.description.HeaderText = "Description"
        Me.description.Name = "description"
        Me.description.Width = 500
        '
        'unitprice
        '
        Me.unitprice.HeaderText = "Unit Price"
        Me.unitprice.Name = "unitprice"
        Me.unitprice.Width = 125
        '
        'quantity
        '
        Me.quantity.HeaderText = "Quantity"
        Me.quantity.Name = "quantity"
        Me.quantity.Width = 125
        '
        'discount
        '
        Me.discount.HeaderText = "Discount"
        Me.discount.Name = "discount"
        Me.discount.Width = 125
        '
        'ivat
        '
        Me.ivat.HeaderText = "Vat"
        Me.ivat.Name = "ivat"
        Me.ivat.Width = 125
        '
        'subtotal
        '
        Me.subtotal.HeaderText = "Sub Total"
        Me.subtotal.Name = "subtotal"
        Me.subtotal.Width = 125
        '
        'frm_pos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1136, 552)
        Me.Controls.Add(Me.dgprods)
        Me.Controls.Add(Me.dgpos)
        Me.Controls.Add(Me.PanelControl3)
        Me.Controls.Add(Me.PanelControl2)
        Me.Name = "frm_pos"
        Me.Text = "frm_pos"
        CType(Me.dgprods, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txt_cashier.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl1.ResumeLayout(False)
        Me.PanelControl1.PerformLayout()
        CType(Me.txt_trnoid.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        CType(Me.cbo_prodcode.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        CType(Me.txt_deladdress.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PanelControl3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl3.ResumeLayout(False)
        CType(Me.PanelControl4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelControl4.ResumeLayout(False)
        CType(Me.dgpos, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgprods As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents txt_cashier As DevExpress.XtraEditors.TextEdit
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents PanelControl1 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents lbl_subtotal As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents lbl_datetime As System.Windows.Forms.Label
    Friend WithEvents txt_trnoid As DevExpress.XtraEditors.TextEdit
    Friend WithEvents btn_removeitem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btn_newcustomer As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PanelControl2 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents PanelControl3 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents txt_deladdress As DevExpress.XtraEditors.TextEdit
    Friend WithEvents tmr_daytime As System.Windows.Forms.Timer
    Friend WithEvents dgpos As System.Windows.Forms.DataGridView
    Friend WithEvents prodcode As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents description As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents unitprice As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents quantity As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents discount As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ivat As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents subtotal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents cbo_customer As System.Windows.Forms.ComboBox
    Friend WithEvents btn_addtocart As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_desc As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_uom As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_price As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents Col_prodid As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents cbo_prodcode As DevExpress.XtraEditors.TextEdit
    Friend WithEvents PanelControl4 As DevExpress.XtraEditors.PanelControl
    Friend WithEvents btn_previnvoice As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents cbo_discount As System.Windows.Forms.ComboBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
End Class
