﻿Public Class frm_pos 


    Public Vals(5) As Object
    Dim P_ids As String


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles tmr_daytime.Tick

        lbl_datetime.Text = Date.Now.ToString

    End Sub

    Private Sub TextEdit2_TextChanged(sender As Object, e As EventArgs)

        If cbo_prodcode.Text = "1234" Then

            dgpos.Rows.Add(cbo_prodcode.Text, "CDO Carne Norte", "10", "10", "0", "100")

        ElseIf cbo_prodcode.Text Is Nothing Then

            Exit Sub

        End If

    End Sub

    Private Sub frm_pos_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dgprods.DataSource = GetProducts()

        GetCustIDAll()

    End Sub

    Private Sub gridView1_Click(sender As Object, e As System.EventArgs) Handles GridView1.RowCellClick

        Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
        Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "prod_id")
        Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "prod_desc")
        Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "list_price")
        Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "uom")

        P_ids = Vals(0).ToString

        'txt_customid.Text = Vals(0)
        'txt_customname.Text = Vals(1)

        frm_quantity.ShowDialog()
    End Sub

    'Private Sub btn_atc_Click(sender As Object, e As EventArgs) Handles btn_atc.Click

    '    Dim view As DevExpress.XtraGrid.Views.Grid.GridView = CType(sender, DevExpress.XtraGrid.Views.Grid.GridView)
    '    Vals(0) = view.GetRowCellValue(view.FocusedRowHandle, "prod_id")
    '    Vals(1) = view.GetRowCellValue(view.FocusedRowHandle, "prod_desc")
    '    Vals(2) = view.GetRowCellValue(view.FocusedRowHandle, "unit_price")
    '    Vals(3) = view.GetRowCellValue(view.FocusedRowHandle, "discount")
    '    P_ids = Vals(0).ToString

    '    'txt_customid.Text = Vals(0)
    '    'txt_customname.Text = Vals(1)
    '    frm_quantity.Label1.Text = Vals(2)

    '    frm_quantity.ShowDialog()
    'End Sub

    Private Sub cbo_prodcode_TextChanged(sender As Object, e As EventArgs) Handles cbo_prodcode.TextChanged
        searchPorder(cbo_prodcode.Text)
    End Sub


    Private Sub btn_previnvoice_Click(sender As Object, e As EventArgs) Handles btn_previnvoice.Click

        frm_previeworders.ShowDialog()

    End Sub

    Private Sub cbo_prodcode_EditValueChanged(sender As Object, e As EventArgs) Handles cbo_prodcode.EditValueChanged

    End Sub
End Class