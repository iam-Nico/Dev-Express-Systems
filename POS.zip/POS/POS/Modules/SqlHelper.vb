﻿

Imports System.Data
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.TypeInitializationException

Public Class SqlHelper

    Public _cmd As SqlCommand
    Public _dr As SqlDataReader
    Public _dap As SqlDataAdapter
    Public _con As SqlConnection

    Public Function ActionData(ByVal str As String) As Integer
        Dim returnval As String
        _con = New SqlConnection(My.Settings.dbcon)
        _con.Open()
        _cmd = New SqlCommand
        _cmd.CommandType = CommandType.Text
        _cmd.CommandText = str
        _cmd.Connection = _con
        returnval = _cmd.ExecuteNonQuery

        _con.Dispose()
        _cmd.Dispose()
        Return returnval
    End Function


    Public Function GetData(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd
            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

            End Using

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function

    Public Function GetCustomersList(ByVal ConStr As String) As DataTable
        Dim dt As DataTable = Nothing
        _con = New SqlConnection(My.Settings.dbcon)
        _con.Open()
        _cmd = New SqlCommand
        _cmd.CommandType = CommandType.Text
        _cmd.CommandText = ConStr
        _cmd.Connection = _con
        _dap = New SqlDataAdapter
        _dap.SelectCommand = _cmd
        Using ds As New DataSet

            _dap.Fill(ds)
            dt = ds.Tables(0)

        End Using

        dt.Clear()

        _dap.Fill(dt)


        _con.Dispose()
        _cmd.Dispose()


        Return dt
    End Function

    Public Function GetDatastring(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd
            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

            End Using


            Dim _dr As SqlDataReader = _cmd.ExecuteReader
            _dr.Read()
            If _dr.HasRows Then
                GenHeaderID = _dr("GenHeaderID").ToString

            End If

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try
    End Function

    Public Function UserLogin(ByVal ConStr As String) As DataTable

        Try
            Dim dt As DataTable = Nothing
            _con = New SqlConnection(My.Settings.dbcon)
            _con.Open()
            _cmd = New SqlCommand
            _cmd.CommandType = CommandType.Text
            _cmd.CommandText = ConStr
            _cmd.Connection = _con
            _dap = New SqlDataAdapter
            _dap.SelectCommand = _cmd
            Using ds As New DataSet

                _dap.Fill(ds)
                dt = ds.Tables(0)

            End Using

            Dim _dr As SqlDataReader = _cmd.ExecuteReader
            _dr.Read()

            If _dr.HasRows Then
                frm_login._Cashier = _dr("cashier_id").ToString
                frm_login._Cashiername = _dr("cashier_fname").ToString
                frm_login.Hide()
                frm_main.Show()
            Else
                MessageBox.Show("Invalid Login!")
            End If

            _con.Dispose()
            _cmd.Dispose()


            Return dt
        Catch ex As Exception
            Exit Function
        End Try

    End Function


End Class
