﻿

Imports System.Data.SqlClient
Imports System.Data.OleDb
Imports Microsoft.VisualBasic
Imports System.IO

Module sysfunction


    ''FILE
    Public Function OpenFile(ByVal filename As String) As Object

        Dim fullfilename = String.Format("{0}\{1}", Directory.GetCurrentDirectory(), filename)
        Dim Connectionstring As String = String.Format("Provider=Microsoft.ACE.OLEDB.12.0;Data Source={0}; Extended Properties=Excel 12.0;", filename)
        Dim adapter = New OleDbDataAdapter("Select * from [product_table$]", Connectionstring)
        Dim dt As New DataSet
        Dim tablename As String = "excelData"
        adapter.Fill(dt, tablename)

        Dim data As DataTable = dt.Tables(tablename)

        Return data

    End Function

    Public Sub Insertinfo(ByVal prod_type As String, prod_desc As String, prod_code As String, prod_wpac As Decimal, prod_upac As String, prod_wbx As Decimal, prod_ubx As String, prod_lprice As Decimal)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_products (product_type,product_description,product_code,product_weight_pac,product_uom_pac,product_weight_bx,product_uom_bx,product_list_price ) values ('" & prod_type & "','" & prod_desc & "','" & prod_code & "', '" & prod_wpac & "','" & prod_upac & "', '" & prod_wbx & "', '" & prod_ubx & "', '" & prod_lprice & "')")
    End Sub

    ''CUSTOMERS
    Public Function GetCustomers() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select * from tbl_customers")
        Return dt
    End Function

    Public Sub AddUsers(ByVal custname As String, custdeladdress As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_customers (customer_name,customer_del_address) values ('" & custname & "','" & custdeladdress & "')")
    End Sub

    Public Sub EditUsers(ByVal custname As String, custdeladdress As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_customers set customer_name = '" & custname & "',customer_del_address = '" & custdeladdress & "' Where customer_id = '" & frm_customers.U_ids & "' ")
    End Sub

    Public Sub DeleteUsers(ByVal U_ID As Integer)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_customers where customer_id = '" & U_ID & "' ")
    End Sub

    Public Function search(ByVal customID As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable

        If frm_customers.txt_search.Text = "" Then
            dt = obj.GetData("Select * from tbl_customers ")
        Else
            dt = obj.GetData("Select * from tbl_customers where customer_id = '" & customID & "'")
        End If
        frm_customers.dgcustomers.DataSource = dt
        Return dt
    End Function


    ''PRODUCTS

    Public Function GetProducts() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select * from tbl_products")
        Return dt
    End Function

    Public Sub AddProducts(ByVal prod_type As String, prod_desc As String, prod_code As String, prod_wpac As Decimal, prod_upac As String, prod_wbx As Decimal, prod_ubx As String, prod_lprice As Decimal)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_products (product_type,product_description,product_code,product_weight_pac,product_uom_pac,product_weight_bx,product_uom_bx,product_list_price ) values ('" & prod_type & "','" & prod_desc & "','" & prod_code & "', '" & prod_wpac & "','" & prod_upac & "', '" & prod_wbx & "', '" & prod_ubx & "', '" & prod_lprice & "')")
    End Sub

    Public Sub EditProducts(ByVal prod_type As String, prod_desc As String, prod_code As String, prod_wpac As Decimal, prod_upac As String, prod_wbx As Decimal, prod_ubx As String, prod_lprice As Decimal)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_products set product_type = '" & prod_type & "',product_description = '" & prod_desc & "',product_code '" & prod_code & "', product_weight_pac = '" & prod_wpac & "',product_uom_pac = '" & prod_upac & "',product_weight_bx = '" & prod_wbx & "',product_uom_bx = '" & prod_ubx & "',product_list_price = '" & prod_lprice & "' Where prod_id = '" & frm_products.P_ids & "' ")
    End Sub

    Public Sub DeleteProducts(ByVal P_ID As Integer)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_products where prod_id = '" & P_ID & "' ")
    End Sub

    Public Function searchproduct(ByVal ProdID As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable

        If frm_products.txt_searchprod.Text = "" Then
            dt = obj.GetData("Select * from tbl_products ")
        Else
            dt = obj.GetData("Select * from tbl_products where prod_id = '" & ProdID & "'")
        End If
        frm_products.dgprods.DataSource = dt
        Return dt
    End Function

    Public Function searchPorder(ByVal ProdID As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable

        If frm_pos.cbo_prodcode.Text = "" Then
            dt = obj.GetData("Select * from tbl_products ")
        Else
            dt = obj.GetData("Select * from tbl_products where prod_id = '" & ProdID & "'")
        End If
        frm_pos.dgprods.DataSource = dt
        Return dt
    End Function

    Public Function GetCustIDAll() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetCustomersList("Select * from tbl_customers")
        Return dt
    End Function

    'Public Function GetCustID() As DataTable
    '    Dim obj As New SqlHelper
    '    Dim dt As New DataTable
    '    dt = obj.GetCustomersList("Select customer_id from tbl_customers where customer_id like '" & frm_transaction.cbo_customer.Text & "'")
    '    Return dt
    'End Function

    'Public Function Getstrings() As DataTable
    '    Dim obj As New SqlHelper
    '    Dim dt As New DataTable
    '    dt = obj.GetDatastring("Select * from tbl_customers where customer_id like '" & frm_transaction.cbo_customer.Text & "'")
    '    Return dt
    'End Function
    Public Function Getreport() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("SELECT a.trno, a.customer_id, a.vatablesales, a.vat, a.discount, a.totalap, a.t_date, b.prod_code, b.quantity, b.net_amount FROM dbo.tbl_Gen_header AS a INNER JOIN dbo.tbl_Gen_details AS b ON a.trno = b.trno")
        Return dt
    End Function



    ''TRANSACTION

    Public Sub transaction(ByVal custid As String, prodid As String, quantity As Decimal, twpacc As Decimal, uom As String, listprice As Decimal, discount As Decimal, netprice As Decimal, netamount As Decimal, pdate As DateTime, ByVal headerid As Integer)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_Gen_details (customer_id,product_code,quantity,total_weight_pac,uom,product_list_price,discount,net_price,net_amount,pdate,trno) values ('" & custid & "','" & prodid & "','" & quantity & "','" & twpacc & "','" & uom & "','" & listprice & "', '" & discount & "', '" & netprice & "', '" & netamount & "','" & pdate & "','" & headerid & "')")

    End Sub

    Public Function addvat(ByVal custid As String, ByVal cashierid As String, vatablesales As Decimal, vat As Decimal, discount As Decimal, totalap As Decimal, t_date As DateTime) As Integer
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_Gen_header (customer_id,cashier_id,vatablesales,vat,discount,totalap,t_date ) values ('" & custid & "','" & cashierid & "','" & vatablesales & "','" & vat & "', '" & discount & "','" & totalap & "','" & t_date & "')")
        Return id

    End Function

    Public Function Get_GenHeaderId() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetDatastring("Select MAX(trno) as GenHeaderID from tbl_Gen_header")
        Return dt
    End Function


    ''CASHIER

    Public Function GetCashier() As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.GetData("Select * from tbl_cashier")
        Return dt
    End Function


    Public Function Login(ByVal username As String, password As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable
        dt = obj.UserLogin("Select * from tbl_cashier where cashier_username = '" & username & "' and cashier_password = '" & password & "'")
        Return dt
    End Function

    Public Sub DeleteCashier(ByVal C_ID As Integer)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Delete from tbl_cashier where cashier_id = '" & C_ID & "' ")
    End Sub

    Public Function searchcashier(ByVal CashierID As String) As DataTable
        Dim obj As New SqlHelper
        Dim dt As New DataTable

        If frm_cashier.txt_search.Text = "" Then
            dt = obj.GetData("Select * from tbl_cashier ")
        Else
            dt = obj.GetData("Select * from tbl_cashier where cashier_id = '" & CashierID & "'")
        End If
        frm_cashier.dg_cashier.DataSource = dt
        Return dt
    End Function

    Public Sub AddCashier(ByVal cfname As String, cmname As String, clname As String, uname As String, pass As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Insert into tbl_cashier (cashier_fname,cashier_mname,cashier_lname,cashier_username,cashier_password) values ('" & cfname & "','" & cmname & "','" & clname & "','" & uname & "','" & pass & "')")
    End Sub

    Public Sub EditCashier(ByVal cfname As String, cmname As String, clname As String, uname As String, pass As String)
        Dim obj As New SqlHelper
        Dim id As Integer
        id = obj.ActionData("Update tbl_cashier set cashier_fname = '" & cfname & "',cashier_mname = '" & cmname & "',cashier_lname = '" & clname & "',cashier_username = '" & uname & "',cashier_password = '" & pass & "' Where cashier_id = '" & frm_cashier.C_ids & "' ")
    End Sub

End Module
