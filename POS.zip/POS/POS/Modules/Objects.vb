﻿Module Objects

    Public st As Integer = 0
    Public GenHeaderID As String
    Public dt As DataTable


    Public vatsales, vat, totalap As Decimal

    Public Sub UsersClear()

        With frm_modcustomers
            .txt_customid.Text = ""
            .txt_customname.Text = ""
            .txt_deladdress.Text = ""
        End With

        With frm_customers
            .txt_customid.Text = ""
            .txt_customname.Text = ""
            .txt_deladdress.Text = ""
        End With

        With frm_modproducts
            .txt_prodid.Text = ""
            .txt_desc.Text = ""
            .txt_price.Text = ""
            .txt_bx.Text = ""
        End With
        With frm_cashier
            .txt_fname.Text = ""
            .txt_mname.Text = ""
            .txt_lname.Text = ""
            .txt_cashierid.Text = ""
        End With

        With frm_modcashier
            .txt_fname.Text = ""
            .txt_mname.Text = ""
            .txt_lname.Text = ""
            .txt_cashierid.Text = ""
            .txt_cusername.Text = ""
            .txt_cpassword.Text = ""
        End With

    End Sub

    Public Sub SortCustomers()
    End Sub

    Public Sub GetVats()

        vatsales = 0

        For Each row As DataGridViewRow In frm_transaction.dgpos.Rows

            vatsales += row.Cells(8).Value

        Next

        vat = vatsales * 0.12
        totalap = vatsales + vat

        totalap = Math.Round(totalap, 2)

        addvat(frm_transaction.txt_custid.Text, frm_login._Cashier, CDec(vatsales), CDec(vat), frm_transaction.cbo_discount.Text, totalap, Date.Now.ToString("yyyy-MM-dd hh:mm:ss"))

        'MessageBox.Show(id)
        'MessageBox.Show(vatsales.ToString + " " + vat.ToString + " " + totalap.ToString)

    End Sub

    Public Sub Gettotalap()

        vatsales = 0

        For Each row As DataGridViewRow In frm_transaction.dgpos.Rows

            vatsales += row.Cells(8).Value

        Next

        vat = vatsales * 0.12
        totalap = vatsales + vat

        totalap = Math.Round(totalap, 2)
        frm_transaction.lbl_ototal.Text = totalap

    End Sub

    Public Sub UploadProds()
        dt = frm_products.DataGridView1.DataSource
        If dt.Rows.Count <> 0 Then
            For i As Integer = 0 To dt.Rows.Count - 1
                Try
                    Insertinfo(dt.Rows(i)(0).ToString, dt.Rows(i)(1).ToString, dt.Rows(i)(2).ToString, dt.Rows(i)(3).ToString, dt.Rows(i)(4).ToString, dt.Rows(i)(5).ToString, dt.Rows(i)(6).ToString, dt.Rows(i)(7).ToString)

                Catch ex As Exception
                    MessageBox.Show("Data Error")
                    Exit Sub
                End Try
            Next
            MessageBox.Show("Uploded!")
        End If
    End Sub

    Public Sub DgposDesign()
        frm_transaction.lbl_itemnum.Text = CStr(frm_transaction.dgpos.Rows.Count)
        Dim i As Integer = 0
        For Each row In frm_transaction.dgpos.Rows
            frm_transaction.dgpos.Rows(i).HeaderCell.Value = (1 + i).ToString
            i += 1
            'MessageBox.Show(i)
        Next

    End Sub

End Module
